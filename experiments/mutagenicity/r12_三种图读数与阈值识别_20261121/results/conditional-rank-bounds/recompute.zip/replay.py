"""Independent seed-3405 R12 replay. Invoke --selftest without any label access."""
from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
import csv
from fractions import Fraction
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
import random
import sys

OUT = Path(__file__).parent
REPO = Path('/home/hxchen/research/GDA/TSBA/repository')
R12 = next((REPO/'experiments/mutagenicity').glob('r12_*'))
ACTIONS = Path('/tmp/r12-conditional-rank-blind/actions.csv')
EXPECTED = '7975e001e3b575c795c16dbef4a8f21808d97e85d63d56993db00bbe04543a9e'
SETTINGS = ('mutagenicity_edge', 'mutagenicity_node', 'proteins_edge')
DOMAINS = range(4)


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def exact_bytes(path, expected):
    data = path.read_bytes()
    if digest(data) != expected:
        raise ValueError(f'Checksum mismatch for {path}')
    return data


def anchor(z, setting):
    return (z % 2) if setting == 'proteins_edge' else (z // 2)


def read_actions():
    result = defaultdict(list)
    rows = csv.DictReader(io.StringIO(exact_bytes(ACTIONS, EXPECTED).decode('utf8')))
    for raw in rows:
        setting = raw.pop('setting')
        source = int(raw.pop('source'))
        target = int(raw.pop('target'))
        g = float(raw.pop('b0_margin'))
        row = {k:int(v) for k,v in raw.items()}
        row['g'] = g
        row['b'] = int(g > 0)
        assert row['anchor'] == anchor(row['z'], setting) and math.isfinite(g)
        result[setting, source, target].append(row)
    assert set(result) == {(s,a,b) for s in SETTINGS for a,b in itertools.permutations(DOMAINS,2)}
    return result


def pair_ranks(rows, with_b0):
    groups = defaultdict(list)
    for r in rows:
        key = (r['z'], r['b']) if with_b0 else r['z']
        groups[key].append(r)
    n = wins2 = hard2 = cover0 = cover1 = eligible = 0
    for cell in groups.values():
        pos = [r for r in cell if r['y']]
        neg = [r for r in cell if not r['y']]
        if pos and neg:
            cover0 += len(neg)
            cover1 += len(pos)
            eligible += 1
        for p, m in itertools.product(pos, neg):
            n += 1
            for col in ('g','b'):
                v = 2 * (p[col] > m[col]) + (p[col] == m[col])
                if col == 'g':
                    wins2 += v
                else:
                    hard2 += v
    total1 = sum(r['y'] for r in rows)
    return dict(n_pairs=n, correct_twice=wins2, hard_correct_twice=hard2,
                eligible_cells=eligible, covered_0=cover0, covered_1=cover1,
                n_0=len(rows)-total1, n_1=total1)


def fit(ref, base):
    if not ref:
        return None
    by_value = defaultdict(Counter)
    for score, y in ref:
        by_value[score][y] += 1
    correct = sum(p[0] for p in by_value.values())
    options = [(correct, 0)]
    top = 0
    for score in sorted(by_value, reverse=True):
        labels = by_value[score]
        top += sum(labels.values())
        correct += labels[1] - labels[0]
        options.append((correct, top))
    _, chosen = max(options, key=lambda r:(r[0], r[1] if base else -r[1]))
    return chosen, sorted(score for score,_ in ref)


def predict(model, query, base):
    if model is None:
        return base
    k, sorted_scores = model
    n = len(sorted_scores)
    if k == 0 or k == n:
        return int(k == n)
    # Mid-CDF vs (n-k)/n with the reference half as its own rank pool.
    q2 = bisect_left(sorted_scores, query) + bisect_right(sorted_scores, query)
    threshold2 = 2 * (n-k)
    if q2 == threshold2:
        return base
    return int(q2 > threshold2)


def majority(ys, base):
    twopos = 2 * sum(ys)
    return base if twopos == len(ys) else int(twopos > len(ys))


def fold_map(setting, target, ids):
    assert len(ids) == len(set(ids))
    def order(gid):
        b = f'r12-rank-half|{setting}|{target}|{gid}'.encode('utf-8')
        return hashlib.sha256(b).digest(), gid
    return {gid:p % 2 for p,gid in enumerate(sorted(ids, key=order))}


def half_predictions(rows, setting, folds):
    output = {}
    for ref_fold in (0,1):
        ref = [r for r in rows if folds[r['graph_id']] == ref_fold]
        query = [r for r in rows if folds[r['graph_id']] != ref_fold]
        for z in range(4):
            base = anchor(z, setting)
            group = [r for r in ref if r['z'] == z]
            model = fit([(r['g'], r['y']) for r in group], base)
            four = majority([r['y'] for r in group], base)
            eight = {b:majority([r['y'] for r in group if r['b']==b],base) for b in (0,1)}
            for r in query:
                if r['z'] == z:
                    assert r['graph_id'] not in output
                    output[r['graph_id']] = dict(rank=predict(model,r['g'],base),
                                                majority4=four, majority8=eight[r['b']])
    assert len(output) == len(rows)
    return output


def metrics(rows, method):
    tn,fp,fn,tp = (sum(r['y']==y and r[method]==p for r in rows)
                   for y,p in itertools.product((0,1), repeat=2))
    def safef1(a,b):
        return Fraction(2*a,2*a+b) if 2*a+b else Fraction()
    return dict(n=len(rows), correct=tn+tp, tn=tn,fp=fp,fn=fn,tp=tp,
                accuracy=float(Fraction(tn+tp,len(rows))),macro_f1=float((safef1(tn,fp+fn)+safef1(tp,fp+fn))/2))


def delta(rows, method, ref):
    corrected = sum(r[method]==r['y']!=r[ref] for r in rows)
    harmed = sum(r[ref]==r['y']!=r[method] for r in rows)
    return dict(n=len(rows), corrected=corrected,harmed=harmed,net=corrected-harmed,
                gain_pp=100*(corrected-harmed)/len(rows))


def decompose(rows):
    for z in range(4):
        matches = [r for r in rows if r['z'] == z]
        p = sum(r['y'] for r in matches)
        k = sum(r['OwnRank'] for r in matches)
        fp = sum(r['OwnRank']>r['y'] for r in matches)
        fn = sum(r['OwnRank']<r['y'] for r in matches)
        assert abs(p-k) + 2*min(fp,fn) == fp+fn
        yield dict(z=z,n=len(matches),p=p,k=k,fp=fp,fn=fn,
                   quota=abs(p-k),ordering=2*min(fp,fn),errors=fp+fn)


def validate_official(out, obs_sha, require_final):
    import numpy as np
    manifest = json.loads(exact_bytes(out/'OBS.json',obs_sha))
    members = {k:exact_bytes(out/k,h) for k,h in manifest['files'].items()}
    if require_final:
        final = json.loads((out/'FINAL.json').read_bytes())
        assert final['files']['OBS.json'] == obs_sha
        assert all(digest((out/k).read_bytes()) == v for k,v in final['files'].items())
        assert (out/'h-label-access.json').is_file()
    sealed_roles = json.loads(members['roles.json'])
    actions = read_actions()
    cohorts = {}
    folds = {}
    for (s,a,b), rows in actions.items():
        key = f'{s}-M{a}_to_M{b}-seed-3405'
        role = sealed_roles[key]
        ids = [r['graph_id'] for r in rows]
        assert ids == role['holdout_ids'] == role['ids']['holdout']
        assert not (set(ids) & set(role['ids']['adapt']))
        assert ids == cohorts.setdefault((s,b),ids)
        fold = folds.setdefault((s,b),fold_map(s,b,ids))
        with np.load(io.BytesIO(members[f'predictions/{key}.npz']), allow_pickle=False) as data:
            for field, col in [('ids','graph_id'),('g','g'),('z','z'),('Anchor','anchor'),('B0','b'),
                               *[(k,k) for k in ('SourceRank','SignMix','Other1','Other2','OwnRank')]]:
                np.testing.assert_array_equal(data[field], [r[col] for r in rows])
            np.testing.assert_array_equal(data['halves'], [fold[i] for i in ids])
            for r, c in zip(rows,data['Centered'],strict=True):
                r['Centered'] = int(c)
    assert len(cohorts)==12 and len(sealed_roles)==36
    return actions,sealed_roles,folds


def load_held(roles):
    sys.path.insert(0,str(REPO))
    from experiments.mutagenicity.r11_分类阈值的跨域检验_20261121.src import inputs
    from experiments.mutagenicity.r7_共同解释与共享更新验证_20261119.src import r5_inputs
    old_plan = json.loads((R12/'configs/conditional-votes.json').read_bytes())
    r10 = Path(old_plan['r10'])
    old_obs = json.loads(exact_bytes(r10/'OBS.json',old_plan['r10_obs_sha256']))
    run_path = 'executed-config.json'
    file_hash = old_obs['files'].get(run_path)
    if file_hash is None:
        fit_seal = json.loads(exact_bytes(r10/'FIT.json',old_plan['r10_fit_sha256']))
        file_hash = fit_seal['files'][run_path]
    r7 = Path(json.loads(exact_bytes(r10/run_path,file_hash))['plan']['r7_archive'])
    grants = {}
    for key, role in roles.items():
        task = {k:role[k] for k in ('setting','source','target','seed')}
        h = role['holdout_ids']
        manifest = json.loads(exact_bytes(r7/f'blocks/{key}/manifest.json',role['manifest_sha256']))
        assert role['ids'] == manifest['ids'] and h == manifest['ids']['holdout']
        ctx = r5_inputs._context(manifest['r7_plan'],**task,repository=REPO)
        if not (ctx['ids'] == role['ids'] and all(task[k]==manifest[k] for k in task)):
            raise PermissionError('H role reference changed')
        grant = inputs.raw_grant(ctx,manifest,'holdout')
        assert list(grant.ids)==h and grant.role=='holdout'
        cohort = task['setting'], task['target']
        assert grant == grants.setdefault(cohort,grant)
    held = {}
    with inputs.GraphLabelSession('holdout') as session:
        for cohort, grant in grants.items():
            y = session.load(grant,grant.ids)
            assert len(y) == len(grant.ids) and set(y.tolist()) <= {0,1}
            held[cohort] = dict(zip(grant.ids, map(int,y),strict=True))
    return held


def table(name, rows):
    with (OUT/f'{name}.csv').open('w') as f:
        writer = csv.DictWriter(f, list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run(out, obs_sha, require_final):
    actions,roles,folds = validate_official(out, obs_sha, require_final)
    labels = load_held(roles)
    pair_results, nets, metric_rows, cell_rows, half_rows = [], [], [], [], []
    for (setting,source,target), rows in actions.items():
        c = setting,target
        task = dict(setting=setting, source=source, target=target)
        for r in rows:
            r['y'] = labels[c][r['graph_id']]
        predicted = half_predictions(rows,setting,folds[c])
        for r in rows:
            r.update(predicted[r['graph_id']])
            half_rows.append(dict(**task,graph_id=r['graph_id'],half=folds[c][r['graph_id']],**predicted[r['graph_id']]))
        for extra in (False,True):
            pair_results.append(dict(**task,cells=(8 if extra else 4),**pair_ranks(rows,extra)))
        for name in ('rank','majority4','majority8','anchor','OwnRank','SourceRank','SignMix','Other1','Other2','Centered'):
            metric_rows.append(dict(**task,method=name,**metrics(rows,name)))
        for name, refs in (('OwnRank',('anchor','SourceRank','SignMix','Centered')),('rank',('majority4','majority8','anchor','Centered'))):
            for ref in refs:
                nets.append(dict(**task,method=name,ref=ref,**delta(rows,name,ref)))
        cell_rows.extend(dict(**task,**r) for r in decompose(rows))
    table('half-actions',half_rows)
    table('paired-ranks',pair_results)
    table('net-corrections',nets)
    table('direction-metrics',metric_rows)
    table('cell-errors',cell_rows)
    table('physical-folds',[dict(setting=s,target=b,graph_id=i,half=f) for (s,b),lookup in folds.items() for i,f in lookup.items()])
    def avg(xs):
        return float(sum(xs)/len(xs)) if xs else None
    summary = {}
    for s in SETTINGS:
        item = {}
        for cells in (4,8):
            rows = [r for r in pair_results if r['setting']==s and r['cells']==cells]
            valid = [r for r in rows if r['n_pairs']]
            ratios = lambda k:[Fraction(r[k],2*r['n_pairs']) for r in valid]
            item[f'pair{cells}'] = dict(dir=len(valid),pairs=sum(r['n_pairs'] for r in valid),g=avg(ratios('correct_twice')),
                                         b=avg(ratios('hard_correct_twice')),
                                         pooled_cov_pos=float(Fraction(sum(r['covered_1'] for r in rows),sum(r['n_1'] for r in rows))),
                                         pooled_cov_neg=float(Fraction(sum(r['covered_0'] for r in rows),sum(r['n_0'] for r in rows))),
                                         wins=sum(r['correct_twice']>r['hard_correct_twice'] for r in valid),
                                         pos=avg([Fraction(r['covered_1'],r['n_1']) for r in rows if r['n_1']]),
                                         neg=avg([Fraction(r['covered_0'],r['n_0']) for r in rows if r['n_0']]))
        for method,ref in sorted({(r['method'],r['ref']) for r in nets}):
            rows = [r for r in nets if (r['setting'],r['method'],r['ref'])==(s,method,ref)]
            item[f'{method}-vs-{ref}'] = dict(pp=avg([100*Fraction(r['net'],r['n']) for r in rows]),
                                              wins=sum(r['net']>0 for r in rows), ties=sum(r['net']==0 for r in rows),
                                              corrected=sum(r['corrected'] for r in rows),harmed=sum(r['harmed'] for r in rows))
        for method in sorted({r['method'] for r in metric_rows}):
            rows = [r for r in metric_rows if (r['setting'],r['method'])==(s,method)]
            item[method] = dict(accuracy=avg([Fraction(r['correct'],r['n']) for r in rows]),macro_f1=avg([r['macro_f1'] for r in rows]))
        summary[s] = item
    receipt = dict(obs_sha256=obs_sha,independent_actions_sha256=EXPECTED,access_role='holdout',
                   physical_cohorts=len(labels),unique_setting_target_graphs=sum(map(len,labels.values())),
                   directions=len(actions),replicated_direction_rows=sum(map(len,actions.values())),
                   script_sha256=digest(Path(__file__).read_bytes()),
                   output_sha256={f.name:digest(f.read_bytes()) for f in OUT.glob('*.csv')})
    (OUT/'score-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')


def selftest():
    rng = random.Random(1121)
    comparisons = 0
    for base in (0,1):
        assert predict(fit([],base), 1,base)==base
        for _ in range(300):
            data = [(rng.randrange(-2,3),rng.randrange(2)) for i in range(rng.randrange(1,17))]
            choices = {(tuple(int(g>cut) for g,y in data)) for cut in (-3,*sorted({p[0] for p in data}))}
            best = max(choices,key=lambda v:(sum(a==b for a,(_,b) in zip(v,data)), -sum(a!=base for a in v)))
            model = fit(data,base)
            assert sum(best)==model[0]
            assert [predict(model,g,base) for g,y in data]==list(best)
            for h in (-99,-2.5,-2,-1.5,-1,-.5,0,.5,1,1.5,2,2.5,99):
                n=len(data)
                k=sum(best)
                u = sum(Fraction((g<h)*2+(g==h),2*n) for g,y in data)
                cutoff = 1-Fraction(k,n)
                expected = int(k==n) if k in (0,n) else (base if u==cutoff else int(u>cutoff))
                assert predict(model,h,base)==expected
                comparisons += 1
    rows = [dict(graph_id=i,g=g,z=z,b=int(g>0),y=y) for i,(g,z,y) in enumerate([(2,0,1),(1,0,0),(1,0,1),(-1,0,0),(-2,1,1)])]
    four,eight = pair_ranks(rows,False),pair_ranks(rows,True)
    assert (four['n_pairs'], four['correct_twice'],four['hard_correct_twice'])==(4,7,6)
    assert (eight['n_pairs'], eight['correct_twice'],eight['hard_correct_twice'])==(2,3,2)
    assert (eight['covered_1'],eight['covered_0'])==(2,1)
    gids = [r['graph_id'] for r in rows]
    folds = fold_map('mutagenicity_edge',1,gids)
    assert folds == fold_map('mutagenicity_edge',1,gids[::-1]) and sorted(Counter(folds.values()).values()) == [2,3]
    for gid in gids:
        pred = half_predictions(rows,'mutagenicity_edge',folds)[gid]
        for r in rows:
            if folds[r['graph_id']] == folds[gid]:
                r['y'] = 1-r['y']
        assert half_predictions(rows,'mutagenicity_edge',folds)[gid] == pred
    print(json.dumps(dict(synthetic=True, rational_predictions_checked=comparisons, blind_actions_sha256=EXPECTED)))


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--selftest',action='store_true')
    parser.add_argument('--official-out',type=Path)
    parser.add_argument('--verified-obs-sha256')
    parser.add_argument('--parent-cleared',action='store_true',help='Use only following explicit parent verification with matching digest.')
    args = parser.parse_args()
    if args.selftest:
        selftest()
    elif args.official_out and args.verified_obs_sha256:
        run(args.official_out,args.verified_obs_sha256,not args.parent_cleared)
    else:
        parser.error('Need --selftest, or official attempt plus verified OBS checksum.')
