import csv
from fractions import Fraction
import hashlib
import io
import json
from pathlib import Path
import numpy as np
import torch

OUT = Path(__file__).parent
REPO = Path('/home/hxchen/research/GDA/TSBA/repository')
R12 = next((REPO/'experiments/mutagenicity').glob('r12_*'))
R12_RES = R12/'results/attempt-002-conditional-votes'
CFG = json.loads((R12/'configs/conditional-votes.json').read_bytes())
R16 = REPO/CFG['r16']
R10 = Path(CFG['r10'])
R11 = REPO/CFG['r11']
R5 = REPO.parent/'experiments/r5'
def digest(data):
    return hashlib.sha256(data).hexdigest()
def read(path, expected):
    raw = path.read_bytes()
    if digest(raw) != expected:
        raise ValueError(f'hash mismatch {path}')
    return raw
def parsed(path, expected):
    return json.loads(read(path,expected))
def members(root, filehashes, rel, names):
    with np.load(io.BytesIO(read(root/rel, filehashes[rel])), allow_pickle=False) as z:
        return {n:z[n] for n in names}
def write(name, rows):
    with (OUT/name).open('w') as f:
        s=csv.DictWriter(f,rows[0].keys())
        s.writeheader()
        s.writerows(rows)
def prepare(s,vz,vg,y):
    fit = {}
    for z in range(4):
        anchor = z%2 if s=='proteins_edge' else z//2
        mask = vz==z
        g,labels=vg[mask],y[mask]
        n=len(g)
        ans=[(0,int(sum(labels==0)))]
        for cutoff in sorted(set(g),reverse=True):
            top=g>=cutoff
            ans.append((int(top.sum()),int(np.sum(top==labels))))
        best=max(ans,key=lambda r:(r[1],r[0] if anchor else -r[0]))
        fit[z]=dict(n=n,k=best[0],correct=best[1],anchor=anchor,candidates=ans)
    return fit
def mid(pool,g):
    return Fraction(int(np.sum(pool<g))*2+int(np.sum(pool==g)), 2*len(pool))
def prediction(fit,z,g,reference,refz,vg,vz,mix):
    n,k,anchor=fit[z]['n'],fit[z]['k'],fit[z]['anchor']
    if n==0:
        return anchor
    if k in (0,n):
        return int(k==n)
    ref=reference[refz==z]
    if not len(ref):
        return prediction(fit,z,g,vg,vz,vg,vz,False)
    if mix:
        u=Fraction()
        for b in [0,1]:
            count=int(np.sum((ref>0)==b))
            if count:
                u+=Fraction(count,len(ref))*mid(reference[(reference>0)==b],g)
    else:
        u=mid(ref,g)
    q=Fraction(n-k,n)
    return int(u>q) if u!=q else anchor
def margin(logits):
    assert logits.ndim==2 and logits.shape[1]==2 and np.isfinite(logits).all()
    return logits[:,1]-logits[:,0]
f16=parsed(R16/'FIT.json',CFG['r16_fit_sha256'])['files']
f10=parsed(R10/'FIT.json',CFG['r10_fit_sha256'])['files']
h16=parsed(R16/'OBS.json',CFG['r16_obs_sha256'])['files']
h10=parsed(R10/'OBS.json',CFG['r10_obs_sha256'])['files']
a11=parsed(R11/'UNLABELED.json',CFG['r11_unlabeled_sha256'])['files']
oldcfg=json.loads((R12/'configs/reverse-vote-check.json').read_bytes())
f12=parsed(R12_RES/'OBS.json',oldcfg['historical_obs_sha256'])['files']
sources=parsed(R12_RES/'source-counts.json',f12['source-counts.json'])
roles=parsed(R12_RES/'roles.json',f12['roles.json'])
roles11=parsed(R11/'roles.json',a11['roles.json'])
roles16=parsed(R16/'prediction-roles.json',h16['prediction-roles.json'])
access10=parsed(R10/'fit-access.json',f10['fit-access.json'])
input_sha=parsed(R12_RES/'input-access.json',f12['input-access.json'])
r10plan=parsed(R10/'executed-config.json',f10['executed-config.json'])['plan']
r7=Path(r10plan['r7_archive'])
fits,enumeration,actions,counts,receipts=[],[],[],[],[]
SEED=3405
for setting in CFG['settings']:
    for source in CFG['domains']:
        group=f'{setting}-M{source}-seed-{SEED}'
        targets=sorted(set(CFG['domains'])-{source})
        ref=sources[group]
        rel=f'fits/{group}.json'
        model=parsed(R16/rel,f16[rel])
        lineage=access10[group]
        assert f16[rel]==ref['r16_fit_member_sha256'] and f10[rel]==ref['structure_sha256']==model['lineage']['model_sha256']
        assert (model['setting'],model['source'],model['seed'])==(setting,source,SEED)
        ids=ref['v_ids']
        assert model['validation_ids']==ids==lineage['validation_ids']
        assert len(ids)==len(set(ids))
        shav=ref['v_label_sha256']
        assert shav==model['source_label_sha256']['V']==lineage['v_label_sha256']
        root=R5/setting/'attempt-001'
        role=json.loads((root/f'roles/M{source}/seed3405.json').read_bytes())
        assert role['validation']==ids
        labels=torch.load(io.BytesIO(read(root/f'source_labels/M{source}/seed3405_validation.pt',shav)),map_location='cpu',weights_only=True).numpy()
        assert labels.shape==(len(ids),) and np.isin(labels,[0,1]).all()
        assert np.bincount(labels,minlength=2).tolist()==role['class_counts']['validation']
        vg,vwl,vsize=np.asarray(model['validation_margins'],dtype=float).T
        assert vg.shape==labels.shape and all(np.isfinite(v).all() for v in (vg,vwl,vsize))
        vb=4*(vsize>0)+2*(vg>0)+(vwl>0)
        np.testing.assert_array_equal(np.bincount(8*labels+vb,minlength=16).reshape(2,2,4),ref['counts'])
        vz=2*(vwl>0)+(vsize>0)
        fit=prepare(setting,vz,vg,labels)
        for z,row in fit.items():
            fits.append(dict(setting=setting,source=source,z=z,n=row['n'],k=row['k'],anchor=row['anchor'],correct=row['correct']))
            for k,c in row['candidates']:
                enumeration.append(dict(setting=setting,source=source,z=z,n=row['n'],k=k,correct=c,selected=int(k==row['k'])))
        data={}
        budget=min(len(roles[f'{setting}-M{source}_to_M{t}-seed-{SEED}']['ids']['adapt']) for t in targets)
        for target in targets:
            key=f'{setting}-M{source}_to_M{target}-seed-{SEED}'
            role,u_role,b_role = roles[key], roles11[key], roles16[key]
            mpath=f'blocks/{key}/manifest.json'
            manifest=parsed(r7/mpath,input_sha[mpath])
            assert manifest['ids']==role['ids'] and role['manifest_sha256']==u_role['manifest_sha256']==b_role['manifest_sha256']==input_sha[mpath]
            assert role['other_targets']==u_role['other_targets']==sorted(set(targets)-{target})
            assert role['ids']['validation']==ids and role['ids']['source']==lineage['source_ids']
            rel=f'predictions/{key}.npz'
            urel=f'deployment/{key}.npz'
            evidence=dict(r11_sha256=a11[urel],r10_sha256=h10[rel],r16_sha256=h16[rel],model_sha256=f10[f'fits/{group}.json'])
            assert role['evidence']==evidence
            assert b_role['r10_prediction_sha256']==h10[rel]==u_role['r10_h_member_sha256']
            old=members(R12_RES,f12,rel,['ids','h_bins','a_ids','a_bins','WL','Size','B0'])
            query=members(R16,h16,rel,['ids','logits_B0','logits_WL_selected','logits_Size'])
            h10raw=members(R10,h10,rel,['ids','logits_B0','logits_WL_selected','logits_Size'])
            for nm in query:
                np.testing.assert_array_equal(query[nm],h10raw[nm])
            deploy=members(R11,a11,urel,['ids','a_margin','a_size_margin','h_margin'])
            hids=role['holdout_ids']
            assert hids==role['ids']['holdout']==u_role['holdout_ids']==b_role['ids']
            for arr in [old['ids'],query['ids'],deploy['ids']]:
                np.testing.assert_array_equal(arr,hids)
            hg=margin(query['logits_B0'])
            hwl=margin(query['logits_WL_selected'])>0
            hsize=margin(query['logits_Size'])>0
            for arr,exp in [(hg>0,'B0'),(hwl,'WL'),(hsize,'Size'),(4*hsize+2*(hg>0)+hwl,'h_bins')]:
                np.testing.assert_array_equal(arr,old[exp])
            np.testing.assert_allclose(hg,deploy['h_margin'],rtol=0,atol=1e-12)
            hz=2*hwl+hsize
            aid=role['selected_a_ids']
            assert aid==u_role['selected_a_ids']==sorted(role['ids']['adapt'],key=lambda gid:(digest(f'r11-v1|{setting}|{gid}'.encode()),gid))[:budget]
            assert not (set(aid)&set(hids))
            np.testing.assert_array_equal(old['a_ids'],aid)
            ag=deploy['a_margin']
            av=old['a_bins']
            assert av.shape==ag.shape==(len(aid),) and np.isin(av,np.arange(8)).all() and np.isfinite(ag).all()
            np.testing.assert_array_equal(ag>0,(av//2)%2)
            np.testing.assert_array_equal(deploy['a_size_margin']>0,av//4)
            afile=f'blocks/{key}/fit_input.npz'
            r7a=members(r7,input_sha,afile,['adapt_ids','adapt_z0'])
            np.testing.assert_array_equal(r7a['adapt_ids'],role['ids']['adapt'])
            idx={int(g):i for i,g in enumerate(r7a['adapt_ids'])}
            orig=margin(r7a['adapt_z0'])[[idx[i] for i in aid]]
            np.testing.assert_allclose(ag,orig,atol=1e-12,rtol=0)
            np.testing.assert_array_equal(ag>0,orig>0)
            vfile=f'blocks/{key}/validation_input.npz'
            if vfile not in input_sha:
                r7_inputs=json.loads((r7/'seals/R7_INPUT.json').read_bytes())
                vhash=r7_inputs['files']
            else:
                vhash=input_sha
            r7v=members(r7,vhash,vfile,['validation_ids','validation_z0'])
            np.testing.assert_array_equal(r7v['validation_ids'],ids)
            np.testing.assert_array_equal(margin(r7v['validation_z0']),vg)
            data[target]=(aid,ag,2*(av%2)+av//4,hids,hg,hz)
            receipts.append(dict(setting=setting,source=source,target=target,nV=len(ids),nA=len(aid),nH=len(hids),**evidence,V_label_sha256=shav,source_counts_sha256=f12['source-counts.json'],R12_votes_sha256=f12[rel],manifest_sha256=input_sha[mpath],R7_V_hash=vhash[vfile],R7_A_hash=input_sha[afile]))
        for target in targets:
            aid,ag,az,hids,hg,hz=data[target]
            others=sorted(set(targets)-{target})
            domains=[('OwnRank',ag,az,False),('SourceRank',vg,vz,False),('SignMix',ag,az,True)]+[(f'Other{i+1}',*data[t][1:3],False) for i,t in enumerate(others)]
            direction=[]
            for gid,g,z in zip(hids,hg,hz,strict=True):
                row=dict(setting=setting,source=source,target=target,graph_id=gid,z=int(z),b0_margin=g,anchor=fit[z]['anchor'])
                for policy,pool,pz,mix in domains:
                    row[policy]=prediction(fit,z,g,pool,pz,vg,vz,mix)
                direction.append(row)
            actions.extend(direction)
            methods=[m[0] for m in domains]
            d=dict(setting=setting,source=source,target=target,n=len(hids),Other1_pool=others[0],Other2_pool=others[1])
            d.update({m+'_positive':sum(row[m] for row in direction) for m in ['anchor',*methods]})
            d.update({'Own_vs_'+m:sum(row[m]!=row['OwnRank'] for row in direction) for m in ['anchor',*methods[1:]]})
            counts.append(d)
write('source-k.csv',fits)
write('all-candidates.csv',enumeration)
write('actions.csv',actions)
write('direction-counts.csv',counts)
write('input-receipts.csv',receipts)
assert len(counts)==36 and len(fits)==48 and len(set((r['setting'],r['source'],r['target'],r['graph_id']) for r in actions))==len(actions)
seal={'registration':'735e661','script_sha256':digest((OUT/'blind.py').read_bytes()),'files':{n:digest((OUT/n).read_bytes()) for n in ['source-k.csv','all-candidates.csv','actions.csv','direction-counts.csv','input-receipts.csv']}}
(OUT/'freeze.json').write_text(json.dumps(seal,indent=2)+'\n')
print('rows',len(actions),'directions',len(counts),'source cells',len(fits),'k candidates',len(enumeration))
for s in CFG['settings']:
    records=[d for d in counts if d['setting']==s]
    print(s, {k:[sum(d[k] for d in records),sum(d[k]>0 for d in records)] for k in records[0] if k.startswith('Own_vs_')})
print('seal',digest((OUT/'freeze.json').read_bytes()))
