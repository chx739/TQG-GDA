"""Compare independent replay outputs to official FINAL without touching raw labels."""
import argparse
from collections import defaultdict, Counter
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).parent
args = argparse.ArgumentParser()
args.add_argument('official',type=Path)
args.add_argument('--final-sha256',required=True)
options = args.parse_args()
official = options.official


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(root,file):
    with (root/file).open() as f:
        return list(csv.DictReader(f))


def task(row):
    return row['setting'],row['source'],row['target']


def index(rows, keys):
    d = {}
    for r in rows:
        key = (*task(r),*[r[k] for k in keys])
        assert key not in d
        d[key] = r
    return d


def same(a,b):
    assert Fraction(a) == Fraction(b),(a,b)


checks = Counter()
assert digest(official/'FINAL.json')==options.final_sha256
final = json.loads((official/'FINAL.json').read_bytes())
assert all(digest(official/k)==v for k,v in final['files'].items())
receipt = json.loads((ROOT/'score-receipt.json').read_bytes())
assert final['files']['OBS.json']==receipt['obs_sha256']
assert all(digest(ROOT/k)==v for k,v in receipt['output_sha256'].items())

arms = {'rank':'HalfRank','majority4':'HalfFour','majority8':'HalfEight','anchor':'Anchor'}
directions=index(read(official,'ranking-directions.csv'),('scope','method'))
for r in read(ROOT,'paired-ranks.csv'):
    scope = 'same_all_three' if r['cells']=='8' else 'same_WL_Size'
    for k,m in (('correct_twice','continuous_B0'),('hard_correct_twice','hard_B0')):
        ref=directions[*task(r),scope,m]
        for f,g in ((k,'credit_twice'),('n_pairs','pairs'),('covered_0','covered_0'),('covered_1','covered_1'),
                    ('n_0','negative'),('n_1','positive')):
            same(r[f],ref[g])
        checks['rank_direction_method_rows']+=1
bycell=index(read(official,'cell-errors.csv'),('method','z'))
for r in read(ROOT,'cell-errors.csv'):
    ref=bycell[*task(r),'OwnRank',r['z']]
    for f,g in (('n','n'),('p','P'),('k','K'),('fp','fp'),('fn','fn'),('errors','errors'),('quota','count_gap'),('ordering','ranking_errors')):
        same(r[f],ref[g])
    checks['own_cell_decompositions']+=1
endpoints=index(read(official,'endpoints.csv'),('method',))
for r in read(ROOT,'direction-metrics.csv'):
    ref=endpoints[*task(r),arms.get(r['method'],r['method'])]
    for f in ('tn','fp','fn','tp','n'):
        same(r[f],ref[f])
    same(Fraction(int(r['correct']),int(r['n'])),ref['accuracy_exact'])
    assert abs(float(r['macro_f1'])-float(ref['macro_f1'])) < 5e-15
    checks['direction_endpoints']+=1
pairs=index(read(official,'paired-blocks.csv'),('left','right'))
for r in read(ROOT,'net-corrections.csv'):
    key=(*task(r),arms.get(r['method'],r['method']),arms.get(r['ref'],r['ref']))
    if key not in pairs:
        assert key[-2:]==('HalfRank','Centered')
        continue
    ref=pairs[key]
    for f in ('corrected','harmed','n'):
        same(r[f],ref[f])
    same(Fraction(int(r['net']),int(r['n'])),ref['accuracy_exact'])
    checks['direction_correction_contrasts']+=1
actions=defaultdict(list)
for r in read(ROOT,'half-actions.csv'):
    actions[task(r)].append(r)
for (s,a,b),group in actions.items():
    with np.load(official/f'half-diagnostic/{s}-M{a}_to_M{b}-seed-3405.npz',allow_pickle=False) as d:
        for f,g in [('graph_id','ids'),('half','halves'),*[(f,g) for f,g in arms.items() if f!='anchor']]:
            np.testing.assert_array_equal([int(r[f]) for r in group],d[g])
        checks['direction_graph_assignments']+=len(group)
        checks['all_three_supervised_graph_actions']+=3*len(group)
data=dict(official_final_sha256=options.final_sha256,official_obs_sha256=receipt['obs_sha256'],
          independent_actions_sha256=receipt['independent_actions_sha256'],checks=checks,match=True)
(ROOT/'official-comparison.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data))
