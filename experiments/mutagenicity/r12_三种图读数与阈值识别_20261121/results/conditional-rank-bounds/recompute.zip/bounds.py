"""Bound conditional-rank accuracy gains from frozen actions and eight-cell counts.

The direction-level bound treats each direction's assignments independently.
The shared bound enforces all sources' published marginals on the same physical
target graphs. Each comparator is optimized separately. Neither the extreme
win counts nor the extreme means imply simultaneous attainability of other
endpoints. All displayed "exact" mean gains are rational percentage points.

Run --help for the input contract and --self-test for an exhaustive example.
"""
import argparse
from collections import Counter, defaultdict
import csv
from dataclasses import dataclass
from fractions import Fraction
import hashlib
import io
from itertools import combinations, product
import json
from math import isfinite
from pathlib import Path

import numpy as np
import scipy
from scipy.optimize import Bounds, LinearConstraint, milp


CONTROLS = ('anchor', 'SourceRank', 'SignMix')
CELLS = tuple(product((0, 1), repeat=3))  # (Size, B0, WL)
ANCHOR_INDEX = {'mutagenicity_edge': 2, 'mutagenicity_node': 2, 'proteins_edge': 0}
INDEX_COLUMNS = {'setting', 'source', 'target'}
COUNT_COLUMNS = INDEX_COLUMNS | {'size', 'b0', 'wl', 'graphs', 'true_0', 'true_1', 'seed'}
ACTION_COLUMNS = INDEX_COLUMNS | {'graph_id', 'z', 'b0_margin', 'OwnRank', *CONTROLS}


@dataclass(frozen=True)
class Action:
    cell: tuple
    differences: tuple  # OwnRank minus each control, prior to scoring


def read_csv(path, required, expected_sha):
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if expected_sha and digest != expected_sha.lower():
        raise ValueError(f'{path.name}: SHA-256 mismatch')
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig'), newline=''), strict=True)
    header = reader.fieldnames or []
    if len(header) != len(set(header)) or not required.issubset(header):
        raise ValueError(f'{path.name}: duplicate column or missing required columns {sorted(required - set(header))}')
    rows = []
    for number, row in enumerate(reader, 2):
        if None in row or any(value is None for value in row.values()):
            raise ValueError(f'{path.name}: wrong column count at row {number}')
        rows.append({name: row[name] for name in required})
    if not rows:
        raise ValueError(f'{path.name}: no data rows')
    return rows, digest


def nonnegative(value):
    number = int(value)
    if number < 0:
        raise ValueError('negative ID, label count or cell capacity')
    return number


def bit(value):
    number = int(value)
    if number not in (0, 1):
        raise ValueError('classification and vote fields must be 0 or 1')
    return number


def direction(row):
    setting, source, target = row['setting'], nonnegative(row['source']), nonnegative(row['target'])
    if setting not in ANCHOR_INDEX or source == target:
        raise ValueError(f'invalid transfer direction {(setting, source, target)}')
    return setting, source, target


def parse_inputs(count_rows, action_rows):
    cells = defaultdict(dict)
    seeds = {nonnegative(row['seed']) for row in count_rows}
    if len(seeds) != 1:
        raise ValueError('the published counts must describe one seed')
    for row in count_rows:
        key = direction(row)
        cell = tuple(bit(row[name]) for name in ('size', 'b0', 'wl'))
        positive, negative, total = (nonnegative(row[name]) for name in ('true_1', 'true_0', 'graphs'))
        if cell in cells[key] or positive + negative != total:
            raise ValueError(f'{key}, {cell}: duplicate cell or class counts inconsistent with capacity')
        cells[key][cell] = (positive, total)

    actions = defaultdict(dict)
    for row in action_rows:
        key = direction(row)
        gid, z = nonnegative(row['graph_id']), nonnegative(row['z'])
        margin = float(row['b0_margin'])
        if z > 3 or not isfinite(margin) or gid in actions[key]:
            raise ValueError(f'{key}: invalid z, margin, or duplicate graph in action table')
        cell = (z % 2, int(margin > 0), z // 2)
        if bit(row['anchor']) != cell[ANCHOR_INDEX[key[0]]]:
            raise ValueError(f'{key}: anchor inconsistent with WL/Size vote')
        own = bit(row['OwnRank'])
        actions[key][gid] = Action(cell, tuple(own - bit(row[control]) for control in CONTROLS))

    if not cells or set(cells) != set(actions):
        raise ValueError('direction lists differ between the two inputs')
    for key, marginals in cells.items():
        if set(marginals) != set(CELLS):
            raise ValueError(f'{key}: all eight published cells are required, including empty cells')
        capacities = Counter(action.cell for action in actions[key].values())
        if any(capacities[cell] != total for cell, (_, total) in marginals.items()):
            raise ValueError(f'{key}: action counts disagree with published cell capacities')
        if not sum(capacities.values()):
            raise ValueError(f'{key}: zero denominator for direction accuracy')

    by_target = defaultdict(list)
    for setting, source, target in sorted(cells):
        by_target[setting, target].append(source)
    for setting in sorted({key[0] for key in cells}):
        domains = {value for s, src, tar in cells if s == setting for value in (src, tar)}
        used_ids = set()
        for target in sorted(domains):
            sources = by_target[setting, target]
            if sources != sorted(domains - {target}):
                raise ValueError(f'{setting}, {target}: incomplete source-to-target grid')
            keys = [(setting, src, target) for src in sources]
            ids = actions[keys[0]].keys()
            if any(actions[key].keys() != ids for key in keys):
                raise ValueError(f'{setting}, {target}: physical H IDs differ between sources')
            if used_ids.intersection(ids):
                raise ValueError(f'{setting}: different target domains share H IDs')
            used_ids.update(ids)
            positive_totals = {sum(p for p, _ in cells[key].values()) for key in keys}
            if len(positive_totals) != 1:
                raise ValueError(f'{setting}, {target}: shared target positive totals disagree')
    return cells, actions, by_target


def closed_form(positive, up, down, tied):
    """All negatives give down-up net wins. Place P positives in order +/0/- or -/0/+."""
    baseline = down - up
    minimum = baseline + 2 * (max(0, positive - down - tied) - min(down, positive))
    maximum = baseline + 2 * (min(up, positive) - max(0, positive - up - tied))
    return minimum, maximum


def direction_bounds(cells, actions):
    cell_rows, direction_rows = [], []
    for (setting, source, target), marginals in sorted(cells.items()):
        key = (setting, source, target)
        for i, control in enumerate(CONTROLS):
            counts = Counter((a.cell, a.differences[i]) for a in actions[key].values())
            low = high = 0
            meta = dict(setting=setting, source=source, target=target, control=control)
            for cell in CELLS:
                p, n = marginals[cell]
                up, down, tied = (counts[cell, sign] for sign in (1, -1, 0))
                lo, hi = closed_form(p, up, down, tied)
                cell_rows.append(dict(**meta, size=cell[0], b0=cell[1], wl=cell[2], n=n, p=p,
                                      own1_ctrl0=up, own0_ctrl1=down, ties=tied, lo=lo, hi=hi))
                low += lo
                high += hi
            direction_rows.append(dict(**meta, n=len(actions[key]), lo=low, hi=high))
    return cell_rows, direction_rows


def integer_minimum(cost, capacities, constraints):
    """Run integer HiGHS, recheck the primal and integer objective bound. Return only the optimum."""
    solution = milp(cost, integrality=np.ones(len(cost)), bounds=Bounds(0, capacities),
                    constraints=constraints, options={'mip_rel_gap': 0.0, 'presolve': False})
    if solution.status == 2:
        return None
    if not solution.success:
        raise RuntimeError(f'integer optimization failed: {solution.message}')
    primal = np.rint(solution.x).astype(np.int64)
    if np.any(primal < 0) or np.any(primal > capacities):
        raise RuntimeError('integer solver returned a point outside the capacities')
    for constraint in constraints:
        value = constraint.A @ primal
        if np.any(value < constraint.lb) or np.any(value > constraint.ub):
            raise RuntimeError('integer solver returned a point outside the published constraints')
    objective = int(cost @ primal)
    # An integer optimum cannot lie strictly between objective-1 and objective.
    dual = solution.mip_dual_bound
    if abs(objective - solution.fun) > 1e-6 or not objective - 1 + 1e-6 < dual <= objective + 1e-6:
        raise RuntimeError('integer solver did not certify the objective to one integer unit')
    return objective


def most_compatible(delta, offsets, capacities, constraints, wins):
    """Test all subsets of sources in descending size, with gain >=1 (win) or <=0 (nonwin)."""
    n_sources, n_signatures = delta.shape
    for size in range(n_sources, 0, -1):
        for subset in combinations(range(n_sources), size):
            extra = []
            for i in subset:
                lo, hi = (1 - offsets[i], np.inf) if wins else (-np.inf, -offsets[i])
                extra.append(LinearConstraint(2 * delta[i], lo, hi))
            if integer_minimum(np.zeros(n_signatures, dtype=int), capacities, constraints + extra) is not None:
                return size
    return 0


def shared_target_bounds(cells, actions, by_target):
    result = []
    for setting in sorted({key[0] for key in cells}):
        targets = sorted(t for s, t in by_target if s == setting)
        for i, control in enumerate(CONTROLS):
            for target in targets:
                sources = by_target[setting, target]
                keys = [(setting, src, target) for src in sources]
                # A variable is the positive count in a joint signature, bounded by its multiplicity.
                signatures = Counter()
                for gid in actions[keys[0]]:
                    features = [actions[key][gid] for key in keys]
                    signatures[tuple((a.cell, a.differences[i]) for a in features)] += 1
                patterns = sorted(signatures)
                capacities = np.array([signatures[pat] for pat in patterns], dtype=np.int64)
                delta = np.array([[pat[j][1] for pat in patterns] for j in range(len(keys))], dtype=np.int64)
                constraints = []
                for j, key in enumerate(keys):
                    for cell, (positive, total) in cells[key].items():
                        members = np.array([int(pat[j][0] == cell) for pat in patterns])
                        if int(members @ capacities) != total:
                            raise ValueError(f'{key}, {cell}: joint signature capacities disagree with published counts')
                        constraints.append(LinearConstraint(members, positive, positive))
                # Direction j has net gain delta[j] @ (2*positive_counts-capacities).
                offsets = -(delta @ capacities)
                cost = 2 * delta.sum(axis=0)
                minimum = integer_minimum(cost, capacities, constraints)
                maximum_neg = integer_minimum(-cost, capacities, constraints)
                if minimum is None or maximum_neg is None:
                    raise ValueError(f'{setting}, {target}: no assignment satisfies all source marginals')
                min_wins = len(keys) - most_compatible(delta, offsets, capacities, constraints, False)
                max_wins = most_compatible(delta, offsets, capacities, constraints, True)
                result.append(dict(setting=setting, target=target, control=control, n=int(capacities.sum()),
                                   groups=len(patterns), min_net=int(offsets.sum()) + minimum,
                                   max_net=int(offsets.sum()) - maximum_neg, min_wins=min_wins, max_wins=max_wins))
    return result


def summarize(direction_rows, shared_rows):
    independent, shared = [], []
    for setting in sorted({r['setting'] for r in direction_rows}):
        for control in CONTROLS:
            directions = [r for r in direction_rows if (r['setting'], r['control']) == (setting, control)]
            targets = [r for r in shared_rows if (r['setting'], r['control']) == (setting, control)]
            for scope, rows, low, high in (('direction', directions, 'lo', 'hi'),
                                           ('target', targets, 'min_net', 'max_net')):
                lo = sum(Fraction(r[low], r['n']) for r in rows) * 100 / len(directions)
                hi = sum(Fraction(r[high], r['n']) for r in rows) * 100 / len(directions)
                if scope == 'direction':
                    independent.append(dict(setting=setting, control=control,
                                            min_wins=sum(r[low] > 0 for r in rows),
                                            max_wins=sum(r[high] > 0 for r in rows),
                                            lo_pp=float(lo), lo_exact=str(lo), hi_pp=float(hi), hi_exact=str(hi)))
                else:
                    shared.append(dict(setting=setting, control=control,
                                       min_wins=sum(r['min_wins'] for r in rows),
                                       max_wins=sum(r['max_wins'] for r in rows),
                                       lo_pp=float(lo), hi_pp=float(hi), lo_exact=str(lo), hi_exact=str(hi)))
    return independent, shared


def calculate(count_rows, action_rows):
    cells, actions, by_target = parse_inputs(count_rows, action_rows)
    cell_rows, directions = direction_bounds(cells, actions)
    targets = shared_target_bounds(cells, actions, by_target)
    independent, shared = summarize(directions, targets)
    return {'cell-bounds.csv': cell_rows, 'direction-bounds.csv': directions, 'setting-bounds.csv': independent,
            'shared-target-bounds.csv': targets, 'shared-setting-bounds.csv': shared}


def self_test():
    """Two sources per target. On target 0 the sources flip disjoint halves against Anchor."""
    setting = 'mutagenicity_edge'
    count_rows, action_rows = [], []
    for target, n in enumerate((4, 5, 6)):
        for j, source in enumerate(src for src in range(3) if src != target):
            bins = defaultdict(list)
            for g in range(n):
                # Use toy classes only to construct the aggregate input to the test.
                y = int(g % 3 != 0)
                z = 0 if target == 0 else (g + j) % 4
                margin = -1 if target == 0 else (g + 2 * j) % 3 - 1
                own = int((g < 2) != bool(j)) if target == 0 else int((g + j) % 3 == 0)
                anchor = z // 2
                cell = (z % 2, int(margin > 0), anchor)
                bins[cell].append(y)
                action_rows.append(dict(setting=setting, source=source, target=target, graph_id=100 * target + g,
                                        z=z, b0_margin=margin, anchor=anchor, OwnRank=own,
                                        SourceRank=1 - own, SignMix=int(g % 2 == 0)))
            for cell in CELLS:
                y = bins[cell]
                count_rows.append(dict(setting=setting, source=source, target=target, seed=1, size=cell[0],
                                       b0=cell[1], wl=cell[2], graphs=len(y), true_0=y.count(0), true_1=sum(y)))
    tables = calculate(count_rows, action_rows)
    cells, actions, by_target = parse_inputs(count_rows, action_rows)
    expected = {}
    for target, n in enumerate((4, 5, 6)):
        keys = [(setting, src, target) for src in by_target[setting, target]]
        gids = sorted(actions[keys[0]])
        allowed = []
        for key in keys:
            valid = set()
            for assignment in product((0, 1), repeat=n):
                positive_counts = Counter(actions[key][gid].cell for gid, y in zip(gids, assignment) if y)
                if all(positive_counts[cell] == p for cell, (p, _) in cells[key].items()):
                    valid.add(assignment)
            allowed.append(valid)
        common = set.intersection(*allowed)
        for i, control in enumerate(CONTROLS):
            def net(key, assignment):
                return sum(actions[key][gid].differences[i] * (2 * y - 1) for gid, y in zip(gids, assignment))
            for key, valid in zip(keys, allowed):
                gains = [net(key, assignment) for assignment in valid]
                row = next(r for r in tables['direction-bounds.csv'] if
                           (r['setting'], r['source'], r['target'], r['control']) == (*key, control))
                if (row['lo'], row['hi']) != (min(gains), max(gains)):
                    raise RuntimeError('exhaustive direction check failed')
            gains = [[net(key, assignment) for key in keys] for assignment in common]
            sums, wins = [sum(vec) for vec in gains], [sum(g > 0 for g in vec) for vec in gains]
            row = next(r for r in tables['shared-target-bounds.csv'] if (r['target'], r['control']) == (target, control))
            expected[target, control] = (min(sums), max(sums), min(wins), max(wins))
            if tuple(row[k] for k in ('min_net', 'max_net', 'min_wins', 'max_wins')) != expected[target, control]:
                raise RuntimeError('exhaustive shared-target check failed')
    for row in tables['shared-setting-bounds.csv']:
        control = row['control']
        for k, endpoint in enumerate(('lo_exact', 'hi_exact')):
            val = sum(Fraction(expected[t, control][k], 4 + t) for t in range(3)) * 100 / 6
            if val != Fraction(row[endpoint]):
                raise RuntimeError('unequal target denominators were not weighted by direction')
    toy = expected[0, 'anchor']
    if toy != (0, 0, 0, 1):
        raise RuntimeError(f'unexpected exhaustive result on opposing source flips: {toy}')
    def expect_invalid(counts, acts, message):
        try:
            calculate(counts, acts)
        except ValueError as error:
            if message not in str(error):
                raise RuntimeError(f'unexpected input rejection: {error}') from error
            return
        raise RuntimeError(f'invalid test data accepted: {message}')

    expect_invalid([dict(count_rows[0], graphs=-1), *count_rows[1:]], action_rows, 'negative')
    expect_invalid(count_rows, [dict(action_rows[0], graph_id=999), *action_rows[1:]], 'physical H IDs')
    # Give both sources identical cells on target 0 but opposite class counts in them.
    # All capacities and the physical target positive total still agree.
    bad_actions = [dict(r, z=int(r['graph_id'] < 2)) if r['target'] == 0 else r for r in action_rows]
    bad_counts = []
    for r in count_rows:
        if r['target'] == 0 and r['b0'] == 0 and r['wl'] == 0:
            p = 2 * int(r['size'] == (r['source'] - 1))
            bad_counts.append(dict(r, graphs=2, true_0=2-p, true_1=p))
        else:
            bad_counts.append(r)
    expect_invalid(bad_counts, bad_actions, 'no assignment satisfies')
    print('Passed exhaustive 4-, 5-, and 6-graph examples and invalid-input checks.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workdir', type=Path, help='existing directory used to resolve all relative paths')
    parser.add_argument('--actions', type=Path, help='independently frozen actions CSV')
    parser.add_argument('--h-cells', type=Path, help='published R12-002 eight-cell true class counts CSV')
    parser.add_argument('--output', type=Path, help='directory for the five bound tables and the input receipt')
    parser.add_argument('--actions-sha256', help='verify actions bytes against this external SHA-256 receipt')
    parser.add_argument('--h-cells-sha256', help='verify the published counts against this external SHA-256 receipt')
    parser.add_argument('--self-test', action='store_true', help='run exhaustive synthetic examples, without inputs or writes')
    args = parser.parse_args()
    if args.self_test:
        if any((args.workdir, args.actions, args.h_cells, args.output, args.actions_sha256, args.h_cells_sha256)):
            parser.error('--self-test is a standalone check')
        self_test()
        return
    if not all((args.workdir, args.actions, args.h_cells, args.output)):
        parser.error('--workdir, --actions, --h-cells, and --output are required')
    root = args.workdir.resolve(strict=True)
    if not root.is_dir():
        parser.error('--workdir must identify a directory')
    actions_path, cells_path, output = ((root / value).resolve() for value in (args.actions, args.h_cells, args.output))
    counts, counts_sha = read_csv(cells_path, COUNT_COLUMNS, args.h_cells_sha256)
    actions, actions_sha = read_csv(actions_path, ACTION_COLUMNS, args.actions_sha256)
    tables = calculate(counts, actions)
    if {actions_path, cells_path}.intersection((output / name).resolve() for name in (*tables, 'inputs.json')):
        parser.error('an output path collides with an input file')
    output.mkdir(parents=True, exist_ok=True)
    for name, rows in tables.items():
        with (output / name).open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)
    receipt = dict(actions_sha256=actions_sha, h_cells_sha256=counts_sha, actions=len(actions), h_cells=len(counts),
                   seed=int(counts[0]['seed']), directions=len(tables['direction-bounds.csv']) // len(CONTROLS),
                   numpy_version=np.__version__, scipy_version=scipy.__version__)
    (output / 'inputs.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
