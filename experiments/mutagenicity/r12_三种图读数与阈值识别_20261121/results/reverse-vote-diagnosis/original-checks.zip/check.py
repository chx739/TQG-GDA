"""Independent exact checks from frozen voting tables and archived cell/endpoint totals."""
import argparse
import csv
import hashlib
import io
import itertools
import json
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
from statistics import mean

SETTINGS = ('mutagenicity_edge', 'mutagenicity_node', 'proteins_edge')
DOM = range(4)
HIST = ('WL', 'Size', 'B0', 'B', 'B2', 'PoolMajority', 'DirectP')
LOCAL = ('Reverse', 'Direct', 'PermMean', 'RowPerm')
HIST_OBS = 'fde4616cad09f0c9c184a2feeeec9d1c243ddae14ad56755b5ec10a8cfb05d51'
HIST_FINAL = '5bab66c3071e4f3a34c694daf2ad3fcdd30604f4716b0e18a7ca73766d401c69'

def task_id(setting, source, target):
    return f'{setting}-M{source}_to_M{target}-seed-3405'

def tasks():
    return {task_id(g,s,t):(g,s,t) for g in SETTINGS for s,t in itertools.permutations(DOM,2)}

def table_mask(i):
    assert type(i) is int and 0<=i<16
    return [(i>>z)&1 for z in DOM]

def smoothed_top(v, h, positive):
    """Return marginal selection probabilities for a uniform cut across entire equal-score groups."""
    n=sum(map(sum,h)); assert 0<=positive<=n
    rates=[F(c1*2+1, (c0+c1+1)*2) for c0,c1 in v]
    result=[]
    for z, rate in enumerate(rates):
        better=sum(sum(c) for c,x in zip(h,rates) if x>rate)
        equal=sum(sum(c) for c,x in zip(h,rates) if x==rate)
        result.append(F(min(equal,max(0,positive-better)),equal) if equal else F(0))
    assert sum(q*sum(c) for q,c in zip(result,h))==positive
    return result

def confusion(h, pol):
    tn=sum(x*(1-p) for (x,_),p in zip(h,pol)); fp=sum(x*p for (x,_),p in zip(h,pol))
    fn=sum(y*(1-p) for (_,y),p in zip(h,pol)); tp=sum(y*p for (_,y),p in zip(h,pol))
    return tn,fp,fn,tp

def metrics(conf):
    tn,fp,fn,tp=map(F,conf); n=tn+fp+fn+tp
    f0=tn/(2*tn+fp+fn) if 2*tn+fp+fn else F(0)
    f1=tp/(2*tp+fp+fn) if 2*tp+fp+fn else F(0)
    return dict(n=n,tn=tn,fp=fp,fn=fn,tp=tp,positive=fp+tp,correct=tn+tp,accuracy=(tn+tp)/n,
                macro_f1=f0+f1,recall_0=tn/(tn+fp) if tn+fp else None,recall_1=tp/(tp+fn) if tp+fn else None)

def paired(h,new,old):
    assert set(new)<={0,1} and all(0<=q<=1 for q in old)
    gain=loss=0
    for (neg,pos),a,b in zip(h,new,old):
        change=1-b if a else b
        gain+=change*(pos if a else neg)
        loss+=change*(neg if a else pos)
    return dict(corrected=gain,harmed=loss,changed=gain+loss,net=gain-loss)

def table_accuracies(h):
    n=sum(map(sum,h))
    return [F(sum(cell[decision] for cell,decision in zip(h,table_mask(m))),n) for m in range(16)]

def winners(scores,anchor):
    top=max(scores)
    ties=[k for k,acc in enumerate(scores) if acc==top]
    # The protocol only fixes the oracle value; retain every maximizer.
    short=min(ties,key=lambda m:((anchor^m).bit_count(),m))
    return dict(maximum=top,tables=ties,anchor_tiebreak=short)

def load_bytes(path,sha):
    data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()==sha, str(path)
    return data

def json_member(path,sha):
    return json.loads(load_bytes(path,sha))

def csv_load(data):
    return list(csv.DictReader(io.StringIO(data.decode())))

def load_history(old):
    final=json_member(old/'FINAL.json',HIST_FINAL)
    assert final['stage']=='FINAL' and final['files']['OBS.json']==HIST_OBS and final['predecessors']['obs_sha256']==HIST_OBS
    obs=json_member(old/'OBS.json',HIST_OBS)
    roles=json_member(old/'roles.json',obs['files']['roles.json'])
    sources=json_member(old/'source-counts.json',obs['files']['source-counts.json'])
    canon_v={}
    for k,r in roles.items():
        original=sources[r['group']]['counts']
        v=[[0,0] for _ in DOM]
        for y,sz,b0,wl in itertools.product(range(2),repeat=4):
            v[2*wl+sz][y]+=int(original[y][sz][2*b0+wl])
        assert sum(map(sum,v))==len(sources[r['group']]['v_ids'])
        canon_v[k]=v
    cells=csv_load(load_bytes(old/'h-cells.csv',final['files']['h-cells.csv']))
    ends=csv_load(load_bytes(old/'endpoints.csv',final['files']['endpoints.csv']))
    return aggregate(cells,ends,roles),canon_v

def row_id(r):
    assert int(r['seed'])==3405
    return task_id(r['setting'],int(r['source']),int(r['target']))

def aggregate(cells,ends,roles):
    per=defaultdict(dict); fixed=defaultdict(dict)
    for r in cells:
        key=row_id(r)
        bits=tuple(int(r[name]) for name in ('b0','wl','size'))
        assert set(bits)<={0,1} and bits not in per[key]
        counts=tuple(int(r[f'true_{y}']) for y in (0,1))
        assert min(counts)>=0 and sum(counts)==int(r['graphs'])
        per[key][bits]=counts
    assert set(per)==set(tasks()) and len(cells)==8*len(per)
    for r in ends:
        arm=r['method']
        if arm not in HIST:continue
        key=row_id(r)
        assert arm not in fixed[key]
        conf=tuple(int(r[col]) for col in ('tn','fp','fn','tp'))
        mx=metrics(conf)
        assert mx['n']==int(r['n']) and mx['correct']==int(r['correct']) and mx['positive']==int(r['positive_count'])
        for name in ('accuracy','macro_f1','recall_0','recall_1'):
            assert abs(float(mx[name])-float(r[name]))<1e-12 if mx[name] is not None else not r[name]
        fixed[key][arm]=mx
    out={};cohorts={}
    for key,info in tasks().items():
        assert set(fixed[key])==set(HIST) and len(per[key])==8
        h=[[0,0] for _ in DOM]
        for (b0,wl,sz),cnt in per[key].items():
            for y in (0,1):h[2*wl+sz][y]+=cnt[y]
        assert sum(map(sum,h))==len(roles[key]['holdout_ids'])
        true_counts=tuple(map(sum,zip(*h)))
        assert cohorts.setdefault((info[0],info[2]),true_counts)==true_counts
        for j,arm in enumerate(('B0','WL','Size')):
            conf=[0]*4
            for bits,(neg,pos) in per[key].items():
                pred=bits[j];conf[pred]+=neg;conf[2+pred]+=pos
            assert metrics(conf)==fixed[key][arm]
        for mx in fixed[key].values():
            assert (mx['tn']+mx['fp'],mx['fn']+mx['tp'])==true_counts
        out[key]=(h,fixed[key])
    return out

def evaluate(data,v_counts,rules):
    all_ids=tasks(); assert set(all_ids)==set(rules)==set(data)==set(v_counts)
    blocks={};summaries={}
    for key,(g,s,t) in all_ids.items():
        h,fixed=data[key]
        anchor=10 if g=='proteins_edge' else 12
        donors=[task_id(g,s,other) for other in DOM if other not in (s,t)]
        masks=dict(Anchor=anchor,**rules[key],**{f'Other{j}':rules[d]['Reverse'] for j,d in enumerate(donors,1)})
        pol={arm:table_mask(table) for arm,table in masks.items()}
        values={arm:metrics(confusion(h,pr)) for arm,pr in pol.items()}
        cm=smoothed_top(v_counts[key],h,values['Reverse']['positive'])
        values['CountMatched']=metrics(confusion(h,cm))
        values.update(fixed)
        values['OtherMean']={m:(values['Other1'][m]+values['Other2'][m])/2 if values['Other1'][m] is not None else None for m in values['Other1']}
        assert values['Anchor']==values['Size' if g=='proteins_edge' else 'WL']
        pairs={x:paired(h,pol['Reverse'],p) for x,p in pol.items() if x!='Reverse'}
        pairs['CountMatched']=paired(h,pol['Reverse'],cm)
        pairs['OtherMean']={m:F(pairs['Other1'][m]+pairs['Other2'][m],2) for m in pairs['Other1']}
        for m,p in pairs.items():assert p['net']==values['Reverse']['correct']-values[m]['correct']
        oracle=table_accuracies(h)
        blocks[key]=dict(setting=g,source=s,target=t,methods=values,pairs=pairs,tables=masks,countmatched=cm,oracle_direction=winners(oracle,anchor),all16_accuracy=oracle)
    for g in SETTINGS:
        group=[b for b in blocks.values() if b['setting']==g]
        anchor=10 if g=='proteins_edge' else 12
        methods={arm:mean(b['methods'][arm]['accuracy'] for b in group) for arm in group[0]['methods']}
        def anchor_gain(gg):return mean(b['methods']['Reverse']['accuracy']-b['methods']['Anchor']['accuracy'] for b in gg)
        target={i:anchor_gain([b for b in group if b['target']==i]) for i in DOM}
        omit={i:anchor_gain([b for b in group if b['target']!=i]) for i in DOM}
        or_s={i:winners([mean(b['all16_accuracy'][m] for b in group if b['source']==i) for m in range(16)],anchor) for i in DOM}
        wins=sum(b['methods']['Reverse']['accuracy']>b['methods']['Anchor']['accuracy'] for b in group)
        competitors=('Direct','PermMean','OtherMean','CountMatched',*HIST)
        overall=methods['Reverse']
        margins={arm:overall-methods[arm] for arm in competitors}
        passed=anchor_gain(group)>=F(1,200) and wins>=7 and min(margins.values())>0
        summaries[g]=dict(methods=methods,anchor_gain=anchor_gain(group),wins=wins,win_rate=F(wins,len(group)),main=passed,
                          margins=margins,rowperm_separate=overall>methods['RowPerm'],per_target=target,omit_target=omit,
                          oracle_source=or_s,oracle_source_mean=mean(s['maximum'] for s in or_s.values()),
                          oracle_direction_mean=mean(b['oracle_direction']['maximum'] for b in group))
    for k,b in blocks.items():
        h,_=data[k]
        for method,rec in [('OracleDirection',b['oracle_direction']),('OracleShared',summaries[b['setting']]['oracle_source'][b['source']])]:
            b['methods'][method]=metrics(confusion(h,table_mask(rec['anchor_tiebreak'])))
    return dict(blocks=blocks,settings=summaries,main_gate=summaries['proteins_edge']['main'] and any(summaries[g]['main'] for g in SETTINGS[:2]))

def selftest():
    # Equal source rates must pool across cells of unequal size; enumerate all random tied selections.
    h=[(2,1),(0,3),(2,0),(0,0)];v=[(0,1),(0,1),(9,0),(4,4)]
    q=smoothed_top(v,h,2)
    assert q==[F(1,3),F(1,3),0,0]
    labels=[int(i in (2,3,4,5)) for i in range(8)]
    vals=[]
    for a,b in itertools.combinations(range(6),2):vals.append(sum(y==(i in (a,b)) for i,y in enumerate(labels)))
    assert metrics(confusion(h,q))['correct']==mean(map(F,vals))
    assert paired([(1,4),(4,1),(0,0),(0,0)],[1,0,0,0],[0,1,0,0])==dict(corrected=8,harmed=2,changed=10,net=6)
    # Equal-direction oracle can differ from a majority pooled across graphs.
    h1=[(0,1),(0,0),(0,0),(0,0)];h2=[(6,4),(0,0),(0,0),(0,0)]
    a=table_accuracies(h1);b=table_accuracies(h2)
    assert winners([(x+y)/2 for x,y in zip(a,b)],0)['maximum']==F(7,10)
    assert winners(table_accuracies([(6,5),(0,0),(0,0),(0,0)]),0)['anchor_tiebreak']==0
    data={};vs={};rr={}
    for k,(g,s,t) in tasks().items():
        hh=[(3+s,1+t),(3,5),(1,0),(0,2)]
        fx={name:metrics(confusion(hh,table_mask({'WL':12,'Size':10}.get(name,5)))) for name in HIST}
        data[k]=(hh,fx);vs[k]=v;rr[k]={'Reverse':t,'PermMean':10,'Direct':8,'RowPerm':12}
    ev=evaluate(data,vs,rr)
    assert not ev['main_gate'] and len(ev['blocks'])==36
    for g,ss in ev['settings'].items():
        assert mean(ss['per_target'].values())==ss['anchor_gain']==mean(ss['omit_target'].values())
        assert ss['oracle_source_mean']<=ss['oracle_direction_mean']
    # Exercise the actual eight-cell archive format on invented counts, and test a positive
    # primary gate even when the exploratory RowPerm is identical to Reverse.
    source_h={};cell_rows=[];end_rows=[];frozen={};source_v={}
    for key,(g,s,t) in tasks().items():
        cells=[(int(z!=t),int(z==t)) for z in DOM]
        source_h[key]={'holdout_ids':list(range(8))}
        for b0,wl,sz in itertools.product(range(2),repeat=3):
            neg,pos=cells[2*wl+sz]
            cell_rows.append(dict(setting=g,source=s,target=t,seed=3405,b0=b0,wl=wl,size=sz,true_0=neg,true_1=pos,graphs=1))
        for arm in HIST:
            if arm=='B0':
                cnt=(3,3,1,1)
            else:
                cnt=confusion([(2*n,2*p) for n,p in cells],table_mask({'WL':12,'Size':10}.get(arm,0)))
            mx=metrics(cnt)
            end_rows.append(dict(setting=g,source=s,target=t,seed=3405,method=arm,positive_count=mx['positive'],**mx))
        frozen[key]=dict(Reverse=1<<t,PermMean=0,Direct=0,RowPerm=1<<t)
        source_v[key]=[(2,2)]*4
    ev=evaluate(aggregate(cell_rows,end_rows,source_h),source_v,frozen)
    assert ev['main_gate'] and all(s['wins']==12 and not s['rowperm_separate'] for s in ev['settings'].values())
    print('Synthetic cell decoding, tie enumeration, paired counts, oracle, positive/negative gates and sensitivity checks passed.')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--history',type=Path);p.add_argument('--blind',type=Path);p.add_argument('--primary',type=Path);p.add_argument('--obs-sha256');p.add_argument('--out',type=Path)
    args=p.parse_args()
    if not args.history:return selftest()
    # Open historical H data only after supplied, authenticated primary 4-arm tables exactly match blind 4-arm tables.
    main_obs=json_member(args.primary/'OBS.json',args.obs_sha256)
    assert main_obs['stage']=='OBS' and main_obs['predecessors']['historical_obs_sha256']==HIST_OBS
    fits=json_member(args.primary/'policies.json',main_obs['files']['policies.json'])
    expected={k:{arm:row['fits'][arm]['table'] for arm in LOCAL} for k,row in fits.items()}
    rules=json.loads((args.blind/'rules.json').read_bytes())
    rp=json.loads((args.blind/'rowperm-rules.json').read_bytes())
    assert set(rules)==set(rp)==set(tasks())
    for k in rules:rules[k]['RowPerm']=rp[k]
    assert rules==expected and all(set(row)==set(LOCAL) and all(type(n) is int and 0<=n<16 for n in row.values()) for row in rules.values())
    data,v_counts=load_history(args.history)
    results=evaluate(data,v_counts,rules)
    for k,b in results['blocks'].items():
        h,_=data[k]; deploy=fits[k]['deployment']
        assert b['tables']==deploy['tables'] and v_counts[k]==fits[k]['v_counts'] and [sum(c) for c in h]==deploy['h_counts']
        for m,policy in deploy['policies'].items():
            q=b['countmatched'] if m=='CountMatched' else table_mask(b['tables'][m])
            assert list(map(F,policy))==q and b['methods'][m]['positive']==F(deploy['positive_counts'][m])
    results['provenance']=dict(final=HIST_FINAL,obs=HIST_OBS,primary_obs=args.obs_sha256,raw_graph_labels_read=0)
    args.out.write_text(json.dumps(results,default=str,indent=2)+'\n')
    print('Verified',len(results['blocks']),'directions. Primary gate',results['main_gate'])
if __name__=='__main__':main()
