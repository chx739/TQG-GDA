"""Post-score attribution of the 4 one-cell changes to the preregistered anchor."""
from collections import defaultdict
from csv import DictReader, DictWriter
from fractions import Fraction as F
from hashlib import sha256
from itertools import groupby
import json
from pathlib import Path
import sys
root, prior, dest = map(Path,sys.argv[1:4])
def read(seal,name,expected):
    raw=(seal/'FINAL.json').read_bytes()
    assert sha256(raw).hexdigest()==expected
    data=(seal/name).read_bytes()
    assert sha256(data).hexdigest()==json.loads(raw)['files'][name]
    return data
def save(name,rows):
    with (dest/name).open('w') as stream:
        writer=DictWriter(stream,rows[0]); writer.writeheader(); writer.writerows(rows)
final_hash='cc3f3c7496a8ca7af0234f1dd582b26b1a92dab25f9e52c94dffa6ddcc531c07'
obs=read(root,'OBS.json',final_hash)
meta=json.loads(obs)
cfg=(root/'executed-config.json').read_bytes()
assert sha256(cfg).hexdigest()==meta['files']['executed-config.json']
pr=json.loads(cfg)['plan']['historical_final_sha256']
official=list(DictReader(read(root,'paired-blocks.csv',final_hash).decode().splitlines()))
cells=defaultdict(lambda:[[0,0] for _ in range(4)])
def key(x): return x['setting']+'-M'+str(x['source'])+'_to_M'+str(x['target'])+'-seed-'+str(x['seed'])
for x in DictReader(read(prior,'h-cells.csv',pr).decode().splitlines()):
    z=2*int(x['wl'])+int(x['size']); cell=cells[key(x)][z]
    cell[0]+=int(x['true_0']); cell[1]+=int(x['true_1'])
g=(root/'policies.json').read_bytes(); assert sha256(g).hexdigest()==meta['files']['policies.json']
rows=[]
for block,p in json.loads(g).items():
    setting=block.split('-')[0]; counts=cells[block]; n=sum(map(sum,counts))
    anchor=p['deployment']['tables']['Anchor']
    for z,(n0,n1) in enumerate(counts):
        voted=(anchor>>z)&1; fixed,harmed=(n0,n1) if voted else (n1,n0)
        other=anchor^(1<<z)
        for arm,fit in p['fits'].items():
            advice=F(fit['brier'][anchor])-F(fit['brier'][other])
            actual=((fit['table']^anchor)>>z)&1
            rows.append(dict(setting=setting,block=block,z=z,method=arm,h_graphs=n0+n1,n_H=n,anchor_vote=voted,source_brier_improvement=str(advice),source_favors_flip=int(advice>0),joint_flips=actual,corrected_if_flipped=fixed,harmed_if_flipped=harmed))
save('cells.csv',rows)
summary=[]
for (setting,method), group in groupby(sorted(rows,key=lambda x:(x['setting'],x['method'])), key=lambda x:(x['setting'],x['method'])):
    live=[x for x in group if x['h_graphs']]; proposed=[x for x in live if x['source_favors_flip']]; acted=[x for x in live if x['joint_flips']]
    b=lambda x:x['corrected_if_flipped']-x['harmed_if_flipped']
    count=lambda g: [sum(b(x)>0 for x in g),sum(b(x)==0 for x in g),sum(b(x)<0 for x in g)]
    summed=lambda g:sum(F(b(x),x['n_H']) for x in g)*100/12
    if method=='Reverse':
        cover=[x for x in official if x['setting']==setting and x['right']=='Anchor']; assert len(cover)==12
        assert summed(acted)==sum(F(x['accuracy_exact'])*100 for x in cover)/12
        assert sum(x['corrected_if_flipped'] for x in acted)==sum(F(x['corrected']) for x in cover)
        assert sum(x['harmed_if_flipped'] for x in acted)==sum(F(x['harmed']) for x in cover)
    summary.append(dict(setting=setting,method=method,occupied=len(live),possible_help_tie_harm='/'.join(map(str,count(live))),individual_positive=len(proposed),positive_help_tie_harm='/'.join(map(str,count(proposed))),positive_correct=sum(x['corrected_if_flipped'] for x in proposed),positive_harm=sum(x['harmed_if_flipped'] for x in proposed),joint=len(acted),joint_help_tie_harm='/'.join(map(str,count(acted))),joint_without_individual_positive=sum(not x['source_favors_flip'] for x in acted),joint_not_positive_correct=sum(x['corrected_if_flipped'] for x in acted if not x['source_favors_flip']),joint_not_positive_harm=sum(x['harmed_if_flipped'] for x in acted if not x['source_favors_flip']),eligible_true_improvement_missed=sum(b(x)>0 and not x['source_favors_flip'] for x in live),joint_delta_pp=float(summed(acted))))
save('summary.csv',summary)
for x in summary:
    if x['method']=='Reverse': print(x)
