"""Compare frozen independent exact outputs with the subsequently released primary FINAL."""
import argparse
import json
from fractions import Fraction as F
from statistics import mean
from check import SETTINGS,DOM,HIST,metrics,load_bytes,json_member,csv_load,row_id,tasks

def main():
    ap=argparse.ArgumentParser();ap.add_argument('out',type=__import__('pathlib').Path);ap.add_argument('final_sha');ap.add_argument('own',type=__import__('pathlib').Path)
    args=ap.parse_args()
    result=json.loads(args.own.read_bytes())
    out=args.out
    final=json_member(out/'FINAL.json',args.final_sha)
    assert final['stage']=='FINAL' and final['files']['OBS.json']==result['provenance']['primary_obs']
    def csvfile(name):return csv_load(load_bytes(out/name,final['files'][name]))
    def rownum(r,m):return F(r[m])
    blocks=result['blocks'];settings=result['settings']
    ntests={}
    def get(r):return blocks[row_id(r)]
    ends=csvfile('endpoints.csv'); assert len(ends)==sum(len(b['methods']) for b in blocks.values())
    seen=set()
    for r in ends:
        k=row_id(r);m=r['method']
        assert (k,m) not in seen;seen.add((k,m));a=get(r)['methods'][m]
        assert rownum(r,'accuracy_exact')==F(a['accuracy']) and rownum(r,'macro_f1_exact')==F(a['macro_f1'])
        assert int(r['n'])==F(a['n'])
        if m!='OtherMean':
            assert all(rownum(r,val)==F(a[val]) for val in ('tn','fp','fn','tp'))
    ntests['endpoints']=len(ends)
    pairs=csvfile('paired-blocks.csv')
    pseen=set()
    for r in pairs:
        k=row_id(r); b=blocks[k];arm=r['right']
        assert (k,arm) not in pseen;pseen.add((k,arm))
        assert rownum(r,'accuracy_exact')==F(b['methods']['Reverse']['accuracy'])-F(b['methods'][arm]['accuracy'])
        pr=b['pairs'].get(arm)
        if pr is not None:assert rownum(r,'corrected')==F(pr['corrected']) and rownum(r,'harmed')==F(pr['harmed'])
        else:assert r['corrected']==r['harmed']==''
    ntests['pairs']=len(pairs)
    oras=csvfile('oracle-headroom.csv')
    assert {row_id(r) for r in oras}==set(blocks) and len(oras)==len(blocks)
    for r in oras:
        b=get(r);s=settings[b['setting']]
        assert int(r['oracle_direction_table'])==b['oracle_direction']['anchor_tiebreak'] and int(r['oracle_shared_table'])==s['oracle_source'][str(b['source'])]['anchor_tiebreak']
        assert int(r['reverse_table'])==b['tables']['Reverse'] and int(r['anchor_table'])==b['tables']['Anchor']
    ntests['oracle']=len(oras)
    ss=csvfile('summary.csv')
    for r in ss:
        scope=r['scope'];group=[b for b in blocks.values() if b['setting']==r['setting'] and (scope=='setting' or (b['target']==int(r['target']))==(scope=='target'))]
        assert len(group)==int(r['directions'])
        vals=[b['methods'][r['method']] for b in group]
        aa=mean(F(x['accuracy']) for x in vals);ff=mean(F(x['macro_f1']) for x in vals)
        delta=aa-mean(F(b['methods']['Anchor']['accuracy']) for b in group)
        assert abs(float(aa)-float(r['accuracy']))<1e-12 and abs(float(ff)-float(r['macro_f1']))<1e-12 and F(r['delta_vs_anchor_exact'])==delta
    ntests['summary']=len(ss)
    ps=csvfile('paired-summary.csv')
    for r in ps:
        group=[b for b in blocks.values() if b['setting']==r['setting']];rr=r['right']
        dif=[F(b['methods']['Reverse']['accuracy'])-F(b['methods'][rr]['accuracy']) for b in group]
        assert len(dif)==int(r['directions']) and mean(dif)==F(r['accuracy_exact'])
        assert [sum(sign(x) for x in dif) for sign in [lambda x:x>0,lambda x:x==0,lambda x:x<0]]==[int(r[n]) for n in ['wins','ties','losses']]
        if rr in group[0]['pairs']:
            for key in ('corrected','harmed'):assert sum(F(b['pairs'][rr][key]) for b in group)==F(r[key])
    ntests['pair_summary']=len(ps)
    gate=json_member(out/'gate.json',final['files']['gate.json'])
    assert gate['advance']==result['main_gate']
    for g in SETTINGS:
        ours=settings[g];theirs=gate['settings'][g]
        assert theirs['passed']==ours['main'] and theirs['wins']==ours['wins']
        tt=[b for b in blocks.values() if b['setting']==g]
        deltas=[F(b['methods']['Reverse']['accuracy'])-F(b['methods']['Anchor']['accuracy']) for b in tt]
        assert theirs['ties']==sum(d==0 for d in deltas) and theirs['losses']==sum(d<0 for d in deltas)
        checks={'anchor_gain':F(ours['anchor_gain'])>=F(1,200),'positive_directions':ours['wins']>=7}
        checks.update({m:F(d)>0 for m,d in ours['margins'].items()})
        assert theirs['checks']==checks and theirs['best_fixed'] in HIST
        assert F(ours['methods'][theirs['best_fixed']])==max(F(ours['methods'][m]) for m in HIST)
        for m,d in theirs['accuracy_exact'].items():
            assert F(d)==F(ours['methods']['Reverse'])-F(ours['methods'][m]) and abs(float(F(d)*100)-theirs['accuracy_pp'][m])<1e-12
    ntests['gates']=4
    print(json.dumps(dict(primary_final=args.final_sha,checked=ntests,all_match=True)))
if __name__=='__main__':main()
