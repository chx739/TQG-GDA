"""Descriptive H-only upper bound and held-out expected domain-label diagnostic."""
from collections import defaultdict
from csv import DictReader, DictWriter
from fractions import Fraction
from hashlib import sha256
import itertools,json,sys
from math import comb
from pathlib import Path
def correct_probability(n, n0, n1, label, anchor, m):
    # Condition on this query being in H minus reference. Counts below exclude it.
    pos,neg=n1-label,n0-(1-label)
    out=n-n0-n1
    denominator=comb(n-1,m)
    win=0
    for count in range(max(0,m-out),min(m,pos+neg)+1):
        outside_ways=comb(out,m-count)
        for num_pos in range(max(0,count-neg),min(count,pos)+1):
            vote=anchor if 2*num_pos==count else int(2*num_pos>count)
            if vote==label: win+=comb(pos,num_pos)*comb(neg,count-num_pos)*outside_ways
    return Fraction(win,denominator)
def score(cells,n,anchor_for):
    best=0; half=Fraction(0); anchor_correct=0; n_amb=0
    for k,(a,b) in cells.items():
        bit=anchor_for(k)
        best+=max(a,b)
        anchor_correct+=b if bit else a
        n_amb+=int(a>0 and b>0)
        for y,ny in enumerate((a,b)):
            if ny:half+=ny*correct_probability(n,a,b,y,bit,n//2)
    return Fraction(best,n),half/n,Fraction(anchor_correct,n),n_amb
def test():
    cats=[(0,0),(0,1),(0,1),(1,0),(1,1),(2,1),(3,0)]
    n=len(cats)
    for m in range(n):
        for idx,(z,y) in enumerate(cats):
            a=sum(c==(z,0) for c in cats);b=sum(c==(z,1) for c in cats)
            for bit in (0,1):
                hits=0;den=0
                for ref in itertools.combinations([i for i in range(n) if i!=idx],m):
                    c=[cats[i][1] for i in ref if cats[i][0]==z]
                    vote=bit if sum(c)*2==len(c) else int(sum(c)*2>len(c))
                    hits+=int(vote==y);den+=1
                assert correct_probability(n,a,b,y,bit,m)==Fraction(hits,den)
def emit(path,rows):
    with path.open('w') as f:
        w=DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
test()
root,outdir=map(Path,sys.argv[1:])
seal=(root/'FINAL.json').read_bytes();assert sha256(seal).hexdigest()=='5bab66c3071e4f3a34c694daf2ad3fcdd30604f4716b0e18a7ca73766d401c69'
data=(root/'h-cells.csv').read_bytes();assert sha256(data).hexdigest()==json.loads(seal)['files']['h-cells.csv']
old=defaultdict(dict)
for row in DictReader(data.decode().splitlines()):
    st,src,tar=row['setting'],int(row['source']),int(row['target'])
    vote=tuple(int(row[x]) for x in ('wl','size','b0'))
    old[st,src,tar][vote]=tuple(int(row[x]) for x in ('true_0','true_1'))
assert len(old)==36 and all(len(x)==8 for x in old.values())
blocks=[]
for (s,i,j),cells in old.items():
    four=defaultdict(lambda:[0,0]); n=sum(sum(v) for v in cells.values())
    for (w,sz,b),v in cells.items():
        for y,vv in enumerate(v): four[w,sz][y]+=vv
    for label,part in [('four',four),('eight',cells)]:
        anchor=lambda k:k[1] if s=='proteins_edge' else k[0]
        opt,half,ref,amb=score(part,n,anchor)
        blocks.append(dict(setting=s,source=i,target=j,partition=label,n=n,reference_n=n//2,occupied=sum(sum(z)>0 for z in part.values()),mixed_cells=amb,anchor=ref,oracle=opt,split_expected=half))
records=[]
for s in sorted({r['setting'] for r in blocks}):
    for part in ('four','eight'):
        b=[r for r in blocks if r['setting']==s and r['partition']==part]
        for method in ('oracle','split_expected'):
            deltas=[r[method]-r['anchor'] for r in b]
            records.append(dict(setting=s,partition=part,method=method,accuracy_pct=float(100*sum(r[method] for r in b)/12),delta_pp=float(100*sum(deltas)/12),wins=sum(x>0 for x in deltas),ties=sum(x==0 for x in deltas),losses=sum(x<0 for x in deltas)))
emit(outdir/'capacity-by-direction.csv',blocks);emit(outdir/'capacity-summary.csv',records)
for x in records: print(x['setting'],x['partition'],x['method'],round(x['accuracy_pct'],4),round(x['delta_pp'],4),x['wins'],x['ties'],x['losses'])
