from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
from math import comb
from pathlib import Path
import csv, io, json
OUT=Path('/tmp/r12-vote-capacity-independent')
R12=next(Path('/home/hxchen/research/GDA/TSBA/repository/experiments/mutagenicity').glob('r12_*/results/attempt-002-conditional-votes'))
final=(R12/'FINAL.json').read_bytes()
assert sha256(final).hexdigest()=='5bab66c3071e4f3a34c694daf2ad3fcdd30604f4716b0e18a7ca73766d401c69'
record=json.loads(final)
assert record['stage']=='FINAL' and record['predecessors']=={'obs_sha256':'fde4616cad09f0c9c184a2feeeec9d1c243ddae14ad56755b5ec10a8cfb05d51'}
cells=(R12/'h-cells.csv').read_bytes()
assert sha256(cells).hexdigest()==record['files']['h-cells.csv']
def cond_correct(zeros,ones,others,m,anchor,y):
    """Number of size-m reference sets in other N-1 giving correct class y."""
    count=0
    for i in range(min(m,ones)+1):
        # reference zeros range by possible membership and predicted class
        lo=max(0,m-i-others)
        hi=min(zeros,m-i)
        if y:
            hi=min(hi,i-(1-anchor))
        else:
            lo=max(lo,i+anchor)
        p=comb(ones,i)
        if lo<=hi:
            count+=p*sum(comb(zeros,j)*comb(others,m-i-j) for j in range(lo,hi+1))
    return count
def measure(positions,anchor):
    N=sum(sum(c) for c in positions)
    m=N//2
    C=comb(N-1,m)
    expected,oracle,base=0,0,0
    for (a,b),act in zip(positions,anchor):
        rest=N-a-b
        if a: expected+=a*cond_correct(a-1,b,rest,m,act,0)
        if b: expected+=b*cond_correct(a,b-1,rest,m,act,1)
        base+=b if act else a
        oracle+=max(a,b)
    return F(base,N),F(oracle,N),F(expected,N*C)
def brute_case(rows,anchors):
    data=[(z,y) for z,n in enumerate(rows) for y,count in enumerate(n) for _ in range(count)]
    N=len(data);m=N//2
    correct=0;total=0
    for selected in combinations(range(N),m):
        ref=set(selected)
        count=[[0,0] for _ in rows]
        for k in ref:
            z,y=data[k];count[z][y]+=1
        for k,(z,y) in enumerate(data):
            if k in ref:continue
            a,b=count[z]
            correct+=int((anchors[z] if a==b else int(b>a))==y)
            total+=1
    return F(correct,total)
test_count=0
for a,b,c,d in product(range(3),repeat=4):
    rows=[(a,b),(c,d)]
    if not 1<=a+b+c+d<=8:continue
    for anchors in product([0,1],repeat=2):
        assert measure(rows,anchors)[2]==brute_case(rows,anchors);test_count+=1
group=defaultdict(dict)
for row in csv.DictReader(io.StringIO(cells.decode())):
    setting=row['setting']; src,t,sz,g,w,n,neg,pos=(int(row[k]) for k in ['source','target','size','b0','wl','graphs','true_0','true_1'])
    assert int(row['seed'])==3405 and n==neg+pos
    key=(setting,src,t)
    assert (w,sz,g) not in group[key]
    group[key][w,sz,g]=(neg,pos)
assert len(group)==36
results=[]
for (setting,src,t),table in sorted(group.items()):
    ar=lambda wi,si:si if setting=='proteins_edge' else wi
    assert len(table)==8
    ab=[]
    agg={}
    for wd in [4,8]:
        cells0=[];actions=[]
        for wi,si in product(range(2),repeat=2):
            if wd==4:
                cells0.append(tuple(map(sum,zip(table[wi,si,0],table[wi,si,1]))))
                actions.append(ar(wi,si))
            else:
                for bi in [0,1]:
                    cells0.append(table[wi,si,bi]);actions.append(ar(wi,si))
        base,oracle,held=measure(cells0,actions)
        agg.update({f'full{wd}':oracle,f'half{wd}':held});ab.append(base)
    assert ab[0]==ab[1] and agg['full8']>=agg['full4']>=ab[0] and agg['full8']>=agg['half8'] and agg['full4']>=agg['half4']
    results.append(dict(setting=setting,source=src,target=t,n=sum(sum(a) for a in table.values()),anchor=ab[0],**agg))
def mean(x):return sum(x)/len(x)
def wp(a,b):return [sum((x>y if sign=='W' else x==y if sign=='T' else x<y) for x,y in zip(a,b)) for sign in ['W','T','L']]
output={}
for setting in sorted({r['setting'] for r in results}):
    rows=[r for r in results if r['setting']==setting]
    assert len(rows)==12
    target=[r['anchor'] for r in rows]
    out=dict(anchor_pp=float(100*mean(target)),N=sum(r['n'] for r in rows),methods={},comparisons={})
    for name in ['full4','full8','half4','half8']:
        x=[r[name] for r in rows]
        out['methods'][name]=dict(accuracy_exact=str(mean(x)),accuracy_pp=float(100*mean(x)),vs_anchor_pp=float(100*(mean(x)-mean(target))),vs_anchor_wtl=wp(x,target))
    for right,left in [('half4','half8'),('full4','full8')]:
        x=[r[left] for r in rows];y=[r[right] for r in rows]
        out['comparisons'][left+'-'+right]={'difference_pp':float(100*(mean(x)-mean(y))),'wtl':wp(x,y)}
    output[setting]=out
with (OUT/'directions.csv').open('w') as fp:
    wr=csv.DictWriter(fp,fieldnames=list(results[0]));wr.writeheader();wr.writerows(results)
(OUT/'summary.json').write_text(json.dumps(output,indent=2)+'\n')
print('brute',test_count)
for s,v in output.items():
    print(s,round(v['anchor_pp'],6))
    for k,m in v['methods'].items():print(k,round(m['accuracy_pp'],6),round(m['vs_anchor_pp'],6),m['vs_anchor_wtl'])
    print(v['comparisons'])
