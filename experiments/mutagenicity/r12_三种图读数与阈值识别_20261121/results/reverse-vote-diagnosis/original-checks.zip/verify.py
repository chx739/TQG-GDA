"""Independent implementation of 3beb843. No A/H graph labels or H class totals."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import io,json,csv,math
import numpy as np
import torch
from torch_geometric.data import Data
from experiments.mutagenicity.r10_原生图适配基线与增量_20261121.src import structural

REPO=Path('/home/hxchen/research/GDA/TSBA/repository')
ROOT=REPO/'experiments/mutagenicity'
OUT=Path('/tmp/r12-reverse-blind')
R12=next(ROOT.glob('r12_*/results/attempt-002-conditional-votes'))
EXPECTED='fde4616cad09f0c9c184a2feeeec9d1c243ddae14ad56755b5ec10a8cfb05d51'
def sha(x): return sha256(x).hexdigest()
def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def read(path,expected):
    data=path.read_bytes()
    assert sha(data)==expected,(path,sha(data),expected)
    return data
def jd(root,files,name): return json.loads(read(root/name,files[name]))
def npz(root,files,name,columns):
    with np.load(io.BytesIO(read(root/name,files[name])),allow_pickle=False) as data:
        return {k:data[k] for k in columns}
def seal(root,stage,signature):
    saved=json.loads(read(root/(stage+'.json'),signature))
    assert saved['stage']==stage
    return saved
def z_from_old(b):
    assert np.all((b>=0)&(b<8)) and b.dtype==np.int64
    return 2*(b%2)+(b//4)
def counts(values,n=4): return np.bincount(values,minlength=n)
def positive_code(code,z): return ((code >> z)&1).astype(np.uint8)
def wgt(vhist,ahist,zm):
    """Vectorized exact distances. Float nomination is *only* an index hint, verified by integer cross-products."""
    aedges=ahist.sum(1)
    k=min(8,len(ahist))
    result=[]
    for vh in vhist:
        n=int(vh.sum())
        nom=np.abs(ahist*n-aedges[:,None]*vh).sum(1)
        # d=nom/(2*n*aedges); n is fixed across the full row
        j=int(np.argpartition(nom/aedges,k-1)[k-1])
        here=nom*aedges[j]
        there=int(nom[j])*aedges
        close=(here<there)
        boundary=(here==there)
        nclose,nbound=int(close.sum()),int(boundary.sum())
        assert nclose<k<=nclose+nbound
        a=counts(zm[close])*nbound+counts(zm[boundary])*(k-nclose)
        b=k*nbound
        div=math.gcd(b,*a)
        assert a.sum()==b
        result.append([*(a//div),b//div])
    return np.asarray(result,dtype=np.int64)
def risks(weight,y):
    cache={}
    risks=[]
    for code in range(16):
        bits=np.array([(code>>j)&1 for j in range(4)])
        numer=(weight[:,:4]@bits-weight[:,4]*y)**2
        den=weight[:,4]**2
        tot=F(0)
        for denom in np.unique(den):
            tot+=F(int(numer[den==denom].sum()),int(denom))
        risks.append(tot/len(y))
    return risks
def best(loss,anchor):
    return min(range(16),key=lambda t:(loss[t],(t^anchor).bit_count(),t))
def topo(g,setting):
    assert set(g)=={'x','edge_index','edge_attr'}
    x=g['x'].numpy()
    assert np.all(x.sum(axis=1)==1) and set(np.unique(x))<=set([0,1])
    t=x.argmax(axis=1)
    width=x.shape[1]
    edges={(min(i,j),max(i,j)) for i,j in g['edge_index'].T.tolist() if i!=j}
    c=np.zeros(width*width+1,dtype=np.int64)
    for i,j in edges: c[min(t[i],t[j])*width+max(t[i],t[j])]+=1
    if not edges: c[-1]=1
    return c
old=seal(R12,'OBS',EXPECTED)
of=old['files']
cfg=json.loads(next(ROOT.glob('r12_*/configs/conditional-votes.json')).read_text())
assert old['predecessors']=={k:cfg[k] for k in old['predecessors']}
R10=Path(cfg['r10']); R11=REPO/cfg['r11'];R16=REPO/cfg['r16']
fit10=seal(R10,'FIT',cfg['r10_fit_sha256'])['files']
obs10=seal(R10,'OBS',cfg['r10_obs_sha256'])['files']
fit16=seal(R16,'FIT',cfg['r16_fit_sha256'])['files']
un11=seal(R11,'UNLABELED',cfg['r11_unlabeled_sha256'])['files']
roles=jd(R12,of,'roles.json');sources=jd(R12,of,'source-counts.json')
old_rules=jd(R12,of,'rules.json')
access=jd(R10,fit10,'fit-access.json')
assert len(roles)==36 and len(sources)==12
scores_out=[]; rows_out=[]; rulemap={}; rowpermmap={}
phase_receipt={'protocol_commit':'3beb843','r12_obs':EXPECTED,'source_label_files':{},'graph_hashes':{},'archived_roles_only':['validation','selected A','H votes'], 'raw_target_label_reads':0}
for setting in cfg['settings']:
    root=REPO.parent/'experiments/r5'/setting/'attempt-001'
    sealed=json.loads((root/'seals/R5_INPUT.json').read_bytes())['files']
    graphhash=jd(root,sealed,'inputs/graph_hashes.json')
    graphs_path=root/'inputs/graphs.pt'; graphs_sha=sha(graphs_path.read_bytes())
    assert graphs_sha==sealed['inputs/graphs.pt']
    phase_receipt['graph_hashes'][setting]=graphs_sha
    graphs=torch.load(graphs_path,weights_only=True,map_location='cpu',mmap=True)
    cache={}
    def graph(i):
        if i not in cache:
            r=graphs[i]
            assert graphhash[i]['id']==i
            for n,v in r.items():
                assert graphhash[i]['input_sha256'][n]==(None if v is None else sha(v.numpy().tobytes()))
            cache[i]=topo(r,setting),structural.features(Data(**r),setting)
        return cache[i]
    for src in [0,1,2,3]:
        tasks={k:r for k,r in roles.items() if r['setting']==setting and r['source']==src}
        assert len(tasks)==3
        group=next(iter(tasks.values()))['group']
        sv=sources[group]; a10=access[group]
        grpath='fits/'+group+'.json'
        r16=jd(R16,fit16,grpath)
        assert fit16[grpath]==sv['r16_fit_member_sha256']
        assert r16['lineage']['model_sha256']==fit10[grpath]==sv['structure_sha256']
        assert r16['lineage']['graph_sha256']==graphs_sha==a10['graph_container_sha256']
        model=jd(R10,fit10,grpath)
        v=sv['v_ids']
        assert v==a10['validation_ids']==r16['validation_ids'] and len(set(v))==len(v)
        path=f'source_labels/M{src}/seed3405_validation.pt'
        ysha=sealed[path]
        assert ysha==a10['v_label_sha256']==sv['v_label_sha256']==r16['source_label_sha256']['V']
        y=torch.load(io.BytesIO(read(root/path,ysha)),weights_only=True,map_location='cpu').numpy()
        assert y.dtype==np.int64 and np.isin(y,[0,1]).all() and y.shape==(len(v),)
        phase_receipt['source_label_files'][group]={'file':str(root/path),'sha256':ysha,'n':len(y)}
        valm=np.array(r16['validation_margins'])
        vvote=valm>0.
        assert vvote.shape==(len(v),3)
        oldbv=4*vvote[:,2]+2*vvote[:,0]+vvote[:,1]
        assert np.array_equal(counts(8*y+oldbv,16).reshape(2,2,4),sv['counts'])
        zv=z_from_old(oldbv)
        vhist=np.stack([graph(i)[0] for i in v])
        vm=structural.predict(model,[graph(i)[1] for i in v])
        for j,arm in [(1,'WL_selected'),(2,'Size')]:
            assert np.array_equal(vm[arm],valm[:,j])
        anchor=10 if setting=='proteins_edge' else 12
        direct=[F(int(np.count_nonzero(positive_code(t,zv)!=y)),len(y)) for t in range(16)]
        for k,row in tasks.items():
            assert row['ids']['validation']==v
            a=row['selected_a_ids'];h=row['holdout_ids']
            assert len(set(a))==len(a) and set(a)<=set(row['ids']['adapt'])
            assert row['ids']['holdout']==h and not (set(v)&set(a) or set(a)&set(h) or set(v)&set(h))
            name='predictions/'+k+'.npz';p=npz(R12,of,name,['a_bins','h_bins','a_ids','ids','B0','WL','Size'])
            assert p['a_ids'].tolist()==a and p['ids'].tolist()==h
            assert np.array_equal(p['h_bins'],4*p['Size']+2*p['B0']+p['WL'])
            x10=npz(R10,obs10,name,['ids','action_WL_selected','action_Size','action_B0'])
            for a12,a10name in [('ids','ids'),('WL','action_WL_selected'),('Size','action_Size'),('B0','action_B0')]:
                assert np.array_equal(p[a12],x10[a10name])
            assert row['evidence']['r10_sha256']==obs10[name]
            a11path='deployment/'+k+'.npz'
            x11=npz(R11,un11,a11path,['a_margin','a_size_margin'])
            assert row['evidence']['r11_sha256']==un11[a11path]
            ahist=np.stack([graph(i)[0] for i in a])
            am=structural.predict(model,[graph(i)[1] for i in a])
            assert np.array_equal(am['Size'],x11['a_size_margin'])
            assert np.array_equal(4*(am['Size']>0)+2*(x11['a_margin']>0)+(am['WL_selected']>0),p['a_bins'])
            assert np.array_equal(counts(p['a_bins'],8),old_rules[k]['global_prior']['a_counts'])
            za=z_from_old(p['a_bins']);zh=z_from_old(p['h_bins'])
            active=(vhist.sum(0)+ahist.sum(0))>0
            w=wgt(vhist[:,active],ahist[:,active],za)
            np.savez_compressed(OUT/'weights'/(k+'.npz'),v_ids=np.array(v),weight_numerators=w[:,:4],weight_denominators=w[:,4],a_votes_4=counts(za),h_votes_4=counts(zh))
            reverse=risks(w,y)
            ac=counts(za)
            perm=[sum(F(int(n),len(y))*(F(int(positive_code(t,np.arange(4))@ac),len(a))-c)**2 for c,n in enumerate(counts(y,2))) for t in range(16)]
            assert reverse[0]==direct[0]==perm[0]==F(int(y.sum()),len(y)) and reverse[15]==direct[15]==perm[15]
            rowperm=[]
            prevalence=F(int(y.sum()),len(y))
            for code in range(16):
                bits=np.asarray([(code>>j)&1 for j in range(4)])
                nm=w[:,:4]@bits
                den=w[:,4]
                tot=F(0)
                for b in np.unique(den):
                    part=nm[den==b]
                    tot+=F(int(part@part),int(b)**2)-2*prevalence*F(int(part.sum()),int(b))
                rowperm.append(tot/len(y)+prevalence)
            ranking={'Reverse':reverse,'Direct':direct,'PermMean':perm,'RowPerm':rowperm}
            rules={name:best(r,anchor) for name,r in ranking.items()}
            rulemap[k]={arm:rules[arm] for arm in ('Reverse','Direct','PermMean')}; rowpermmap[k]=rules['RowPerm']
            for mode,loss in ranking.items():
                for t,l in enumerate(loss):scores_out.append({'block':k,'method':mode,'table':t,'v_brier_exact':str(l)})
            record={'block':k,'V_n':len(v),'A_n':len(a),'H_n':len(h),'a_counts_4':ac.tolist(),'h_counts_4':counts(zh).tolist(),'selected':rules,'method':{}}
            for name,r in ranking.items():
                z=positive_code(rules[name],zh)
                ordered=sorted(r)
                record['method'][name]={'positive_h':int(z.sum()),'actions_sha256_u8':sha(z.tobytes()),'runnerup_gap':str(ordered[1]-ordered[0]),'selected_loss':str(ordered[0]),'vs_anchor_changed_h':int(np.count_nonzero(z!=positive_code(anchor,zh)))}
            rows_out.append(record)
        print('verified',setting,src,flush=True)
with (OUT/'all-v-losses.csv').open('w') as fp:
    wr=csv.DictWriter(fp,fieldnames=list(scores_out[0]));wr.writeheader();wr.writerows(scores_out)
for name,doc in [('directions',rows_out),('rules',rulemap),('rowperm-rules',rowpermmap),('receipt',phase_receipt)]:
    (OUT/(name+'.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
(OUT/'rules-canonical.json').write_bytes(canon(rulemap))
print('complete',sha(canon(rulemap)),len(scores_out),flush=True)
