"""Run the registered source D/C pair-readout check in freeze and score phases."""

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

import pair_inputs as pair


ROOT = Path("/home/hxchen/research/GDA/TSBA")
SCRIPT = Path(__file__).resolve().parent
PLAN_HASH = "5b57c3f653541b607b19ba456cfa81412c209a65c795684d85fd8544b3526a7d"
PAIR_HASH = "364c8b02f6b773f11c72f97b8c6fba9a8a78cb5d08e8e776f8db69ca13d96143"


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def authenticated_roles():
    assert pair.sha((SCRIPT / "plan.md").read_bytes()) == PLAN_HASH
    assert pair.sha((SCRIPT / "pair_inputs.py").read_bytes()) == PAIR_HASH
    r9 = next((ROOT / "repository/experiments/mutagenicity").glob(
        "r9_*/results/reference-geometry-001"))
    raw = (r9 / "roles.json").read_bytes()
    assert pair.sha(raw) == pair.read_json(r9 / "OBS.json")["files"]["roles.json"]
    receipt = pair.read_json(r9 / "source-provenance.json")
    return json.loads(raw), receipt, pair.sha(raw)


def get_labels(key, role, ids, rows, receipt, expected_role):
    """Never read a byte of the raw graph-label file except registered per-ID offsets."""
    assert role == expected_role and role in ("D", "C")
    block = rows[key]
    assert ids == block["roles"][role] and len(ids) == len(set(ids))
    setting = block["setting"]
    root = ROOT / "experiments/r5" / setting / "attempt-001"
    source = receipt[setting]
    meta_bytes = (root / "inputs/label_records.json").read_bytes()
    assert pair.sha(meta_bytes) == source["inputs/label_records.json"]
    meta = json.loads(meta_bytes)
    plan_bytes = (root / "protocol/plan.json").read_bytes()
    assert pair.sha(plan_bytes) == source["protocol/plan.json"]
    plan = json.loads(plan_bytes)
    path = Path(meta["path"])
    assert path == Path(plan["input"]["raw_directory"]) / (plan["dataset"] + "_graph_labels.txt")
    spec = plan["input"]["files"][path.name]
    assert spec["sha256"] == meta["sha256"]
    assert path.stat().st_size == spec["bytes"]
    assert sorted(meta["mapping"].values()) == [0, 1]
    out = []
    requested_bytes = hashlib.sha256()
    with path.open("rb", buffering=0) as file:
        for graph_id in ids:
            start, size = meta["offsets"][graph_id]
            assert 0 <= start < spec["bytes"] and 0 < size <= spec["bytes"] - start
            file.seek(start)
            record = file.read(size)
            assert len(record) == size
            requested_bytes.update(record)
            out.append(meta["mapping"][str(int(record))])
    return np.asarray(out, dtype=int), dict(direction=key, role=role, ids=ids,
        selected_record_bytes_sha256=requested_bytes.hexdigest(),
        label_metadata_sha256=source["inputs/label_records.json"],
        historical_file_sha256=spec["sha256"], checked_file_size=spec["bytes"])


def make_grid(rows, setting):
    return {k: v["roles"] for k, v in rows.items() if v["setting"] == setting}


def freeze(out, rows, receipt, role_sha):
    if (out / "freeze.json").exists():
        raise FileExistsError("Use a fresh output directory for a new result")
    scores, accesses, training_info = [], [], {}
    for setting in pair.SETTINGS:
        grid = make_grid(rows, setting)
        wanted = {i for r in grid.values() for role in ("D", "C") for i in r[role]}
        types, groups, neighbors, hashes = pair.load_inputs(ROOT, setting, wanted)
        _, words, word_by_id = pair.graph_inputs(types, groups, neighbors)
        for key, r in grid.items():
            d, c = r["D"], r["C"]
            assert not set(d) & set(c)
            counts = Counter(t for i in d for t in set(words[i][0]))
            chosen = sorted(counts, key=lambda t: (-counts[t], word_by_id[t]))[:16]
            vocab = {token: i for i, token in enumerate(chosen)}
            k = len(vocab) + 1
            y, access = get_labels(key, "D", d, rows, receipt, "D")
            accesses.append(access)
            aggregate = np.zeros((2, k, k))
            fit_covered = [0, 0]
            for gid, label in zip(d, y):
                matrix, pairs = pair.word_pair_matrix(words[gid], vocab)
                aggregate[label] += matrix
                fit_covered[label] += int(pairs > 0)
            assert np.allclose(aggregate.sum((1, 2)), fit_covered)
            cond = (aggregate + 1/k) / (aggregate.sum(2, keepdims=True) + 1)
            marg = (aggregate.sum(1) + 1/k) / (aggregate.sum((1, 2))[:, None] + 1)
            assert np.allclose(cond.sum(2), 1) and np.allclose(marg.sum(1), 1)
            ll_cond = np.log(cond[1] / cond[0])
            ll_marg = np.log(marg[1] / marg[0])
            prior = (y.sum() + .5) / (len(y) + 1)
            offset = np.log(prior / (1-prior))
            for gid in c:
                matrix, pairs = pair.word_pair_matrix(words[gid], vocab)
                scores.append(dict(setting=setting, direction=key, graph_id=gid,
                    ordered_pairs=pairs, logit_prior=offset,
                    margin_marginal=offset + np.sum(matrix * ll_marg),
                    margin_conditional=offset + np.sum(matrix * ll_cond)))
            training_info[key] = dict(positive_D=int(y.sum()), n_D=len(y),
                class_counts=np.bincount(y, minlength=2).tolist(), fit_covered=fit_covered,
                prior=prior, dictionary=[word_by_id[t] for t in chosen],
                marginal=marg.tolist(), conditional=cond.tolist(), raw_graph_sha256=hashes)
    assert len(training_info) == len(rows) == 24
    pair.write_csv(out / "frozen-predictions.csv", scores)
    dump(out / "fit-D-label-access.json", accesses)
    dump(out / "fit-tables.json", training_info)
    artifacts = ["frozen-predictions.csv", "fit-D-label-access.json", "fit-tables.json"]
    dump(out / "freeze.json", dict(plan_sha256=PLAN_HASH, pair_inputs_sha256=PAIR_HASH,
        code_sha256=pair.sha(Path(__file__).read_bytes()), roles_sha256=role_sha,
        files={name: pair.sha((out / name).read_bytes()) for name in artifacts}))


def score(out, rows, receipt, role_sha):
    freeze_file = (out / "freeze.json").read_bytes()
    archive = json.loads(freeze_file)
    assert archive["plan_sha256"] == PLAN_HASH and archive["roles_sha256"] == role_sha
    assert archive["code_sha256"] == pair.sha(Path(__file__).read_bytes())
    for file, check in archive["files"].items():
        assert pair.sha((out / file).read_bytes()) == check
    with (out / "frozen-predictions.csv").open() as file:
        all_predictions = list(csv.DictReader(file))
    score_rows, accesses, summary = [], [], []
    for setting in pair.SETTINGS:
        for key, r in make_grid(rows, setting).items():
            local = [x for x in all_predictions if x["direction"] == key]
            assert [int(x["graph_id"]) for x in local] == r["C"]
            y, access = get_labels(key, "C", r["C"], rows, receipt, "C")
            accesses.append(access)
            pools = [np.array([float(p["margin_" + arm]) for p in local])
                     for arm in ("marginal", "conditional")]
            correct, metrics = [], {}
            for arm, m in zip(("marginal", "conditional"), pools):
                right = (m > 0) == y
                correct.append(right)
                metrics[f"accuracy_{arm}"] = right.mean()
                metrics[f"nll_{arm}"] = np.mean(np.logaddexp(0, m) - y*m)
            m, c = correct
            score_rows.append(dict(setting=setting, direction=key,
                n_C=len(y), positive_C=int(y.sum()),
                covered_C=sum(int(x["ordered_pairs"]) > 0 for x in local),
                changed=int(np.sum(m != c)), fixed=int(np.sum(~m & c)),
                harmed=int(np.sum(m & ~c)), **metrics,
                delta_accuracy_pp=100 * (metrics["accuracy_conditional"]-metrics["accuracy_marginal"]),
                delta_nll=metrics["nll_conditional"]-metrics["nll_marginal"]))
        subset = [r for r in score_rows if r["setting"] == setting]
        sums = {metric: sum(r[metric] for r in subset)
                for metric in ("n_C", "positive_C", "covered_C", "changed", "fixed", "harmed")}
        means = {metric: np.mean([r[metric] for r in subset])
                 for metric in ("accuracy_marginal", "accuracy_conditional", "nll_marginal",
                                "nll_conditional", "delta_accuracy_pp", "delta_nll")}
        summary.append(dict(setting=setting, **sums, **means,
            accuracy_wins=sum(r["fixed"] > r["harmed"] for r in subset),
            accuracy_ties=sum(r["fixed"] == r["harmed"] for r in subset),
            accuracy_losses=sum(r["fixed"] < r["harmed"] for r in subset),
            nll_wins=sum(r["delta_nll"] < 0 for r in subset)))
    pair.write_csv(out / "directions.csv", score_rows)
    pair.write_csv(out / "summary.csv", summary)
    dump(out / "score-C-label-access.json", accesses)
    dump(out / "final.json", dict(freeze_sha256=pair.sha(freeze_file),
        files={name: pair.sha((out / name).read_bytes()) for name in
               ("directions.csv", "summary.csv", "score-C-label-access.json")}))
    print((out / "summary.csv").read_text())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("freeze", "score"))
    parser.add_argument("--output", type=Path, default=SCRIPT)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=True, parents=True)
    (freeze if args.phase == "freeze" else score)(args.output, *authenticated_roles())
