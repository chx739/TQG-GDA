"""Recompute two label-free R9 mechanism screens, writing only in the output directory."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import io
import itertools
import json
from pathlib import Path

import numpy as np


SETTINGS = ("mutagenicity_edge", "mutagenicity_node", "proteins_edge")
ARMS = ("target_anchor", "source_anchor", "target_free", "target_marginal")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load_inputs(root, setting, allowed):
    plan = read_json(root / "experiments/r5" / setting / "attempt-001/protocol/plan.json")
    base = Path(plan["input"]["raw_directory"])
    dataset = plan["dataset"]
    hashes = {}

    def read_column(suffix, delimiter=None):
        path = base / f"{dataset}_{suffix}.txt"
        raw = path.read_bytes()
        observed = sha(raw)
        assert observed == plan["input"]["files"][path.name]["sha256"]
        hashes[str(path)] = observed
        return np.loadtxt(io.BytesIO(raw), dtype=int, delimiter=delimiter)

    types = read_column("node_labels")
    graph_ids = read_column("graph_indicator") - 1
    edges = read_column("A", ",") - 1
    edge_labels = (read_column("edge_labels") if f"{dataset}_edge_labels.txt" in plan["input"]["files"]
                   else np.zeros(len(edges), dtype=int))
    assert (graph_ids[edges[:, 0]] == graph_ids[edges[:, 1]]).all()
    assert len(edge_labels) == len(edges)
    groups = defaultdict(list)
    neighbors = {}
    for node, graph_id in enumerate(graph_ids):
        if graph_id in allowed:
            groups[graph_id].append(node)
            neighbors[node] = {}
    for (i, j), label in zip(edges, edge_labels):
        if i in neighbors and i != j:
            if j in neighbors[i]:
                assert neighbors[i][j] == label
            neighbors[i][j] = label
            neighbors[j][i] = label
    assert set(groups) == allowed
    return types, groups, neighbors, hashes


def graph_inputs(types, groups, neighbors):
    catalog = {}
    moments, motifs = {}, {}
    for graph_id, nodes in groups.items():
        n = len(nodes)
        counts = np.unique(types[nodes], return_counts=True)[1]
        expected_same = (counts @ (counts - 1)) / (n * (n - 1)) if n > 1 else 0.0
        node_offsets = {node: j for j, node in enumerate(nodes)}
        same1 = same2 = size1 = size2 = 0
        tokens, forbidden = [], []
        for node in nodes:
            first = set(neighbors[node])
            second = set().union(*(neighbors[j] for j in first)).difference(first, {node})
            for j in first:
                if node < j:
                    size1 += 1
                    same1 += types[node] == types[j]
            for j in second:
                if node < j:
                    size2 += 1
                    same2 += types[node] == types[j]
            word = (int(types[node]), tuple(sorted((int(edge), int(types[j]))
                                                    for j, edge in neighbors[node].items())))
            tokens.append(catalog.setdefault(word, len(catalog)))
            forbidden.append(np.array([node_offsets[j] for j in first | second | {node}]))
        moments[graph_id] = (
            same1 / size1 - expected_same if size1 else 0,
            same2 / size2 - expected_same if size2 else 0,
            size1, size2,
        )
        motifs[graph_id] = np.array(tokens), forbidden
    return moments, motifs, {identifier: word for word, identifier in catalog.items()}


def measure_attenuation(key, setting, role, moments, rng):
    d_all, u_all = (np.array([moments[i] for i in role[p]]) for p in ("D", "U"))
    d, u = d_all[:, :2], u_all[:, :2]
    md, mu = d.mean(axis=0), u.mean(axis=0)
    db = d[rng.randint(len(d), size=(1500, len(d)))].mean(axis=1)
    ub = u[rng.randint(len(u), size=(1500, len(u)))].mean(axis=1)
    coef = mu[0] / md[0]
    ratio_bounds = np.quantile(ub[:, 0] / db[:, 0], [.025, .975])
    cross_bounds = np.quantile(db[:, 0] * ub[:, 1] - db[:, 1] * ub[:, 0], [.025, .975])
    return dict(
        setting=setting, direction=key, n_D=len(d), n_U=len(u),
        D_excess1=md[0], D_excess2=md[1], U_excess1=mu[0], U_excess2=mu[1],
        lambda_U1_over_D1=coef, lambda_ci_low=ratio_bounds[0], lambda_ci_high=ratio_bounds[1],
        det=md[0] * mu[1] - md[1] * mu[0], det_ci_low=cross_bounds[0], det_ci_high=cross_bounds[1],
        lambda_in_unit=int(0 <= coef <= 1),
        ratio_ci_outside_unit=int(ratio_bounds[0] > 1 or ratio_bounds[1] < 0),
        det_ci_excludes_zero=int(cross_bounds[0] > 0 or cross_bounds[1] < 0),
        D_covered1=int(np.sum(d_all[:, 2] > 0)), D_covered2=int(np.sum(d_all[:, 3] > 0)),
        U_covered1=int(np.sum(u_all[:, 2] > 0)), U_covered2=int(np.sum(u_all[:, 3] > 0)),
        D_unordered_pairs1=int(d_all[:, 2].sum()), D_unordered_pairs2=int(d_all[:, 3].sum()),
        U_unordered_pairs1=int(u_all[:, 2].sum()), U_unordered_pairs2=int(u_all[:, 3].sum()),
    )


def word_pair_matrix(record, vocab):
    tokens, forbidden = record
    width = len(vocab) + 1
    words = np.array([vocab.get(t, width - 1) for t in tokens])
    counts = np.bincount(words, minlength=width)
    pairs = np.outer(counts, counts)
    for j, blocked in enumerate(forbidden):
        pairs[words[j]] -= np.bincount(words[blocked], minlength=width)
    assert (pairs >= 0).all() and np.array_equal(pairs, pairs.T)
    size = int(pairs.sum())
    normalized = pairs / size if size else np.zeros_like(pairs, dtype=float)
    return normalized, size


def fit(agg, anchor):
    n = agg.shape[0]
    cond = (agg + 1 / n) / (agg.sum(axis=1, keepdims=True) + 1)
    left, right = cond[list(anchor)]
    line = right - left
    position = np.clip((cond - left) @ line / max(line @ line, 1e-15), 0, 1)
    return left + np.outer(position, line), cond


def score_anchor(key, setting, role, motifs, word_by_id):
    d, u = role["D"], role["U"]
    frequency = Counter(t for i in d for t in set(motifs[i][0]))
    keep = sorted(frequency, key=lambda t: (-frequency[t], word_by_id[t]))[:16]
    vocab = {t: j for j, t in enumerate(keep)}
    width = len(vocab) + 1
    pairs = {i: word_pair_matrix(motifs[i], vocab) for i in d + u}

    def aggregate(ids):
        return sum((pairs[i][0] for i in ids), np.zeros((width, width)))

    md = aggregate(d)
    eligible = [j for j, t in enumerate(keep) if frequency[t] >= max(10, len(d) * .05)
                and md[j].sum() > 0]
    assert len(eligible) >= 2
    _, prior = fit(md, (0, 1))
    anchor = max(itertools.combinations(eligible, 2),
                 key=lambda ab: np.linalg.norm(prior[ab[0]] - prior[ab[1]]))
    source_segment, _ = fit(md, anchor)
    ordered = sorted(u, key=lambda i: sha(f"anchor-role/v1|{setting}|{i}".encode()))
    folds = ordered[::2], ordered[1::2]
    fold_rows = []
    summed = np.zeros(4)
    total = 0
    metadata = dict(words=[word_by_id[t] for t in keep], anchors=anchor,
                    source_D=d, U_folds=[folds[0], folds[1]])
    for fold, (train, valid) in enumerate((folds, folds[::-1])):
        ma, mh = aggregate(train), aggregate(valid)
        denominator = mh.sum()
        missing = any(ma[j].sum() == 0 for j in anchor)
        target_segment, target_free = fit(ma, anchor)
        if missing:
            target_segment = source_segment
        marginal = (ma.sum(0) + 1 / width) / (ma.sum() + 1)
        scores = np.array([-np.sum(mh * np.log(p)) for p in
                           [target_segment, source_segment, target_free, marginal]])
        eligible_train = sum(pairs[i][1] > 0 for i in train)
        eligible_valid = sum(pairs[i][1] > 0 for i in valid)
        assert abs(denominator - eligible_valid) < 1e-8
        fold_rows.append(dict(
            setting=setting, direction=key, fold=fold, n_train=len(train),
            covered_train=eligible_train, n_valid=len(valid), covered_valid=eligible_valid,
            ordered_train_pairs=sum(pairs[i][1] for i in train),
            ordered_valid_pairs=sum(pairs[i][1] for i in valid),
            train_anchor_0_mass=float(ma[anchor[0]].sum()), train_anchor_1_mass=float(ma[anchor[1]].sum()),
            source_fallback=int(missing),
            **dict(zip(ARMS, scores / denominator)),
        ))
        total += denominator
        summed += scores
    return (dict(setting=setting, direction=key, n_D=len(d), n_U=len(u), n_U_covered=round(total),
                 **dict(zip(ARMS, summed / total))), fold_rows, metadata)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/home/hxchen/research/GDA/TSBA"))
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=True, parents=True)
    r9 = next((args.root / "repository/experiments/mutagenicity").glob(
        "r9_*/results/reference-geometry-001"))
    role_bytes = (r9 / "roles.json").read_bytes()
    assert sha(role_bytes) == read_json(r9 / "OBS.json")["files"]["roles.json"]
    roles = json.loads(role_bytes)
    hashes = {str(r9 / "roles.json"): sha(role_bytes)}
    attenuation_rows, anchor_rows, fold_rows, summary = [], [], [], []
    metadata = {}
    rng = np.random.RandomState(3405)
    for setting in SETTINGS:
        matching = {k: r["roles"] for k, r in roles.items() if r["setting"] == setting}
        ids = {i for role in matching.values() for p in ("D", "U") for i in role[p]}
        types, groups, neighbors, input_hashes = load_inputs(args.root, setting, ids)
        hashes.update(input_hashes)
        moments, motifs, word_by_id = graph_inputs(types, groups, neighbors)
        for key, role in matching.items():
            attenuation_rows.append(measure_attenuation(key, setting, role, moments, rng))
            item, folds, meta = score_anchor(key, setting, role, motifs, word_by_id)
            anchor_rows.append(item)
            fold_rows.extend(folds)
            metadata[key] = meta
        am = [r for r in attenuation_rows if r["setting"] == setting]
        an = [r for r in anchor_rows if r["setting"] == setting]
        fd = [r for r in fold_rows if r["setting"] == setting]
        summary.append(dict(setting=setting, n_directions=len(an), n_folds=len(fd),
            n_U=sum(r["n_U"] for r in an), n_U_covered=sum(r["n_U_covered"] for r in an),
            n_folds_missing_anchor=sum(r["source_fallback"] for r in fd),
            lambda_point_in_unit=sum(r["lambda_in_unit"] for r in am),
            ratio_ci_outside_unit=sum(r["ratio_ci_outside_unit"] for r in am),
            det_ci_excludes_zero=sum(r["det_ci_excludes_zero"] for r in am),
            **{arm: np.mean([r[arm] for r in an]) for arm in ARMS},
            anchor_wins_source=sum(r["target_anchor"] < r["source_anchor"] for r in an),
            anchor_wins_free=sum(r["target_anchor"] < r["target_free"] for r in an),
            anchor_wins_marginal=sum(r["target_anchor"] < r["target_marginal"] for r in an),
            free_wins_marginal=sum(r["target_free"] < r["target_marginal"] for r in an)))
    for name, data in [("summary", summary), ("attenuation-directions", attenuation_rows),
                       ("anchor-directions", anchor_rows), ("anchor-folds", fold_rows)]:
        write_csv(args.output / f"{name}.csv", data)
    for name, data in [("source-anchors-and-fold-ids", metadata), ("input-hashes", hashes)]:
        (args.output / f"{name}.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    print((args.output / "summary.csv").read_text())


if __name__ == "__main__":
    main()
