import csv
import hashlib
import json
from pathlib import Path
from collections import defaultdict

import numpy as np
from scipy.stats import spearmanr

out = Path(__file__).parent
base = Path('/home/hxchen/research/GDA/TSBA/repository/experiments/mutagenicity')
arch = next(base.glob('r9_*/results/attempt-002-weighted-residuals'))
plan = json.loads(next(base.glob('r5_*/results/execution/mutagenicity_edge/plan.json')).read_text())['input']
obs = json.loads((arch/'OBS.json').read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(arch/'roles.json') == obs['files']['roles.json']
roles = {k:v for k,v in json.loads((arch/'roles.json').read_text()).items() if v['setting']=='mutagenicity_edge'}
inputs = {}
for k in ['graph_indicator','node_labels','A']:
    name = f'Mutagenicity_{k}.txt'
    path = Path(plan['raw_directory'])/name
    inputs[k] = (str(path), sha(path))
    assert inputs[k][1] == plan['files'][name]['sha256']
roles_used = sorted({g for row in roles.values() for role in ['U','C'] for g in row['roles'][role]})
gids = np.loadtxt(inputs['graph_indicator'][0],dtype=int)-1
ty = np.loadtxt(inputs['node_labels'][0],dtype=int)
edges = np.loadtxt(inputs['A'][0],dtype=int,delimiter=',')-1
adj = [set() for _ in gids]
for a,b in edges:
    assert gids[a]==gids[b]
    if a!=b:
        adj[a].add(b)
        adj[b].add(a)
nodes=defaultdict(list)
for v,g in enumerate(gids):
    nodes[g].append(v)
n, m, opp, close = {}, {}, {}, {}
for g in roles_used:
    n[g] = len(nodes[g])
    m[g] = sum(len(adj[v]) for v in nodes[g])//2
    O=[0]*4
    C=[0]*4
    for start in nodes[g]:
        def visit(path,depth):
            v=path[-1]
            if depth >= 4 and start<v:
                k=2*(depth-4) + int(ty[start]==ty[v])
                O[k]+=1
                if start in adj[v]:
                    C[k]+=1
            if depth<5:
                for w in adj[v]:
                    if w not in path:
                        visit(path+(w,),depth+1)
        visit((start,),0)
    opp[g]=np.array(O)
    close[g]=np.array(C)
def hashorder(tag, ids):
    return sorted(ids,key=lambda i:hashlib.sha256(f'ring-precheck-v1|{tag}|{i}'.encode()).digest())
def summary_rates(ids):
    O=sum(opp[i]/n[i] for i in ids)
    C=sum(close[i]/n[i] for i in ids)
    support=np.sum([opp[i]>0 for i in ids],axis=0)
    assert np.all(O>0)
    typed=C/O
    length=np.repeat(C.reshape(2,2).sum(1)/O.reshape(2,2).sum(1),2)
    return typed,length,support
def write_table(path,rows):
    with path.open('w') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
results,foldrows,graphids,counts=[],[],{},[]
for i in roles_used:
    counts.append(dict(graph=i,nodes=n[i],edges=m[i],**{f'O{k}':opp[i][k] for k in range(4)},**{f'C{k}':close[i][k] for k in range(4)}))
write_table(out/'per_graph_counts.csv',counts)
for tag,r in roles.items():
    cids=r['roles']['C']; uids=r['roles']['U']
    assert not set(cids)&set(uids)
    cut=r['cut']
    small_source=r['direction']=='small_to_large'
    assert all((m[i]<=cut)==small_source for i in cids) and all((m[i]>cut)==small_source for i in uids)
    uorder=hashorder(tag+'-U',uids)
    corder=hashorder(tag+'-C',cids)
    per_dir=[]; missing=0; supports=[]; pairs=[]; grouped_delta=[]; scalars=[]; sized=[]
    for fold in range(2):
        evalu=uorder[fold::2]
        ref=uorder[1-fold::2][:len(corder)]
        source=corder[:len(ref)]
        assert len(source)==len(ref) and not set(ref)&set(evalu)
        graphids[f'{tag}-{fold}']={'source':source,'target':ref,'evaluation':evalu}
        sourcep,sourcelen,scount=summary_rates(source)
        ownp,ownlen,ocount=summary_rates(ref)
        supports.extend([scount.min(),ocount.min()])
        scores=[]; dev=[]; evalsize=[];evalnode=[];evalclose=[]
        for g in evalu:
            O,C=opp[g],close[g]
            assert np.all(C<=O)
            if O.sum()==0:
                missing+=1;continue
            def brier(p):
                return float((C*(1-p)**2+(O-C)*p**2).sum()/O.sum())
            scores.append([brier(p) for p in [ownp,sourcep,ownlen,sourcelen]])
            d=(sourcep-ownp)*O/n[g]
            dev.append(d)
            evalsize.append(m[g]);evalnode.append(n[g]);evalclose.append(float(C.sum()/O.sum()))
        per_dir.extend(scores)
        dev=np.array(dev)
        bins=defaultdict(list)
        for j,key in enumerate(evalsize):
            bins[key].append(j)
        within=dev.copy()
        for idx in bins.values():
            within[idx]=dev[idx]-dev[idx].mean(0)
        grouped_delta.extend(np.linalg.norm(within,axis=1).tolist())
        scalars.extend((dev.sum(1)-dev.sum(1).mean()).tolist())
        sized.extend((np.array(evalsize)-np.mean(evalsize)).tolist())
        pairs.extend(np.linalg.norm(dev-dev.mean(0),axis=1).tolist())
        foldrows.append(dict(tag=tag,fold=fold,m=len(source),evaluation=len(evalu),valid=len(scores),own=ownp.tolist(),source=sourcep.tolist(),own_source_pdiff=(ownp-sourcep).tolist(),supportU=ocount.tolist(),supportC=scount.tolist(),close_rate_size_rho=spearmanr(evalsize,evalclose).statistic,closure_threshold=None))
    av=np.mean(per_dir,axis=0)
    results.append(dict(direction=f"M{r['source']}_{r['direction']}",ref=foldrows[-1]['m'],U=len(uids),valid=len(per_dir),uncovered=missing,smallest_ref_graph_support=min(supports),own=av[0],source=av[1],length=av[2],source_length=av[3],source_minus_own=av[1]-av[0],length_minus_own=av[2]-av[0],rms_vary=float(np.sqrt(np.mean(np.square(pairs)))),rms_same_edge=float(np.sqrt(np.mean(np.square(grouped_delta)))),size_corr_unitweights=float(np.corrcoef(scalars,sized)[0,1]),rho_close_size=(foldrows[-1]['close_rate_size_rho']+foldrows[-2]['close_rate_size_rho'])/2))
write_table(out/'directions.csv',results)
(out/'folds.json').write_text(json.dumps(foldrows,indent=2))
(out/'roles_used.json').write_text(json.dumps(graphids))
(out/'inputs.json').write_text(json.dumps({'structural_inputs':inputs,'R9_roles':sha(arch/'roles.json'),'script':sha(Path(__file__))},indent=2))
for r in results:
    print(r['direction'], 'budget',r['ref'],'valid/total',r['valid'],r['U'],'min S', r['smallest_ref_graph_support'],'scores',*[round(r[k],6) for k in ['own','source','length','source_minus_own','length_minus_own','rms_vary','rms_same_edge','rho_close_size']])
for k in ['own','source','length','source_length','source_minus_own','length_minus_own','rms_vary','rms_same_edge','rho_close_size']:
    print(k,np.mean([r[k] for r in results]))
print('counts',len(roles_used),sum(r['valid'] for r in results),'/',sum(r['U'] for r in results),'wins',sum(r['source_minus_own']>0 for r in results),sum(r['length_minus_own']>0 for r in results))
