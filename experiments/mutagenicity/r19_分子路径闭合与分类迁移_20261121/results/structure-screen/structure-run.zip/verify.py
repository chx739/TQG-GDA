import csv
from itertools import combinations
import json
from pathlib import Path
from collections import defaultdict
import numpy as np

out = Path(__file__).parent
inputs=json.loads((out/'inputs.json').read_text())['structural_inputs']
nodes=defaultdict(list)
with open(inputs['graph_indicator'][0]) as f:
    for i,line in enumerate(f,1):
        nodes[int(line)-1].append(i)
with open(inputs['node_labels'][0]) as f:
    types=[None]+[int(line) for line in f]
adj=defaultdict(set)
with open(inputs['A'][0]) as f:
    for line in f:
        a,b=map(int,line.split(','))
        if a!=b:
            adj[a].add(b)
            adj[b].add(a)
with (out/'per_graph_counts.csv').open() as f:
    recs=list(csv.DictReader(f))
verified={}
for rec in recs:
    g=int(rec['graph'])
    O=[0]*4;C=[0]*4
    for mid in nodes[g]:
        for a,b in combinations(adj[mid],2):
            for p in adj[a]-{mid,b}:
                for q in adj[b]-{mid,a,p}:
                    k=int(types[p]==types[q])
                    O[k]+=1;C[k]+=int(p in adj[q])
        for other in adj[mid]:
            if mid>=other:
                continue
            for a in adj[mid]-{other}:
                for b in adj[other]-{mid,a}:
                    for p in adj[a]-{mid,other,b}:
                        for q in adj[b]-{mid,other,a,p}:
                            k=2+int(types[p]==types[q])
                            O[k]+=1;C[k]+=int(p in adj[q])
    assert O==[int(rec['O'+str(k)]) for k in range(4)],g
    assert C==[int(rec['C'+str(k)]) for k in range(4)],g
    assert sum(C[:2])%5==0 and sum(C[2:])%6==0
    verified[g]=np.array([O,C],float)
folds=json.loads((out/'roles_used.json').read_text()); scores=defaultdict(list)
for f,r in folds.items():
    assert not set(r['evaluation'])&(set(r['source'])|set(r['target']))
    def rates(ids):
        v=sum(verified[g]/len(nodes[g]) for g in ids)
        x,y=v
        return [y/x,np.repeat([y[:2].sum()/x[:2].sum(),y[2:].sum()/x[2:].sum()],2)]
    own,ol=rates(r['target'])
    src,sl=rates(r['source'])
    for g in r['evaluation']:
        O,C=verified[g]
        if O.sum():
            scores[f.rsplit('-',1)[0]].append([np.sum(O*p*p + C*(1-2*p))/O.sum() for p in [own,src,ol,sl]])
means=np.mean([np.mean(s,axis=0) for s in scores.values()],axis=0)
with (out/'directions.csv').open() as f:
    dirs=list(csv.DictReader(f))
orig=np.mean([[float(r[k]) for k in ('own','source','length','source_length')] for r in dirs],axis=0)
assert np.max(abs(orig-means))<1e-14
rows=dict(verified_graphs=len(verified),path_counts_checked=8*len(verified),eligible_graphs=sum(map(len,scores.values())),mean_brier=means.tolist(),max_error=float(np.max(abs(orig-means))),size_pearson_unitweights_per_direction=[float(r['size_corr_unitweights']) for r in dirs],
         per_fold_mean_spearman_graph_closure_fraction_and_edges=[float(r['rho_close_size']) for r in dirs])
print(json.dumps(rows))
(out/'independent-verification.json').write_text(json.dumps(rows,indent=2))
