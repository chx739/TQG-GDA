"""Frozen C-independent experts and one prespecified structural split. Read no E/H members or classes."""
from pathlib import Path
import hashlib, json, csv, statistics
from fractions import Fraction
import numpy as np
import torch
from torch_geometric.data import Data
from experiments.mutagenicity.r10_原生图适配基线与增量_20261121.src import structural, source_attributes
from experiments.mutagenicity.r8_图结构观察量与类别约束_20261121.src.composition import scores
from experiments.mutagenicity.r9_目标近邻与源标签传递_20261121.src import residual_models
BASE = Path('/home/hxchen/research/GDA/TSBA')
ROOT = BASE/'repository/experiments/mutagenicity'
R9 = next(ROOT.glob('r9_*/results/attempt-002-weighted-residuals'))
R10 = next(ROOT.glob('r10_*/results/attempt-005-source-attributes'))
OUT = Path('/tmp/r19-spectral-feasibility')
def load(p): return json.loads(p.read_bytes())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def checked(root, files, name):
    path = root/name
    assert digest(path)==files[name]
    return path
m9,m10 = (load(p/'OBS.json')['files'] for p in (R9,R10))
roles=load(checked(R9,m9,'roles.json'))
source=load(checked(R9,m9,'source-provenance.json'))
def graph_stats(g):
    assert set(g)=={'edge_index','edge_attr','x'}
    types = g['x'].numpy().argmax(axis=1)
    edges = { (min(a,b),max(a,b)) for a,b in g['edge_index'].numpy().T.tolist() if a!=b }
    return len(types), len(edges), Fraction(sum(types[a]!=types[b] for a,b in edges),len(edges)) if edges else Fraction(0)
def risk_pair(setting,k,role,qc,dd,uu,eligible_n,md,arm,a,b,y):
    d = np.asarray((a>0)==y,dtype=int)-np.asarray((b>0)==y,dtype=int)
    low=~qc
    results={}
    for name,sel in [('low',low),('high',qc)]:
        results[name+'_n']=int(sel.sum())
        results[name+'_leftonly']=int((d[sel]==1).sum())
        results[name+'_rightonly']=int((d[sel]==-1).sum())
        results[name+'_net']=int(d[sel].sum())
    totals=[results['low_n'],results['high_n']]
    net=[results['low_net'],results['high_net']]
    ucounts=[len(uu)-sum(uu),sum(uu)]
    raw=Fraction(sum(net),sum(totals))
    target=None if min(totals)==0 else sum(Fraction(t,n)*Fraction(u,len(uu)) for t,n,u in zip(net,totals,ucounts))
    return dict(setting=setting,block=k,source=role['source'],direction=role['direction'],pair=arm,
                D_n=len(dd),D_high=sum(dd),U_n=len(uu),U_high=sum(uu),
                D_edgeless=eligible_n[0],C_edgeless=eligible_n[1],U_edgeless=eligible_n[2],
                median_D=float(md),**results,crossover=int(net[0]*net[1]<0),
                pos_on_high=int(net[0]<0<net[1]),pos_on_low=int(net[1]<0<net[0]),
                C_net_pp=float(raw*100),U_weighted_C_net_pp=None if target is None else float(target*100),
                preference_flip=None if target is None else int((raw>0 and target<0) or (raw<0 and target>0)),
                D_U_high_shift_pp=100*(sum(uu)/len(uu)-sum(dd)/len(dd)))
rows=[]
for setting in ['mutagenicity_edge','mutagenicity_node','proteins_edge']:
    p=BASE/'experiments/r5'/setting/'attempt-001'
    graphs_path=checked(p,source[setting],'inputs/graphs.pt')
    graphs=torch.load(graphs_path,map_location='cpu',weights_only=True,mmap=True)
    plan=load(checked(p,source[setting],'protocol/plan.json'))
    rec=load(checked(p,source[setting],'inputs/label_records.json'))
    assert rec['sha256']==plan['input']['files'][Path(rec['path']).name]['sha256']
    if setting=='proteins_edge': owners,types,values,_=source_attributes.raw_columns(plan,len(graphs))
    for k,role in roles.items():
        if role['setting']!=setting: continue
        ids={s:role['roles'][s] for s in ('D','C','U')}
        assert sum(map(len,ids.values()))==len(set(sum(ids.values(),[])))
        stats = {s:[graph_stats(graphs[i]) for i in v] for s,v in ids.items()}
        median = statistics.median([g[2] for g in stats['D']])
        mask={s:[bool(g[2]>median) for g in stats[s]] for s in stats}
        noedges=[sum(n[1]==0 for n in stats[s]) for s in ('D','C','U')]
        with Path(rec['path']).open('rb',buffering=0) as stream:
            labels=[]
            for i in ids['C']:
                offset,span=rec['offsets'][i];stream.seek(offset)
                labels.append(rec['mapping'][str(int(stream.read(span)))])
        y=np.asarray(labels)
        m=load(checked(R9,m9,'models/'+k+'.json'))
        features_c={i:structural.features(Data(**graphs[i]),setting) for i in ids['C']}
        left,right=residual_models.margins(m,features_c,ids['C'])
        verify_u=ids['U'][:1]
        feature_u={i:structural.features(Data(**graphs[i]),setting) for i in verify_u}
        left_u,right_u=residual_models.margins(m,feature_u,verify_u)
        with np.load(checked(R9,m9,'predictions/'+k+'.npz'),allow_pickle=False) as pred:
            assert np.array_equal(pred['u_ids'],ids['U'])
            assert np.allclose([left_u[0],right_u[0]],[pred['wl_u'][0],pred['size_u'][0]],rtol=1e-13,atol=1e-13)
        args=(setting,k,role,np.array(mask['C']),mask['D'],mask['U'],noedges,median)
        rows.append(risk_pair(*args,'WL1-Size1',left,right,y))
        if setting=='proteins_edge':
            new=load(checked(R10,m10,'models/'+k+'.json'))
            if new['fit']['status']=='single_class_D': attr=np.full(len(y),new['fit']['constant'])
            else:
                features={}
                for i in ids['C']:
                    graph=graphs[i]
                    f,z=features_c[i]
                    med,_=source_attributes.graph_attributes(i,graph,owners,types,values)
                    features[i]=f,z,med
                design=source_attributes.design_for(features,ids['C'],new['design'])
                attr=scores(design['Attribute'],new['fit']['candidates']['1.0'])
                stored=next(v for v in new['fit']['validation'] if v['C']==1.0)
                assert structural.validation_metrics(1.0,attr,y)==stored
            rows.append(risk_pair(*args,'Attribute1-WL1',attr,left,y))
with (OUT/'blocks.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
for key in sorted({(r['setting'],r['pair']) for r in rows}):
    rr=[r for r in rows if (r['setting'],r['pair'])==key]
    print(key,{p:sum(r[p] for r in rr) for p in ['D_n','D_high','U_n','U_high','D_edgeless','C_edgeless','U_edgeless','low_n','high_n','low_leftonly','low_rightonly','high_leftonly','high_rightonly','crossover','pos_on_high','pos_on_low']},'flip',sum(r['preference_flip']==1 for r in rr),'eligible',sum(r['preference_flip']!=None for r in rr),'meanAbsShift',np.mean([abs(r['D_U_high_shift_pp']) for r in rr]),'UhiSmallLarge',[round(100*sum(r['U_high'] for r in rr if r['direction']==side)/sum(r['U_n'] for r in rr if r['direction']==side),1) for side in ('small_to_large','large_to_small')])
