from pathlib import Path
from collections import defaultdict
import json, hashlib, random, subprocess
import networkx as nx
from networkx.algorithms.isomorphism import GraphMatcher, categorical_node_match, categorical_edge_match
folder=Path('/tmp/r9-natural-contain')
root=Path('/home/hxchen/research/GDA/TSBA/repository')
archive=next((root/'experiments/mutagenicity').glob('r9*/results/attempt-002*'))
roles_file=archive/'roles.json'
roles=json.loads(roles_file.read_bytes())
nm=categorical_node_match('t',None)
em=categorical_edge_match('t',None)
def digest(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()
def read_graphs(path):
 g={}
 with path.open() as f:
  for _ in range(int(next(f))):
   gid,n,m,*labels=map(int,next(f).split())
   assert n==len(labels)
   h=nx.Graph()
   h.add_nodes_from((v,{'t':t}) for v,t in enumerate(labels))
   for _ in range(m):
    u,v,t=map(int,next(f).split())
    h.add_edge(u,v,t=t)
   g[gid]=h
 return g
audit={'roles_sha256':digest(roles_file),'source_code':{name:digest(folder/name) for name in ['prepare.py','search.cpp','freeze.py']},'inputs':{},'directions':{},'summaries':{},'independent_oracle_checks':[]}
for s in sorted({r['setting'] for r in roles.values()}):
 # Legacy names from the first run used no explicit 'E' affix.
 for role,tag in [('E',''),('U','.U')]:
  data=folder/(s+tag+'.input')
  out=folder/(s+tag+'.witness')
  g=read_graphs(data)
  audit['inputs'][data.name]=digest(data)
  audit['inputs'][out.name]=digest(out)
  rows=defaultdict(dict)
  unknown=defaultdict(set)
  for line in out.read_text().splitlines():
   src,d,i,j,state,*f=map(int,line.split())
   if state<0:
    unknown[src,d].add((i,j))
    continue
   hs,hb=(g[i],g[j]) if d else (g[j],g[i])
   assert len(f)==len(hs)<len(hb) and len(set(f))==len(f)
   sub=hb.subgraph(f)
   assert len(sub.edges)==len(hs.edges)
   assert all(hs.nodes[n]['t']==hb.nodes[f[n]]['t'] for n in hs)
   assert all(sub.has_edge(f[u],f[v]) and sub.edges[f[u],f[v]]['t']==attrs['t'] for u,v,attrs in hs.edges(data=True))
   assert (i,j) not in rows[src,d]
   rows[src,d][i,j]=f
  sums=defaultdict(int)
  for key,r in roles.items():
   if r['setting']!=s:continue
   src,d=r['source'],int(r['direction']=='small_to_large')
   D,rids=r['roles']['D'],r['roles'][role]
   verified=rows[src,d]; und=unknown[src,d]
   assert all(i in D and j in rids for i,j in list(verified)+list(und))
   covered_ids=sorted({j for i,j in verified})
   counts={'pairs':len(D)*len(rids),'hit_pairs':len(verified),'budget_unresolved':len(und),'covered':len(covered_ids),'attempted':len(rids),'matched_D':len({i for i,j in verified})}
   sums.update({})  # Counts are direction-exposures; D-U doubles each unordered pair.
   for k,v in counts.items():sums[k]+=v
   audit['directions'][key+'-'+role]=dict(**counts,covered_ids=covered_ids,donor_recipient_pairs=[list(p) for p in sorted(verified)])
   # Stratified pass/fail checks with an independent generic solver. All positive witnesses above already verified.
   random_gate=random.Random(142+src*2+d)
   sample=[(random_gate.choice(D),random_gate.choice(rids)) for _ in range(12)]
   sample+=random_gate.sample(sorted(verified),min(3,len(verified)))
   for i,j in sample:
    a,b=(g[i],g[j]) if d else (g[j],g[i])
    if len(b)>100 or len(a)>30: continue
    ref=len(a)<len(b) and GraphMatcher(b,a,node_match=nm,edge_match=em).subgraph_is_isomorphic()
    assert (i,j) in und or ref==((i,j) in verified),(i,j)
    audit['independent_oracle_checks'].append([s,role,src,d,i,j,int(ref)])
  audit['summaries'][s+'-'+role]=dict(sums)
  print(s,role,dict(sums),flush=True)
audit['criteria']={'containment':'Proper induced subgraph embedding, preserves node and bond types. All crossings of the historical within-source size cut. No connectedness or minimum size constraint. D supplies the label and U or E is the recipient.','max_dfs_nonterminal_states_per_pair':600,'class_labels_accessed':False}
path=folder/'structural-freeze.json'
path.write_text(json.dumps(audit,indent=2)+'\n')
print('audit',digest(path),'independent comparisons',len(audit['independent_oracle_checks']),flush=True)
