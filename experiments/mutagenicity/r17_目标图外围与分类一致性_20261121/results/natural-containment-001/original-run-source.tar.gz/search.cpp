#include <cstdio>
#include <vector>
#include <algorithm>
#include <numeric>
#include <unordered_map>
#include <array>
#include <utility>
#include <cassert>
using namespace std;
struct G{
 int n,m; vector<int> lab; vector<vector<int>> adj; vector<vector<signed char>> bond;
 vector<vector<pair<int,int>>> neighbor_hist; vector<pair<int,int>> global;
};
vector<pair<int,int>> compact(unordered_map<int,int> v){
 vector<pair<int,int>> r(v.begin(),v.end());sort(r.begin(),r.end());return r;
}
bool contains(const vector<pair<int,int>>& big,const vector<pair<int,int>>& small){
 int j=0;
 for(auto x:small){
  while(j<(int)big.size() && big[j].first<x.first)j++;
  if(j==(int)big.size()||big[j].first!=x.first||big[j].second<x.second)return false;
 }
 return true;
}
struct Match {
 const G &s,&b;
 vector<vector<int>> cand;
 vector<int> mapping,used;
 int budget=600;
 Match(const G&a,const G&h):s(a),b(h){}
 int visit(int done){
  if(done==s.n)return 1;
  if(--budget<0)return -1;
  int i=-1, priority=-1, csize=0, degree=0;
  for(int v=0;v<s.n;v++){
   if(mapping[v]>=0)continue;
   int mapped_neigh=0;
   for(int n:s.adj[v])mapped_neigh+=mapping[n]>=0;
   int nc=cand[v].size(), dg=s.adj[v].size();
   if(i<0 || mapped_neigh>priority || (mapped_neigh==priority && (nc<csize || (nc==csize && dg>degree)))){
    i=v;priority=mapped_neigh;csize=nc;degree=dg;
   }
  }
  int anchor=-1;
  for(int n:s.adj[i])if(mapping[n]>=0 && (anchor<0 || b.adj[mapping[n]].size()<b.adj[anchor].size()))anchor=mapping[n];
  auto &options=(anchor>=0 && b.adj[anchor].size()<cand[i].size())?b.adj[anchor]:cand[i];
  for(int t:options){
   if(used[t] || !binary_search(cand[i].begin(),cand[i].end(),t))continue;
   bool ok=true;
   for(int j=0;j<s.n;j++)if(mapping[j]>=0 && s.bond[i][j]!=b.bond[t][mapping[j]]){ok=false;break;}
   if(!ok)continue;
   mapping[i]=t;used[t]=1;
   int out=visit(done+1);
   if(out!=0)return out;
   mapping[i]=-1;used[t]=0;
  }
  return 0;
 }
 int solve(){
  if(s.n>=b.n || s.m>b.m || !contains(b.global,s.global))return 0;
  cand.resize(s.n);mapping.assign(s.n,-1);used.assign(b.n,0);
  for(int i=0;i<s.n;i++){
   for(int j=0;j<b.n;j++)if(s.lab[i]==b.lab[j] && b.adj[j].size()>=s.adj[i].size() && contains(b.neighbor_hist[j],s.neighbor_hist[i]))cand[i].push_back(j);
   if(cand[i].empty())return 0;
  }
  return visit(0);
 }
};
int main(){
 int N; if(scanf("%d",&N)!=1)return 1;
 unordered_map<int,G> graphs;
 for(int k=0;k<N;k++){
  int id,n,m;assert(scanf("%d%d%d",&id,&n,&m)==3);
  auto&g=graphs[id];g.n=n;g.m=m;g.lab.resize(n);g.adj.resize(n);g.bond.assign(n,vector<signed char>(n,-1));g.neighbor_hist.resize(n);
  unordered_map<int,int> total;vector<unordered_map<int,int>> local(n);
  for(int& x:g.lab){assert(scanf("%d",&x)==1);total[x]++;}
  for(int j=0;j<m;j++){
   int v,w,e;assert(scanf("%d%d%d",&v,&w,&e)==3);
   g.adj[v].push_back(w);g.adj[w].push_back(v);
   g.bond[v][w]=g.bond[w][v]=e;
   local[v][e*100+g.lab[w]]++;local[w][e*100+g.lab[v]]++;
   total[10000+e*10000+min(g.lab[v],g.lab[w])*100+max(g.lab[v],g.lab[w])]++;
  }
  g.global=compact(total);
  for(int v=0;v<n;v++)g.neighbor_hist[v]=compact(local[v]);
 }
 int src,dir,n,m;
 while(scanf("%d%d%d%d",&src,&dir,&n,&m)==4){
  vector<int>D(n),E(m);for(int&x:D)assert(scanf("%d",&x)==1);for(int&x:E)assert(scanf("%d",&x)==1);
  int hit=0,unknown=0;
  for(int i:D)for(int j:E){
   Match matcher(graphs[dir?i:j],graphs[dir?j:i]);
   int got=matcher.solve();if(got!=0){
    printf("%d %d %d %d %d",src,dir,i,j,got);
    if(got>0){for(int x:matcher.mapping)printf(" %d",x);hit++;}else unknown++;
    puts("");
   }
  }
  fprintf(stderr,"%d %d total %d witnesses %d unresolved %d\n",src,dir,n*m,hit,unknown);fflush(stdout);
 }
}
