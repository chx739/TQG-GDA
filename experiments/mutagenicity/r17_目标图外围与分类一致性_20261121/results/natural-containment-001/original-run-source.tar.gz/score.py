from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
import hashlib, json, subprocess
import torch

folder=Path('/tmp/r9-natural-contain')
repo=Path('/home/hxchen/research/GDA/TSBA/repository')
round9=next((repo/'experiments/mutagenicity').glob('r9*/results/attempt-002*'))
commit='743cef9f32c580b3e34196b8fe7fe8d391b5aeb0'
rule_path=next((repo/'experiments/mutagenicity').glob('r17*/docs/natural-containment.md')).relative_to(repo)
registered=subprocess.check_output(['git','-C',str(repo),'show',commit+':'+str(rule_path)])
assert (repo/rule_path).read_bytes()==registered
def sha(buf):return hashlib.sha256(buf).hexdigest()
def checked(path, digest):
 buf=path.read_bytes()
 if sha(buf)!=digest:raise ValueError(path)
 return buf
frozen_hash='61a7bdd99aa18f52f181c49a158881f0971b8b53531e95651abbcd59e1f48644'
frozen=json.loads(checked(folder/'structural-freeze.json',frozen_hash))
roles=json.loads(checked(round9/'roles.json',frozen['roles_sha256']))
prov=json.loads((round9/'source-provenance.json').read_bytes())
out={'protocol_commit':commit,'protocol_sha256':sha(registered),'structural_freeze_sha256':frozen_hash,
     'script_sha256':sha(Path(__file__).read_bytes()),'directions':{},'provenance':{},'setting_summaries':{}}
field=['weighted_pair_agreement','expected_size_stratified_agreement','majority_accuracy','size_prior_accuracy']
def counts_and_rates(groups,yd,ye,sizes):
    ne=len(groups)
    # Unit mass to each recipient, split equally among its observed donors.
    mass=defaultdict(F);posD=defaultdict(F);posE=defaultdict(F)
    n_pairs=Counter()
    same=opposite=any_opposite=any_same=all_opposite=0
    w_agree=F(0); votes=0
    for e,ds in groups.items():
        w=F(1,ne*len(ds)); correct=sum(yd[d]==ye[e] for d in ds)
        same+=correct;opposite+=len(ds)-correct
        any_opposite+=correct<len(ds);any_same+=correct>0;all_opposite+=correct==0
        votes+=(sum(yd[d] for d in ds)*2>len(ds))==ye[e]
        w_agree+=w*correct
        for d in ds:
            n=sizes[d]
            mass[n]+=w;posD[n]+=w*yd[d];posE[n]+=w*ye[e]; n_pairs[n]+=1
    assert sum(mass.values())==1
    expected=F(0);pD={};informative_sizes=0;informative_mass=F(0)
    single_pair=0;d_constant=0;e_constant=0
    for n,w in mass.items():
        pD[n]=posD[n]/w; pE=posE[n]/w
        expected+=w*(pD[n]*pE+(1-pD[n])*(1-pE))
        single_pair+=n_pairs[n]==1
        d_constant+=pD[n] in (0,1)
        e_constant+=pE in (0,1)
        if 0<pD[n]<1 and 0<pE<1:
            informative_sizes+=1;informative_mass+=w
    prior_votes=sum((2*sum(pD[sizes[d]] for d in ds)>len(ds))==ye[e] for e,ds in groups.items())
    rates=list(map(float,(w_agree,expected,F(votes,ne),F(prior_votes,ne))))
    return dict(agreeing_pairs=same,opposing_pairs=opposite,any_opposing_E=any_opposite,
                any_agreeing_E=any_same,all_opposing_E=all_opposite,
                majority_correct=votes,size_prior_correct=prior_votes,
                strata=dict(total=len(mass),single_pair=single_pair,one_D_class=d_constant,one_E_class=e_constant,
                            both_margins_nonconstant=informative_sizes,both_margins_nonconstant_weight=float(informative_mass)),
                **dict(zip(field,rates)))
for setting,seal in prov.items():
    base=repo.parent/'experiments/r5'/setting/'attempt-001'
    plan=json.loads(checked(base/'protocol/plan.json',seal['protocol/plan.json']))
    record=json.loads(checked(base/'inputs/label_records.json',seal['inputs/label_records.json']))
    graph_ids=json.loads(checked(base/'inputs/graph_hashes.json',seal['inputs/graph_hashes.json']))
    graph_file=base/'inputs/graphs.pt'
    checked(graph_file,seal['inputs/graphs.pt'])
    graphs=torch.load(graph_file,weights_only=True,map_location='cpu')
    expected=Path(plan['input']['raw_directory'])/(plan['dataset']+'_graph_labels.txt')
    label_file=expected.resolve()
    clsmeta=plan['input']['files'][expected.name]
    assert Path(record['path']).resolve()==label_file and clsmeta['sha256']==record['sha256']
    assert label_file.stat().st_size==clsmeta['bytes']
    stat_before=label_file.stat()
    assert plan['input']['graph_id']=='TU graph number minus one'
    assert [q['id'] for q in graph_ids]==list(range(len(graphs))) and len(record['offsets'])==len(graphs)
    classes=record['mapping'];assert set(classes.values())=={0,1}
    verified=set();parsed=[];summary=Counter();rate_sums=Counter()
    for task,r in roles.items():
        if r['setting']!=setting:continue
        rec=frozen['directions'][task+'-E']
        assert rec['budget_unresolved']==0
        groups=defaultdict(list)
        for d,e in rec['donor_recipient_pairs']:
            assert d in r['roles']['D'] and e in r['roles']['E']
            groups[e].append(d)
        donor=sorted({d for ds in groups.values() for d in ds})
        recipients=sorted(groups)
        assert recipients==rec['covered_ids'] and len(donor)==rec['matched_D'] and len(recipients)==rec['covered']
        row=dict(total_E=rec['attempted'],matched_E=len(recipients),matched_D=len(donor),matched_pairs=rec['hit_pairs'])
        if groups:
            def read_labels(ids):
                result={}
                with label_file.open('rb',buffering=0) as stream:
                    for i in ids:
                        assert i not in result
                        if i not in verified:
                            actual={k:None if v is None else sha(v.numpy().tobytes()) for k,v in graphs[i].items()}
                            assert actual==graph_ids[i]['input_sha256']
                            verified.add(i)
                        start,length=record['offsets'][i]
                        assert 0<=start and length>0
                        stream.seek(start)
                        raw=stream.read(length)
                        assert len(raw)==length
                        result[i]=classes[str(int(raw))]
                        parsed.append([task,i])
                return result
            sizes={d:len(graphs[d]['x']) for d in donor}
            stats=counts_and_rates(groups,read_labels(donor),read_labels(recipients),sizes)
            row.update(stats)
            for k in field:rate_sums[k]+=row[k]*len(recipients)
        else:
            row.update({k:None for k in field+['agreeing_pairs','opposing_pairs','any_opposing_E','any_agreeing_E','all_opposing_E','majority_correct','size_prior_correct','strata']})
        out['directions'][task]=row
        for k in ('total_E','matched_E','matched_D','matched_pairs','agreeing_pairs','opposing_pairs','any_opposing_E','majority_correct','size_prior_correct'):
            summary[k]+=row[k] or 0
    assert stat_before==label_file.stat() or (stat_before.st_size,stat_before.st_mtime_ns,stat_before.st_ino)==(label_file.stat().st_size,label_file.stat().st_mtime_ns,label_file.stat().st_ino)
    expected_access=[]
    for task,r in roles.items():
        if r['setting']!=setting:continue
        pairs=frozen['directions'][task+'-E']['donor_recipient_pairs']
        expected_access.extend([task,i] for i in sorted({d for d,e in pairs})+sorted({e for d,e in pairs}))
    assert parsed==expected_access
    out['setting_summaries'][setting]=dict(summary,**{k:rate_sums[k]/summary['matched_E'] if summary['matched_E'] else None for k in field})
    out['provenance'][setting]=dict(graph_number_convention=plan['input']['graph_id'],count=len(graphs),
        input_graph_container_sha256=seal['inputs/graphs.pt'],graph_record_inventory_sha256=seal['inputs/graph_hashes.json'],
        catalog_plan_sha256=seal['protocol/plan.json'],label_offset_catalog_sha256=seal['inputs/label_records.json'],
        raw_label_file=str(label_file),registered_raw_label_sha256=record['sha256'],
        current_label_checks='registered path, registered file size, stable inode/mtime, read only matched graph offsets',
        graph_tensors_individually_verified=len(verified),unique_parsed_graphs=len({i for task,i in parsed}),
        parsed_directional_records=len(parsed),role_access_exact=True,U_label_requests=0,
        read_graph_id_sequence_sha256=sha(json.dumps(parsed,separators=(',',':')).encode()))
path=folder/'supervised-score.json'
path.write_text(json.dumps(out,indent=2)+'\n')
for k,r in out['directions'].items():
 if r['matched_E']:print(k,r)
print(out['setting_summaries'])
print(sha(path.read_bytes()),path)
