#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
/home/hxchen/anaconda3/envs/bfn4jet/bin/python prepare.py E
/home/hxchen/anaconda3/envs/bfn4jet/bin/python prepare.py U
g++ -O3 -std=c++17 -Wall search.cpp -o search
for setting in mutagenicity_edge mutagenicity_node proteins_edge; do
    mv "$setting.E.input" "$setting.input"
    ./search < "$setting.input" > "$setting.witness"
    ./search < "$setting.U.input" > "$setting.U.witness"
done
python freeze.py
