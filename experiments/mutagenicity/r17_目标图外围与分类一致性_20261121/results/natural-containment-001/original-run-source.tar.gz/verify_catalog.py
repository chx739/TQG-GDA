from pathlib import Path
from itertools import repeat
from collections import defaultdict
import hashlib, json, torch
root=Path('/home/hxchen/research/GDA/TSBA')
archive=next((root/'repository/experiments/mutagenicity').glob('r9*/results/attempt-002*'))
frozen=Path('/tmp/r9-natural-contain/structural-freeze.json')
data=frozen.read_bytes()
assert hashlib.sha256(data).hexdigest()=='61a7bdd99aa18f52f181c49a158881f0971b8b53531e95651abbcd59e1f48644'
directions=json.loads(data)['directions']
seals=json.loads((archive/'source-provenance.json').read_bytes())
output={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'by_setting':{}}
for s,sv in seals.items():
 ids={i for k,v in directions.items() if k.startswith(s+'-') and k.endswith('-E') for pair in v['donor_recipient_pairs'] for i in pair}
 if not ids:
  output['by_setting'][s]={'verified_graphs':0};continue
 store=root/'experiments/r5'/s/'attempt-001'
 plan=json.loads((store/'protocol/plan.json').read_bytes())
 directory=Path(plan['input']['raw_directory']); dataset=plan['dataset']
 checks={}
 def lines(suffix):
  fn=dataset+'_'+suffix+'.txt'
  data=(directory/fn).read_bytes()
  checks[fn]=hashlib.sha256(data).hexdigest()
  assert checks[fn]==plan['input']['files'][fn]['sha256']
  return data.splitlines()
 batch=[int(ln)-1 for ln in lines('graph_indicator')]
 nodes=defaultdict(list);labels=defaultdict(list);edges=defaultdict(dict)
 ranks={}
 for node,(gid,encoded) in enumerate(zip(batch,lines('node_labels'),strict=True)):
  if gid not in ids:continue
  ranks[node]=len(nodes[gid]);nodes[gid].append(node); labels[gid].append(plan['input']['node_label_values'].index(int(encoded)))
 A=lines('A'); bond=lines('edge_labels') if plan['input']['edge_feature_dim'] else repeat(None,len(A))
 for uv,t in zip(A,bond,strict=True):
  u,v=(int(x.strip())-1 for x in uv.split(b','))
  gid=batch[u]
  if gid not in ids or u==v:continue
  assert batch[v]==gid
  key=(ranks[u],ranks[v])
  value=int(t) if t is not None else 0
  if key in edges[gid]:assert edges[gid][key]==value
  edges[gid][key]=value
 records=torch.load(store/'inputs/graphs.pt',map_location='cpu',weights_only=True)
 for i in ids:
  r=records[i]
  assert labels[i]==r['x'].argmax(1).tolist()
  tg=r['edge_index'].T.tolist()
  tb=r['edge_attr'].argmax(1).tolist() if r['edge_attr'] is not None else [0]*len(tg)
  assert {tuple(uv):t for uv,t in zip(tg,tb,strict=True)}==edges[i]
 output['by_setting'][s]=dict(verified_graphs=len(ids),raw_files=checks,raw_directory=str(directory),
 graph_indicator_conversion='TU graph ID minus one; raw node ordering in each TU graph retained',
 node_types_verified=True,all_directed_edges_and_types_verified=True,raw_graph_labels_opened=False)
path=Path('/tmp/r9-natural-contain/catalog-crosscheck.json')
path.write_text(json.dumps(output,indent=2)+'\n')
print(path,hashlib.sha256(path.read_bytes()).hexdigest(),[(s,r['verified_graphs']) for s,r in output['by_setting'].items()])
