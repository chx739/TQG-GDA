from pathlib import Path
import hashlib
import json
import torch
import sys
role=sys.argv[1] if len(sys.argv)>1 else "E"
assert role in ("U","E")
folder=Path('/tmp/r9-natural-contain')
root=Path('/home/hxchen/research/GDA/TSBA')
a=next((root/'repository/experiments/mutagenicity').glob('r9*/results/attempt-002*'))
roles=json.loads((a/'roles.json').read_bytes())
provenance=json.loads((a/'source-provenance.json').read_bytes())
for s,seal in provenance.items():
    path=root/'experiments/r5'/s/'attempt-001/inputs/graphs.pt'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==seal['inputs/graphs.pt']
    g=torch.load(path,weights_only=True,map_location='cpu')
    ids=sorted(set(i for r in roles.values() if r['setting']==s for kind in ('D',role) for i in r['roles'][kind]))
    with (folder/(s+'.'+role+'.input')).open('w') as w:
        print(len(ids),file=w)
        for i in ids:
            r=g[i]
            assert set(r)=={'x','edge_index','edge_attr'}
            x=r['x'].argmax(1).tolist()
            edges=r['edge_index'].T.tolist()
            typ=([0]*len(edges) if r['edge_attr'] is None else r['edge_attr'].argmax(1).tolist())
            e={(u,v):b for (u,v),b in zip(edges,typ)}
            assert all(u!=v and e[v,u]==b for (u,v),b in e.items())
            print(i,len(x),len(e)//2,*x,file=w)
            for (u,v),b in e.items():
                if u<v: print(u,v,b,file=w)
        for r in roles.values():
            if r['setting']!=s: continue
            g1=r['roles']['D']; g2=r['roles'][role]
            print(r['source'],int(r['direction']=='small_to_large'),len(g1),len(g2),*g1,*g2,file=w)
