import csv, collections, itertools, json, hashlib, pathlib, warnings
import networkx as nx
import numpy as np

repo=pathlib.Path('/home/hxchen/research/GDA/TSBA/repository')
out=pathlib.Path('/tmp/r19-overlap')
rawbase=pathlib.Path('/home/hxchen/research/GDA/TQG/data')
def read_graphs(ds):
    raw=next(rawbase.glob(f'{ds}_official_*/{ds}/raw'))
    def read(s):
        return np.loadtxt(raw/f'{ds}_{s}.txt',dtype=int,delimiter=',')
    membership=read('graph_indicator')-1
    cat=read('node_labels')
    edges=read('A')-1
    assert len(cat)==len(membership)
    assert np.all(membership[edges[:,0]]==membership[edges[:,1]])
    assert np.all(membership[1:]>=membership[:-1])
    graphs=[nx.Graph() for _ in range(int(max(membership)+1))]
    for n,(i,k) in enumerate(zip(membership,cat)):
        graphs[int(i)].add_node(n,cat=str(k))
    for u,v in edges:
        if u!=v:
            graphs[int(membership[u])].add_edge(int(u),int(v))
    assert sum(2*g.number_of_edges() for g in graphs)==len(set((u,v) for u,v in edges if u!=v))
    return graphs

def sig(g,typed):
    return (len(g),g.number_of_edges(),nx.weisfeiler_lehman_graph_hash(g,node_attr='cat' if typed else None,iterations=3,digest_size=32))

def iso(g,h,typed):
    return nx.is_isomorphic(g,h,node_match=nx.algorithms.isomorphism.categorical_node_match('cat',None) if typed else None)

def main():
    rows=[]; near=[]; doms=[]; examples={}
    for ds,variants in [('Mutagenicity',['idx','node']),('PROTEINS',['idx'])]:
        graphs=read_graphs(ds)
        dims={i:(len(g),g.number_of_edges()) for i,g in enumerate(graphs)}
        for variant in variants:
            domain=[set(np.load(repo/'data'/f'{variant}_{ds}_{k}.npy',allow_pickle=False).tolist()) for k in range(4)]
            setkey=f'{ds}-{variant}'
            assert sorted(i for grp in domain for i in grp)==list(range(len(graphs)))
            stat={i:dims[i][variant=='idx'] for i in dims}
            for k,dom in enumerate(domain):
                vals=sorted(stat[i] for i in dom)
                doms.append(dict(setting=setkey,domain=k,n=len(dom),minimum=vals[0],maximum=vals[-1]))
            for a,b in itertools.combinations(range(4),2):
                la=domain[a];lb=domain[b]
                shared=set(stat[i] for i in la)&set(stat[i] for i in lb)
                cut={k:sorted(i for i in dom if stat[i] in shared) for k,dom in [(a,la),(b,lb)]}
                rec=dict(setting=setkey,a=a,b=b,total_a=len(la),total_b=len(lb),cut=sorted(shared),cut_a=len(cut[a]),cut_b=len(cut[b]))
                for typed in (False,True):
                    m='typed' if typed else 'plain'
                    group={k:collections.defaultdict(list) for k in [a,b]}
                    for k in (a,b):
                        for i in cut[k]: group[k][sig(graphs[i],typed)].append(i)
                    iap=set();ibp=set();allp=[]
                    cwl=0;wla=set();wlb=set()
                    for s in group[a].keys() & group[b].keys():
                        aa,bb=group[a][s],group[b][s]
                        cwl+=len(aa)*len(bb);wla.update(aa);wlb.update(bb)
                        for i,j in itertools.product(aa,bb):
                            if iso(graphs[i],graphs[j],typed):
                                iap.add(i);ibp.add(j);allp.append((i,j))
                    for key,val in dict(wl_pairs=cwl,wl_a=len(wla),wl_b=len(wlb),iso_pairs=len(allp),iso_a=len(iap),iso_b=len(ibp)).items(): rec[f'{m}_{key}']=val
                    examples[f'{setkey}-{a}-{b}-{m}']=allp
                rows.append(rec)
                print(rec,flush=True)
    for filename,results in [('exact.csv',rows),('domains.csv',doms)]:
        with open(out/filename,'w') as f:
            writer=csv.DictWriter(f,fieldnames=list(results[0]));writer.writeheader();writer.writerows(results)
    (out/'exact-pairs.json').write_text(json.dumps(examples,indent=2)+'\n')
if __name__=='__main__':main()
