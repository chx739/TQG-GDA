import csv,collections,itertools,json,pathlib
import numpy as np
from audit import *

def summarize(ds,variant,graphs):
    domain=[set(np.load(repo/'data'/f'{variant}_{ds}_{k}.npy',allow_pickle=False).tolist()) for k in range(4)]
    lookup={i:k for k,grp in enumerate(domain) for i in grp}
    dims={i:(len(g),g.number_of_edges()) for i,g in enumerate(graphs)}
    cats={i:collections.Counter(nx.get_node_attributes(g,'cat').values()) for i,g in enumerate(graphs)}
    def signature(n,e,c):return (n,e,tuple(sorted((k,v) for k,v in c.items() if v)))
    index=collections.defaultdict(list)
    for i,(n,e) in dims.items():
        index[signature(n,e,cats[i])].append(i)
    sigcache={}
    results=collections.defaultdict(set)
    for i,g in enumerate(graphs):
        n,e=dims[i]
        groups=collections.defaultdict(list)
        for u,d in g.degree():
            if d==1: groups[g.nodes[u]['cat']].append(u)
        for k,leaves in groups.items():
            c=cats[i].copy()
            c[k]-=1
            candidates=[j for j in index[signature(n-1,e-1,c)] if lookup[j]!=lookup[i]]
            if not candidates:continue
            signatures=collections.defaultdict(list)
            for j in candidates:
                if j not in sigcache:sigcache[j]=sig(graphs[j],True)
                signatures[sigcache[j]].append(j)
            # Leaves with same neighbor and category are interchangeable.
            reprs={}
            for leaf in leaves:reprs[next(iter(g[leaf]))]=leaf
            done=set()
            for u in reprs.values():
                reduced=g.copy()
                reduced.remove_node(u)
                for j in signatures.get(sig(reduced,True),[]):
                    if j in done:continue
                    if iso(reduced,graphs[j],True):
                        done.add(j)
                        a,b=sorted([lookup[i],lookup[j]])
                        results[a,b].add((i,j) if lookup[i]==a else (j,i))
    details={}
    rows=[]
    for a,b in itertools.combinations(range(4),2):
        pairs=sorted(results[a,b])
        details[f'{a}-{b}']=pairs
        rows.append(dict(setting=f'{ds}-{variant}',a=a,b=b,total_a=len(domain[a]),total_b=len(domain[b]),oneleaf_pairs=len(pairs),covered_a=len({i for i,j in pairs}),covered_b=len({j for i,j in pairs})))
    return rows,details
if __name__=='__main__':
    allrows=[];details={}
    for ds,var in [('Mutagenicity',['idx','node']),('PROTEINS',['idx'])]:
        gg=read_graphs(ds)
        for variant in var:
            rows,det=summarize(ds,variant,gg);allrows.extend(rows);details[f'{ds}-{variant}']=det
            print(rows,flush=True)
    with (out/'leaf.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
    (out/'leaf-pairs.json').write_text(json.dumps(details,indent=2)+'\n')
