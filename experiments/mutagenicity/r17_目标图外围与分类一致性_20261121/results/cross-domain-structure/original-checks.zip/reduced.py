from audit import *
def reduce(g,mode):
    if mode=='drop_isolates':
        keep=[n for n,d in g.degree if d]
    elif mode=='all_largest_components':
        parts=sorted(nx.connected_components(g),key=len,reverse=True)
        keep=set.union(*(p for p in parts if len(p)==len(parts[0])))
    else:
        core=nx.k_core(g,k=2)
        return core
    return g.subgraph(keep).copy()
def compute(ds,graphs,mode):
    seen=collections.defaultdict(list)
    types={};clrows=[];counter=0;sizes={};non=None
    for i,g in enumerate(graphs):
        h=reduce(g,mode)
        if not len(h):continue
        shell=sig(h,True)
        for id_,rep in seen[shell]:
            if iso(h,rep,True):break
        else:
            id_=counter;counter+=1;seen[shell].append((id_,h))
        types[i]=id_;sizes[id_]=len(h)
    for variant in (['idx','node'] if ds=='Mutagenicity' else ['idx']):
        domain=[set(np.load(repo/'data'/f'{variant}_{ds}_{k}.npy',allow_pickle=False).tolist()) for k in range(4)]
        counts=[collections.Counter(types[i] for i in d if i in types) for d in domain]
        for a,b in itertools.combinations(range(4),2):
            both=counts[a].keys()&counts[b].keys();pairs=sum(counts[a][k]*counts[b][k] for k in both)
            clrows.append(dict(setting=f'{ds}-{variant}',mode=mode,a=a,b=b,pairs=pairs,shared_classes=len(both),covered_a=sum(counts[a][k] for k in both),covered_b=sum(counts[b][k] for k in both),all_nonempty=len(types),top_a=max((counts[a][k] for k in both),default=0),top_b=max((counts[b][k] for k in both),default=0)))
    return clrows
if __name__=='__main__':
    rows=[]
    for ds in ['Mutagenicity','PROTEINS']:
        graphs=read_graphs(ds)
        for mode in ['drop_isolates','all_largest_components','nonempty_2core']:
            current=compute(ds,graphs,mode);rows.extend(current)
            with (out/'partial-graphs.csv').open('w') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            print(ds,mode,[(k,[(r['covered_a'],r['covered_b']) for r in rr]) for k,rr in itertools.groupby(current,key=lambda r:r['setting'])],flush=True)
