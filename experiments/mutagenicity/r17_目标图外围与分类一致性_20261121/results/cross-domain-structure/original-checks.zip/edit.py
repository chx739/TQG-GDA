import collections, json, itertools, csv
from audit import *

def find_edits(graphs,ds,variant,old):
    domain=[set(np.load(repo/'data'/f'{variant}_{ds}_{k}.npy',allow_pickle=False).tolist()) for k in range(4)]
    lookup={i:k for k,grp in enumerate(domain) for i in grp}
    dims={i:(len(g),g.number_of_edges()) for i,g in enumerate(graphs)}
    cats={i:collections.Counter(nx.get_node_attributes(g,'cat').values()) for i,g in enumerate(graphs)}
    index=collections.defaultdict(list)
    for i,(n,e) in dims.items():
        index[n,e,tuple(sorted(cats[i].items()))].append(i)
    cached={}
    results=collections.defaultdict(set)
    for i,g in enumerate(graphs):
        n,e=dims[i]
        candidates=[j for j in index[n,e-1,tuple(sorted(cats[i].items()))] if lookup[j]!=lookup[i]]
        if not candidates:continue
        finder=collections.defaultdict(list)
        for j in candidates:
            if j not in cached:cached[j]=sig(graphs[j],True)
            finder[cached[j]].append(j)
        done=set()
        reduced=g.copy()
        for s,t in g.edges:
            reduced.remove_edge(s,t)
            for j in finder.get(sig(reduced,True),[]):
                if j not in done and iso(reduced,graphs[j],True):
                    done.add(j)
                    a,b=sorted([lookup[i],lookup[j]])
                    results[a,b,'edge'].add((i,j) if lookup[i]==a else (j,i))
            reduced.add_edge(s,t)
            if done==set(candidates):break
    for a,b in itertools.combinations(range(4),2):
        for i,j in old[f'{ds}-{variant}-{a}-{b}-plain']:
            ca,cb=cats[i],cats[j]
            ch,dest=list((ca-cb).elements()),list((cb-ca).elements())
            if len(ch)!=1 or len(dest)!=1:continue
            current=graphs[i].copy()
            for u,v in graphs[i].nodes(data='cat'):
                if v!=ch[0]:continue
                current.nodes[u]['cat']=dest[0]
                if iso(current,graphs[j],True):
                    results[a,b,'color'].add((i,j));break
                current.nodes[u]['cat']=ch[0]
    add={}
    for a,b in itertools.combinations(range(4),2):
        for typ in ('edge','color'):
            add[f'{a}-{b}-{typ}']=sorted(results[a,b,typ])
    return add
if __name__=='__main__':
    details={}
    old=json.loads((out/'exact-pairs.json').read_text())
    for ds,var in [('Mutagenicity',['idx','node']),('PROTEINS',['idx'])]:
        gg=read_graphs(ds)
        for variant in var:
            details[f'{ds}-{variant}']=find_edits(gg,ds,variant,old)
            print(ds,variant,{k:len(v) for k,v in details[f'{ds}-{variant}'].items()},flush=True)
    (out/'edit-pairs.json').write_text(json.dumps(details,indent=2)+'\n')
