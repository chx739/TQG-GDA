from audit import *
from math import gcd
from functools import reduce
def compute(gs):
    colors=[{n:int(c) for n,c in g.nodes(data='cat')} for g in gs]
    acc=[[] for g in gs]
    ren=[[] for g in gs]
    for depth in range(4):
        for i,c in enumerate(colors):
            h=collections.Counter(c.values())
            acc[i].append(tuple(sorted(h.items())))
            gg=reduce(gcd,h.values())
            ren[i].append(tuple(sorted((k,v//gg) for k,v in h.items())))
        if depth<3:
            vocabulary={}
            def color(t):
                if t not in vocabulary:vocabulary[t]=len(vocabulary)
                return vocabulary[t]
            colors=[{v:color((c[v],tuple(sorted(c[u] for u in g[v])))) for v in g} for c,g in zip(colors,gs)]
    return acc,ren
def measure(ds,acc,ren):
    result=[]
    for variant in (['idx','node'] if ds=='Mutagenicity' else ['idx']):
        dom=[np.load(repo/'data'/f'{variant}_{ds}_{i}.npy',allow_pickle=False) for i in range(4)]
        for depth in [2,3]:
            for kind,reps in [('count',acc),('normalized',ren)]:
                tables=[collections.Counter(tuple(reps[i][:depth+1]) for i in ids) for ids in dom]
                for a,b in itertools.combinations(range(4),2):
                    both=tables[a].keys() & tables[b].keys()
                    result.append(dict(setting=f'{ds}-{variant}',depth=depth,kind=kind,a=a,b=b,shared_classes=len(both),pairs=sum(tables[a][k]*tables[b][k] for k in both),covered_a=sum(tables[a][k] for k in both),covered_b=sum(tables[b][k] for k in both)))
    return result
if __name__=='__main__':
    rows=[]
    for ds in ['Mutagenicity','PROTEINS']:
        current=measure(ds,*compute(read_graphs(ds)));rows+=current
        print(ds,[(k,sum(r['pairs'] for r in rr)) for k,rr in itertools.groupby(current,key=lambda r:(r['setting'],r['depth'],r['kind']))],flush=True)
    with (out/'wl-equivalence.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
