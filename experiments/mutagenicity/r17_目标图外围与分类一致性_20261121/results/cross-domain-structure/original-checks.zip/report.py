from audit import *
exact=list(csv.DictReader((out/'exact.csv').open()))
leaf=json.loads((out/'leaf-pairs.json').read_text())
edits=json.loads((out/'edit-pairs.json').read_text())
plain=json.loads((out/'exact-pairs.json').read_text())
rows=[]
for setting,records in itertools.groupby(exact,key=lambda r:r['setting']):
    records=list(records)
    pairct=dict(plain=0,typed=0,leaf=0,edge=0,color=0,union=0,cut_targets=0,alltargets=0,union_targets=0)
    target_union=set();plain_union=set();target_bound=set()
    for row in records:
        a,b=[int(row[k]) for k in ('a','b')]
        k=f'{a}-{b}'
        collection=[set(map(tuple,grp)) for grp in (leaf[setting][k],edits[setting][f'{k}-edge'],edits[setting][f'{k}-color'])]
        near=set().union(*collection)
        p=set(map(tuple,plain[f'{setting}-{k}-plain']))
        assert len(near)==sum(map(len,collection))
        for i,j in near:target_union.update([i,j])
        for i,j in p:plain_union.update([i,j])
        recipients=[{v[t] for v in near} for t in (0,1)]
        for typ,v in zip(('leaf','edge','color'),collection):pairct[typ]+=len(v)
        pairct['union']+=len(near)
        pairct['union_targets']+=sum(map(len,recipients))
        pairct['plain']+=len(p)
        pairct['typed']+=int(row['typed_iso_pairs'])
        pairct['cut_targets']+=int(row['cut_a'])+int(row['cut_b'])
        pairct['alltargets']+=int(row['total_a'])+int(row['total_b'])
        rows.append(dict(setting=setting,a=a,b=b,leaves=len(collection[0]),edge_edits=len(collection[1]),category_edits=len(collection[2]),any_edit=len(near),a_covered=len(recipients[0]),b_covered=len(recipients[1]),a_pct=100*len(recipients[0])/int(row['total_a']),b_pct=100*len(recipients[1])/int(row['total_b'])))
    print(setting,pairct,'unique_near',len(target_union),'unique_plain',len(plain_union))
with (out/'edit.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
