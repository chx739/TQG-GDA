"""Describe empirical domain identification from publication-defined graph size. No class labels."""

import ast
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
import math
from pathlib import Path

import numpy as np


ROOT = Path("/home/hxchen/research/GDA/TSBA")
REPO = ROOT / "repository"
OUT = Path(__file__).resolve().parent
SETTINGS = {"mutagenicity_edge": ("Mutagenicity-idx", "undirected_edges"),
            "mutagenicity_node": ("Mutagenicity-node", "nodes"),
            "proteins_edge": ("PROTEINS-idx", "undirected_edges")}
HASHES = {}


def checked(path, expected=None):
    raw = path.read_bytes()
    h = hashlib.sha256(raw).hexdigest()
    assert expected is None or h == expected, str(path)
    HASHES[str(path)] = h
    return raw


def write(name, rows):
    with (OUT / (name + ".csv")).open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def entropy_mass(counts):
    n = sum(counts)
    return -sum(c * math.log2(c/n) for c in counts if c)


def analyze(s, field, name, source_provenance, topologies, roles, exact):
    base = ROOT / "experiments/r5" / s / "attempt-001"
    source = source_provenance[s]
    graphs = json.loads(checked(base / "inputs/graph_hashes.json", source["inputs/graph_hashes.json"]))
    plan = json.loads(checked(base / "protocol/plan.json", source["protocol/plan.json"]))
    raw_directory = Path(plan["input"]["raw_directory"])
    dataset = plan["dataset"]
    def read_column(suffix, delimiter=None):
        path = raw_directory / f"{dataset}_{suffix}.txt"
        record = plan["input"]["files"][path.name]
        values = checked(path, record["sha256"])
        return np.loadtxt(io.BytesIO(values), dtype=int, delimiter=delimiter)
    graph_index = read_column("graph_indicator") - 1
    if field == "nodes":
        counts = np.bincount(graph_index, minlength=len(graphs))
    else:
        entries = read_column("A", ",") - 1
        assert (graph_index[entries[:,0]] == graph_index[entries[:,1]]).all()
        distinct = {(min(i,j),max(i,j)) for i,j in entries if i!=j}
        counts = np.bincount([graph_index[i] for i,_ in distinct], minlength=len(graphs))
    size_of = dict(enumerate(counts.tolist()))
    assert all(r["id"] in size_of and (field not in r or size_of[r["id"]] == r[field])
               for r in graphs)
    assert len(size_of) == len(graphs) == plan["setting"]["total_graphs"]
    tables = defaultdict(Counter)
    domain_ids = {}
    by_domain, pseudo = [], []
    for row in plan["setting"]["domain_indices"]:
        d = row["domain"]
        raw = checked(REPO / row["path"], source[f"repository:{row['path']}"])
        assert row["sha256"] == HASHES[str(REPO / row["path"])]
        ids = np.load(io.BytesIO(raw), allow_pickle=False).tolist()
        assert len(set(ids)) == len(ids) == row["count"]
        domain_ids[d] = set(ids)
        for i in ids:
            tables[size_of[i]][d] += 1
        top = topologies[f"{s}-M{d}-seed-3405"]
        top_ids = top["source_ids"] + top["validation_ids"]
        assert len(set(top_ids)) == len(top_ids) and set(top_ids) == set(ids)
        assert all(size_of[i] == n for i, n in zip(top_ids, top["sizes"], strict=True))
        for direction in ("small_to_large", "large_to_small"):
            task = roles[f"{s}-M{d}-{direction}-seed-3405"]
            cut = task["cut"]
            r = task["roles"]
            assert set(r["D"]).isdisjoint(r["U"])
            assert set(r["D"]) | set(r["U"]) == set(top["source_ids"])
            assert set(r["C"]).isdisjoint(r["E"])
            assert set(r["C"]) | set(r["E"]) == set(top["validation_ids"])
            sizes_d = [size_of[i] for i in r["D"]]
            sizes_u = [size_of[i] for i in r["U"]]
            reverse = direction == "large_to_small"
            predict_U = lambda n: n <= cut if reverse else n > cut
            count = sum(not predict_U(n) for n in sizes_d) + sum(predict_U(n) for n in sizes_u)
            validation_count = sum(not predict_U(size_of[i]) for i in r["C"]) + sum(
                predict_U(size_of[i]) for i in r["E"])
            intersection = set(sizes_d) & set(sizes_u)
            assert cut == top["cut"] and not intersection
            assert count == len(sizes_d) + len(sizes_u)
            assert validation_count == len(r["C"]) + len(r["E"])
            pseudo.append(dict(setting=s, historical_source=d, direction=direction, cut=cut,
                n_D=len(sizes_d), min_D=min(sizes_d), max_D=max(sizes_d),
                n_U=len(sizes_u), min_U=min(sizes_u), max_U=max(sizes_u), shared_sizes=0,
                distinct_D=len(set(sizes_d)), distinct_U=len(set(sizes_u)),
                cut_correct_DU=count, cut_accuracy_DU=1.0, H_side_given_size_bits=0,
                n_C=len(r["C"]), n_E=len(r["E"]), cut_correct_CE=validation_count))
    assert set.union(*domain_ids.values()) == set(size_of)
    assert sum(map(len, domain_ids.values())) == len(size_of)
    error = 0
    unique = 0
    mass = 0.0
    size_rows = []
    correct_by_domain = Counter()
    unique_by_domain = Counter()
    minority_by_domain = Counter()
    for x, counts in sorted(tables.items()):
        n = counts.total()
        maximum = max(counts.values())
        winners = [d for d, c in counts.items() if c == maximum]
        assert len(winners) == 1
        winner = winners[0]
        correct_by_domain[winner] += maximum
        if len(counts) == 1:
            unique += n
            unique_by_domain[winner] += n
        for d, c in counts.items():
            minority_by_domain[d] += int(winner != d) * c
        error += n - maximum
        hm = entropy_mass(counts.values())
        mass += hm
        size_rows.append(dict(setting=s, size=x, M0=counts[0], M1=counts[1], M2=counts[2],
            M3=counts[3], max_count=maximum, lookup_domain=winner, empirical_errors=n-maximum,
            H_domain_given_this_size=hm/n))
    relevant = [row for row in exact if row["setting"] == name]
    assert len(relevant) == 6
    overlap = []
    pair_error = pair_shared = 0
    pair_mass = 0.0
    for row in relevant:
        a, b = int(row["a"]), int(row["b"])
        assert int(row["total_a"]) == len(domain_ids[a])
        assert int(row["total_b"]) == len(domain_ids[b])
        cuts = ast.literal_eval(row["cut"])
        assert sorted(x for x, counts in tables.items() if counts[a] and counts[b]) == cuts
        if not cuts:
            assert int(row["cut_a"]) == int(row["cut_b"]) == 0
            continue
        assert len(cuts) == 1
        x = cuts[0]
        na, nb = int(row["cut_a"]), int(row["cut_b"])
        assert tables[x][a] == na and tables[x][b] == nb and len(tables[x]) == 2
        pair_error += min(na, nb)
        pair_shared += na + nb
        pair_mass += entropy_mass((na, nb))
        overlap.append(dict(setting=s, size=x, domain_a=a, count_a=na, domain_b=b, count_b=nb,
                            majority_domain=a if na>nb else b, minority_count=min(na,nb)))
    total = len(graphs)
    assert pair_error == error and pair_shared == total - unique
    assert math.isclose(pair_mass, mass, abs_tol=1e-10)
    for d, ids in domain_ids.items():
        values = [size_of[i] for i in ids]
        by_domain.append(dict(setting=s,domain=d,graphs=len(ids),min_size=min(values),
            max_size=max(values),distinct_sizes=len(set(values)),unique_size_graphs=unique_by_domain[d],
            shared_size_graphs=len(ids)-unique_by_domain[d],lookup_correct=correct_by_domain[d],
            minority_side_mistakes=minority_by_domain[d],lookup_accuracy=correct_by_domain[d]/len(ids)))
    summary = dict(setting=s,n=total,unique_size_graphs=unique,shared_size_graphs=total-unique,
        shared_distinct_sizes=len(overlap),minority_side_graphs=error,lookup_correct=total-error,
        lookup_accuracy=(total-error)/total,H_domain_given_size_bits=mass/total,
        entropy_domain_bits=entropy_mass([len(v) for v in domain_ids.values()])/total,
        pseudo_tasks=len(pseudo),pseudo_DU_total=sum(r["cut_correct_DU"] for r in pseudo),
        pseudo_CE_total=sum(r["cut_correct_CE"] for r in pseudo))
    return summary, by_domain, overlap, size_rows, pseudo


def main():
    r9 = next((REPO / "experiments/mutagenicity").glob("r9_*/results/reference-geometry-001"))
    obs = json.loads(checked(r9 / "OBS.json"))
    def member(file):
        return json.loads(checked(r9 / file, obs["files"][file]))
    provenance = member("source-provenance.json")
    topologies = member("source-topology.json")
    roles = member("roles.json")
    exact = list(csv.DictReader(io.StringIO(checked(Path("/tmp/r19-overlap/exact.csv")).decode())))
    results = [analyze(s, field, name, provenance, topologies, roles, exact)
               for s, (name, field) in SETTINGS.items()]
    write("summary", [r[0] for r in results])
    for col, name in enumerate(("per-domain", "shared-sizes", "full-size-table", "pseudo-tasks"), 1):
        write(name,[row for r in results for row in r[col]])
    (OUT / "input-sha256.json").write_text(json.dumps(HASHES, indent=2) + "\n")
    print((OUT / "summary.csv").read_text())


if __name__ == "__main__":
    main()
