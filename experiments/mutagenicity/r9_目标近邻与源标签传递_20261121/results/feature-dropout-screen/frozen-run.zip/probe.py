from pathlib import Path
import sys, json, hashlib, csv, collections
import numpy as np, torch
from scipy.linalg import cho_factor, cho_solve
from torch_geometric.data import Data
repo=Path('/home/hxchen/research/GDA/TSBA/repository')
sys.path.insert(0,str(repo))
from experiments.mutagenicity.r10_原生图适配基线与增量_20261121.src import structural
from experiments.mutagenicity.r9_目标近邻与源标签传递_20261121.src import wl
out=Path(__file__).resolve().parent
r9=next(repo.glob('experiments/mutagenicity/r9_*/results/reference-geometry-001'))
r18=next(repo.glob('experiments/mutagenicity/r18_*/results/attempt-001-source-screen'))
roles=json.loads((r9/'roles.json').read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def subset(ids,n,key):
    return sorted(ids,key=lambda i:hashlib.sha256(f'flda1|{key}|{i}'.encode()).digest())[:n]
def get_meta(setting):
    root=repo.parent/'experiments'/'r5'/setting/'attempt-001'/'inputs'
    return root,json.loads((root/'label_records.json').read_text()),json.loads((root/'domains.json').read_text())
def labels(meta,domain,roles,role,stage):
    assert role in ({'fit':{'D','C'},'score':{'E'}}[stage])
    allids=sum(roles.values(),[])
    assert set(allids)==set(domain) and len(allids)==len(set(allids))
    with Path(meta['path']).open('rb',buffering=0) as f:
        vals=[]
        for i in roles[role]:
            pos,length=meta['offsets'][i]
            f.seek(pos); vals.append(meta['mapping'][str(int(f.read(length)))])
    return np.array(vals)
def fit_scores(x,query,y,ratio,penalty,lam):
    # Analytic FLDA-Q in n-dimensional dual, lambda positive, free intercept.
    inv=np.zeros_like(ratio)
    keep=ratio>0
    inv[keep]=1/(lam+penalty[keep]*(1/ratio[keep]-1))
    weighted=x.multiply(inv).tocsr()
    gram=(weighted@x.T).toarray()
    gram.flat[::len(gram)+1]+=1
    sol=cho_solve(cho_factor(gram),np.c_[y,np.ones(len(y))])
    intercept=sol[:,0].sum()/sol[:,1].sum()
    return query@(weighted.T@(sol[:,0]-intercept*sol[:,1]))+intercept
def freeze():
    sep={}
    for setting in structural.SETTINGS:
        root,meta,domains=get_meta(setting)
        graph=torch.load(root/'graphs.pt',map_location='cpu',weights_only=True)
        assert all(set(g)=={'x','edge_index','edge_attr'} for g in graph)
        for source in range(4):
            features={i:structural.features(Data(**graph[i]),setting)[0] for i in domains[str(source)]}
            for key,rec in roles.items():
                if (rec['setting'],rec['source'])!=(setting,source): continue
                role=rec['roles']
                d,c,u,e=[role[k] for k in ['D','C','U','E']]
                yd=labels(meta,domains[str(source)],role,'D','fit')*2-1
                yc=labels(meta,domains[str(source)],role,'C','fit')*2-1
                lex=wl.vocabulary(features,d)
                xd=wl.sparse_rows(features,d,lex); xc=wl.sparse_rows(features,c,lex)
                xe=wl.sparse_rows(features,e,lex)
                m=min(len(c),len(u))
                source_df=np.asarray(xd.getnnz(axis=0))
                freq=source_df/len(d)
                def ratio(ids):
                    matrix=wl.sparse_rows(features,subset(ids,m,key),lex)
                    return np.minimum(1,(np.asarray(matrix.getnnz(axis=0))/m)/freq)
                target=ratio(u)
                # Preserve radius and source frequency octave while randomizing attribution.
                perm=target.copy(); rng=np.random.default_rng(20261121)
                groups=collections.defaultdict(list)
                for (rad,h),j in lex.items():
                    groups[(rad,int(np.floor(np.log2(source_df[j]))))].append(j)
                for indices in groups.values(): perm[indices]=rng.permutation(target[indices])
                budget=np.asarray(xd.power(2).sum(axis=0)).ravel()
                from scipy.sparse import vstack
                q=vstack([xc,xe],format='csr')
                outputs={}; params={}
                for name,r in dict(Target=target,Static=np.ones(len(lex)),Source=ratio(c),Perm=perm).items():
                    opts=[]
                    for lam in (.01,.1,1.,10.):
                        z=fit_scores(xd,q,yd,r,budget,lam)
                        val=z[:len(c)]
                        opts.append(((-int(((val>0)==(yc>0)).sum()),float(np.mean((val-yc)**2)),-lam),z[len(c):]))
                    (neg,mse,minuslam),pred=min(opts,key=lambda v:v[0]); params[name]=-minuslam
                    outputs[name]=pred
                with np.load(r18/'predictions'/f'{key}.npz') as old:
                    assert np.array_equal(old['e_ids'],e)
                    for name,field in [('Strong','margin_Anchor'),('WL','margin_WL_selected')]:
                        outputs[name]=old[field].copy()
                npos=(outputs['Target']>0).sum()
                equal=np.full(len(e),-1.)
                if npos:
                    equal[np.lexsort((e,-outputs['Static']))[:npos]]=1
                outputs['Count']=equal
                np.savez(out/f'{key}.npz',e=np.array(e),**outputs)
                sep[key]=dict(m=m,D=len(d),C=len(c),E=len(e),n_features=len(lex),zero=int((target==0).sum()),params=params,prediction_sha=digest(out/f'{key}.npz'))
                print('frozen',key,flush=True)
    (out/'freeze.json').write_text(json.dumps(dict(source_program=digest(Path(__file__)),rows=sep),indent=2))
def score():
    frozen=json.loads((out/'freeze.json').read_text())
    assert frozen['source_program']==digest(Path(__file__)) and set(frozen['rows'])==set(roles)
    results=[]
    for key,rec in roles.items():
        root,meta,domains=get_meta(rec['setting'])
        assert digest(out/f'{key}.npz')==frozen['rows'][key]['prediction_sha']
        y=labels(meta,domains[str(rec['source'])],rec['roles'],'E','score')
        with np.load(out/f'{key}.npz') as arr:
            assert np.array_equal(arr['e'],rec['roles']['E'])
            correctness={a:(arr[a]>0)==y for a in arr.files if a!='e'}
            ours=correctness['Target']
            for name,other in correctness.items():
                results.append(dict(setting=rec['setting'],source=rec['source'],direction=rec['direction'],method=name,accuracy=other.mean(),gain=(ours.mean()-other.mean()),fixed=int((ours&~other).sum()),harmed=int((~ours&other).sum()),disagree=(ours!=other).mean(),n=len(y)))
    with (out/'directions.csv').open('w') as f:
        wr=csv.DictWriter(f,results[0].keys()); wr.writeheader();wr.writerows(results)
    for k in structural.SETTINGS:
        for method in ('Target','Static','Source','Perm','Strong','WL','Count'):
            rows=[r for r in results if r['setting']==k and r['method']==method]
            print(k,method,*[round(100*np.mean([r[s] for r in rows]),3) for s in ('accuracy','gain','disagree')],*[sum(r[s] for r in rows) for s in ('fixed','harmed')])
if sys.argv[1]=='freeze': freeze()
if sys.argv[1]=='score': score()
