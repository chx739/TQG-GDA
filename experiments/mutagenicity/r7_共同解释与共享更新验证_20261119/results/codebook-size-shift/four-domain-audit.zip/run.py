from pathlib import Path
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
import csv,hashlib,json,math,io
import numpy as np
from scipy.stats import fisher_exact
REPO=Path('/home/hxchen/research/GDA/TSBA/repository')
BASE=REPO/'experiments/mutagenicity'; OUT=Path(__file__).resolve().parent
R12=next(BASE.glob('r12*/results/attempt-002-conditional-votes'))
H={}
def read(path,expected=None):
 b=path.read_bytes();h=hashlib.sha256(b).hexdigest()
 if expected is not None:assert h==expected,(path,expected,h)
 H[str(path)]=h
 return b
known=json.loads(read(R12.parent.parent/'configs/reverse-vote-check.json'))['historical_obs_sha256']
inv=json.loads(read(R12/'OBS.json',known))['files'];roles=json.loads(read(R12/'roles.json',inv['roles.json']))
plan=next(BASE.glob('r7*/docs/finite-codebook-control.md'));read(plan)
def write_csv(name, rows):
 with (OUT/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def sign(x):return int(x>0)-int(x<0)
def win(x):return {-1:'P',0:'tie',1:'I'}[sign(x)]
def fisher(a,b,c,d):
 if min(a+b,c+d)==0: return F(1)
 n=a+b+c+d;p=a+c;r=a+b; lo=max(0,r-(n-p));hi=min(r,p)
 den=math.comb(n,r)
 observed=math.comb(p,a)*math.comb(n-p,r-a)
 mass=math.comb(p,lo)*math.comb(n-p,r-lo)
 total=allmass=0
 for x in range(lo,hi+1):
  allmass+=mass
  if mass<=observed: total+=mass
  if x<hi: mass=mass*(p-x)*(r-x)//((x+1)*(n-p-r+x+1))
 assert allmass==den
 exact=F(total,den)
 other=fisher_exact([[a,b],[c,d]],alternative='two-sided').pvalue
 assert math.isclose(float(exact),other,abs_tol=1e-14,rel_tol=1e-8),(a,b,c,d,exact,other)
 return exact
def structural(v,n):
 x,y=1,1
 lograt=0.
 for j in range(5):
  a,b=map(int,v[:,j]);diff=int(n[0,j])-int(n[1,j]);proportion=F(a,b)
  numerator,denominator=proportion.numerator,proportion.denominator
  if diff<0:numerator,denominator=denominator,numerator
  x*=pow(numerator,abs(diff)); y*=pow(denominator,abs(diff))
  lograt+=diff*(math.log(a)-math.log(b))
 assert abs(lograt)<1e-8 if x==y else sign(lograt)==sign(x-y)
 return win(x-y),lograt
def key(k):return int(k.split('_to_M')[-1].split('-')[0])
rows=[]; scopes={}
for s,name,pair in [('mutagenicity_edge','Mutagenicity',(1,4)),('proteins_edge','PROTEINS',(0,1))]:
 cfg=json.loads(read(next(BASE.glob('r5*/configs/'+name.lower()+'-plan.json'))))
 d=Path(cfg['input']['raw_directory'])
 def col(suf,commas=False):
  fn=name+suf;spec=cfg['input']['files'][fn];sha=spec if isinstance(spec,str) else spec['sha256']
  return np.loadtxt(io.BytesIO(read(d/fn,sha)),dtype=int,delimiter=',' if commas else None)
 own=col('_graph_indicator.txt')-1; typ=col('_node_labels.txt')
 edges=col('_A.txt',True)-1;assert own.ndim==typ.ndim==1 and len(own)==len(typ) and all(own[edges[:,0]]==own[edges[:,1]])
 edges=np.unique(np.sort(edges[edges[:,0]!=edges[:,1]],axis=1),axis=0);degree=np.bincount(edges.ravel(),minlength=len(typ))
 types=pair;ng=int(max(own))+1
 hist=np.zeros((ng,2,5),dtype=np.int64)
 for j,t in enumerate(types):
  ok=typ==t
  hist[:,j]=np.bincount(own[ok]*5+np.minimum(degree[ok],4),minlength=ng*5).reshape(ng,5)
 diff=hist[:,0].sum(1)-hist[:,1].sum(1); n=np.bincount(own)
 selected=sorted((k,o) for k,o in roles.items() if o['setting']==s)
 assert len(selected)==12 and {(o['source'],o['target']) for k,o in selected}=={(i,j) for i in range(4) for j in range(4) if i!=j}
 for k,o in selected:
  D,U=o['ids']['source'],o['selected_a_ids'];assert o['seed']==3405 and len(set(D)|set(U))==len(D)+len(U) and len(set(D))==len(D) and len(set(U))==len(U)
  scopes[k]=dict(D=D,U=U)
  dr=sum((F(int(diff[i]),int(n[i])) for i in D),F())/len(D)
  ur=sum((F(int(diff[i]),int(n[i])) for i in U),F())/len(U)
  dpos=int((diff[D]>0).sum()); dneg=int((diff[D]<0).sum());upos=int((diff[U]>0).sum());uneg=int((diff[U]<0).sum())
  model=hist[D].sum(0)+1; u=hist[U].sum(0)
  for code in (0,1):
   cm=1-2*code
   ap,an=(uneg,upos) if code else (upos,uneg)
   p=fisher(dpos,dneg,ap,an); q=fisher(dpos,dneg,an,ap)
   retained=''.join(u for u,z in [('I',p),('P',q)] if z>=F(1,20)) or 'empty'
   main='P' if retained=='P' else 'I'
   struc,llr=structural(model,u[::-1] if code else u)
   true='P' if code else 'I'
   rows.append(dict(setting=s,source=o['source'],target=o['target'],code=true,D=len(D),U=len(U),D_mean=float(dr),U_mean=float(ur)*cm,D_pos=dpos,D_neg=dneg,U_pos=ap,U_neg=an,D_ties=len(D)-dpos-dneg,U_ties=len(U)-ap-an,mean_rule=win(dr*ur*cm),fisher_p_I=float(p),fisher_p_P=float(q),retained=retained,truth_retained=true in retained,shared_action=main,maxp=win(p-q),structural=struc,structural_log_ratio=llr))
write_csv('directions.csv',rows)
summary=[]
for s in ('mutagenicity_edge','proteins_edge'):
 for code in ('I','P'):
  z=[r for r in rows if r['setting']==s and r['code']==code]
  x=dict(setting=s,code=code,n=len(z))
  for m in ('mean_rule','shared_action','maxp','structural'):
   for val in ('I','P','tie'):x[m+'_'+val]=sum(r[m]==val for r in z)
  for val in ('I','P','IP','empty'):x['retained_'+val]=sum(r['retained']==val for r in z)
  x['truth_retained']=sum(r['truth_retained'] for r in z)
  summary.append(x)
  print(s,code,[(m,[x[m+'_'+v] for v in ('I','P','tie')]) for m in ('mean_rule','shared_action','maxp','structural')],'sets',[x['retained_'+v] for v in ('I','P','IP','empty')],'contains truth',x['truth_retained'])
  if code=='I':
   for m in ('mean_rule','shared_action','maxp','structural'):print(m,'false P',[(r['source'],r['target']) for r in z if r[m]=='P'])
write_csv('summary.csv',summary)
for stem,values in [('inputs',H),('roles',scopes)]: (OUT/(stem+'.json')).write_text(json.dumps(values,indent=2,ensure_ascii=False)+'\n')
checks={n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ('protocol.txt','run.py','roles.json','inputs.json','directions.csv','summary.csv')}
(OUT/'STRUCTURE-ONLY.json').write_text(json.dumps(checks,indent=2)+'\n')
