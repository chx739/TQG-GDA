"""Check the four prespecified codebook decisions on equal-sized same/opposite graph pools."""
from collections import Counter, OrderedDict
from fractions import Fraction
from pathlib import Path
import csv
import hashlib
import io
import json
import math
import pickle
import zipfile
import numpy as np
from scipy.stats import fisher_exact

OUT=Path(__file__).resolve().parent
ROOT=Path('/home/hxchen/research/GDA/TSBA')
REPO=ROOT/'repository/experiments/mutagenicity'
R9=next(REPO.glob('r9*/results/attempt-002-weighted-residuals/roles.json'))
R7=next(REPO.glob('r7*/results/finite-codebook-blind/roles.json'))
digest=lambda data:hashlib.sha256(data).hexdigest()
assert digest(R9.read_bytes())==json.loads((R9.parent/'OBS.json').read_text())['files']['roles.json']
roles=json.loads(R9.read_text())
same_locked=json.loads(R7.read_text())
def ordered(ids):
    return sorted(ids,key=lambda g:(hashlib.sha256(str(g).encode('ascii')).digest(),g))
def save(file,rows):
    with (OUT/file).open('w') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
def vote(value):
    return 'I' if value>0 else 'P' if value<0 else 'tie'
def fisher(a,b,c,d):
    row1=a+b
    row2=c+d
    col=a+c
    if row1==0 or row2==0:
        return Fraction(1)
    mass=lambda j:math.comb(row1,j)*math.comb(row2,col-j)
    weights=[mass(j) for j in range(max(0,col-row2),min(row1,col)+1)]
    return Fraction(sum(w for w in weights if w<=mass(a)),sum(weights))
def tensor_description(storage,offset,shape,stride,grad,hooks):
    return storage,offset,shape,stride
class TensorMetadata(pickle.Unpickler):
    def find_class(self,module,name):
        return {('torch._utils','_rebuild_tensor_v2'):tensor_description,('torch','FloatStorage'):'<f4',
                ('torch','LongStorage'):'<i8',('collections','OrderedDict'):OrderedDict}[module,name]
    def persistent_load(self,key):
        kind,dtype,address,device,size=key
        assert kind=='storage' and device=='cpu'
        return dtype,address
def graph_read(z,meta,graph_id,field,hashes):
    (dtype,address),offset,shape,stride=meta[graph_id][field]
    dtype=np.dtype(dtype)
    data=z.read('archive/data/'+address)
    arr=np.ndarray(shape,dtype,buffer=data,offset=offset*dtype.itemsize,
                   strides=tuple(s*dtype.itemsize for s in stride))
    assert digest(arr.tobytes())==hashes[graph_id]['input_sha256'][field]
    return arr
def graph_summary(z,meta,g,pair,fps):
    x=graph_read(z,meta,g,'x',fps)
    edges=graph_read(z,meta,g,'edge_index',fps)
    assert (x.sum(axis=1)==1).all() and np.isin(x,[0.,1.]).all()
    types=x.argmax(axis=1)
    degree=np.zeros(len(x),dtype=int)
    unique={(min(a,b),max(a,b)) for a,b in edges.T.tolist() if a!=b}
    for a,b in unique:
        degree[a]+=1
        degree[b]+=1
    h=np.stack([np.bincount(np.minimum(degree[types==v],4),minlength=5) for v in pair])
    return Fraction(int(h[0].sum()-h[1].sum()),len(x)),h
def features(graphs,ids):
    ds=[graphs[i][0] for i in ids]
    dmean=sum(ds,Fraction(0))/len(ids)
    pos=sum(d>0 for d in ds)
    neg=sum(d<0 for d in ds)
    joint=np.sum([graphs[i][1] for i in ids],axis=0)
    return dmean,pos,neg,joint
def struct_decision(source,counts):
    a,b=[list(map(int,row)) for row in source]
    x,y=[list(map(int,row)) for row in counts]
    a_likelihood=math.prod(u**i*v**j for u,v,i,j in zip(a,b,x,y))
    b_likelihood=math.prod(v**i*u**j for u,v,i,j in zip(a,b,x,y))
    action=vote(a_likelihood-b_likelihood)
    approximate=math.fsum((i-j)*(math.log(u)-math.log(v)) for u,v,i,j in zip(a,b,x,y))
    assert abs(approximate)<1e-9 or vote(approximate)==action
    return action
records=[]
role_receipt={}
integrity={}
for setting, pair in (('mutagenicity_edge',(1,4)),('proteins_edge',(0,1))):
    grouped={code:r for code,r in roles.items() if r['setting']==setting}
    assert len(grouped)==8
    selected_ids=set()
    forbidden=set()
    for name,r in grouped.items():
        raw=r['roles']
        assert r['seed']==3405 and r['status']=='ok'
        assert len(set().union(*map(set,raw.values())))==sum(map(len,raw.values()))
        D=raw['D']
        C=ordered(raw['C'])
        m=len(C)//2
        same=C[:m]
        opposite=ordered(raw['U'])[:m]
        assert same==same_locked[name]['U_star'] and D==same_locked[name]['D']
        assert len(same)==len(opposite) and len(set(D+same+opposite))==len(D)+2*m
        role_receipt[name]={'D':D,'same_from_C':same,'opposite_from_U':opposite}
        forbidden.update(C[m:])
        selected_ids.update(D+same+opposite)
    assert selected_ids.isdisjoint(forbidden)
    pooldir=ROOT/'experiments/r5'/setting/'attempt-001'
    inventory=pooldir/'inputs/graph_hashes.json'
    expected=json.loads((pooldir/'seals/R5_INPUT.json').read_text())['files']['inputs/graph_hashes.json']
    assert expected==digest(inventory.read_bytes())
    fps=json.loads(inventory.read_text())
    with zipfile.ZipFile(pooldir/'inputs/graphs.pt') as z:
        meta=TensorMetadata(io.BytesIO(z.read('archive/data.pkl'))).load()
        graphs={g:graph_summary(z,meta,g,pair,fps) for g in sorted(selected_ids)}
    integrity[setting]={'R5_graph_inventory_sha256':expected,'x_and_edge_index_pairs_read':len(graphs),
                        'forbidden_query_ids':len(forbidden),'query_tensor_pairs_read':len(set(graphs)&forbidden)}
    for name,reg in sorted(grouped.items()):
        chosen=role_receipt[name]
        dm,dpos,dneg,dh=features(graphs,chosen['D'])
        for expr in ('same_from_C','opposite_from_U'):
            um,upos,uneg,uh=features(graphs,chosen[expr])
            for code in 'IP':
                if code=='I':
                    om,op,on,oh=um,upos,uneg,uh
                else:
                    om,op,on,oh=-um,uneg,upos,uh[::-1]
                p_i=fisher(dpos,dneg,op,on)
                p_p=fisher(dpos,dneg,on,op)
                for p, pos, neg in ((p_i,op,on),(p_p,on,op)):
                    assert abs(float(p)-fisher_exact([[dpos,dneg],[pos,neg]],alternative='two-sided').pvalue)<1e-10
                keep=''.join(t for t,p in [('I',p_i),('P',p_p)] if p>=Fraction(1,20)) or 'empty'
                records.append(dict(setting=setting,source=reg['source'],direction=reg['direction'],
                      reference=expr,D=len(chosen['D']),m=len(chosen[expr]),actual_code=code,
                      source_pos=dpos,source_neg=dneg,ref_pos=op,ref_neg=on,
                      count=vote(dm*om),retained=keep,common='P' if keep=='P' else 'I',
                      p_I=float(p_i),p_P=float(p_p),best_p=vote(p_i-p_p),degree=struct_decision(dh+1,oh)))
summary=[]
for setting in ('mutagenicity_edge','proteins_edge'):
    for ref in ('same_from_C','opposite_from_U'):
        for code in 'IP':
            rows=[r for r in records if (r['setting'],r['reference'],r['actual_code'])==(setting,ref,code)]
            assert len(rows)==8
            keep=Counter(r['retained'] for r in rows)
            out=dict(setting=setting,reference=ref,actual_code=code,directions=len(rows),
                    only_I=keep['I'],only_P=keep['P'],both=keep['IP'],empty=keep['empty'])
            for rule in ('count','common','best_p','degree'):
                tally=Counter(r[rule] for r in rows)
                out.update({f'{rule}_P':tally['P'],f'{rule}_tie':tally['tie']})
            summary.append(out)
save('directions.csv',records)
save('summary.csv',summary)
(OUT/'roles.json').write_text(json.dumps(role_receipt,indent=2)+'\n')
(OUT/'audit.json').write_text(json.dumps(dict(roles_sha256=digest(R9.read_bytes()),
    finite_blind_roles_sha256=digest(R7.read_bytes()),verification=integrity),indent=2)+'\n')
print((OUT/'summary.csv').read_text())
print((OUT/'audit.json').read_text())
