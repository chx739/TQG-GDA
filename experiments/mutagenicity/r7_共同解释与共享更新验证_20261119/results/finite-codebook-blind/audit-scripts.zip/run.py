"""Read-only hidden-codebook check. All results are written next to this script."""
import csv
import hashlib
import json
from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path

OUT = Path(__file__).resolve().parent
DATA = Path('/home/hxchen/research/GDA/TQG/data')
REPO = Path('/home/hxchen/research/GDA/TSBA/repository')
ROLES = next((REPO / 'experiments/mutagenicity').glob('r9*/results/attempt-002*/roles.json'))
SETTINGS = {
    'mutagenicity_edge': ('Mutagenicity_official_20261026', 'Mutagenicity', (1, 4)),
    'proteins_edge': ('PROTEINS_official_20261023', 'PROTEINS', (0, 1)),
}
HALF = F(1, 2)
inputs = {}
def read_file(path):
    payload = path.read_bytes()
    inputs[str(path)] = hashlib.sha256(payload).hexdigest()
    return payload

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def rank(graph_id):
    return hashlib.sha256(str(graph_id).encode('ascii')).digest()

def average(values):
    return sum(values, F(0))/len(values)

def sign(value):
    return int(value > 0) - int(value < 0)

def predict(source_sign, observed):
    product = source_sign * sign(observed)
    return {1: 'identity', -1: 'swap', 0: 'tie'}[product]

def score(predicted, real_codebook):
    if predicted == 'tie':
        return HALF
    return F(int(predicted == real_codebook))

def export_table(name, records):
    with (OUT / name).open('w') as f:
        writer=csv.DictWriter(f, fieldnames=records[0].keys())
        writer.writeheader()
        writer.writerows(records)

roles = json.loads(read_file(ROLES))
roles_kept = {}
all_rows, per_query = [], []
for setting, (dirname, name, pair) in SETTINGS.items():
    root = DATA / dirname / name / 'raw'
    selected = {k:r for k,r in roles.items() if r['setting']==setting}
    assert len(selected)==8
    if name=='Mutagenicity':
        codebook = read_file(root/f'{name}_label_readme.txt').decode().split('Edge labels were converted')[0]
        assert {tuple(row.split()) for row in codebook.splitlines()} >= {('1','O'),('4','N')}
    owners = read_file(root/f'{name}_graph_indicator.txt').splitlines()
    types = read_file(root/f'{name}_node_labels.txt').splitlines()
    active_ids = {i for row in selected.values() for part in ('D','C') for i in row['roles'][part]}
    counts = defaultdict(Counter)
    for owner, type_ in zip(owners, types, strict=True):
        graph_id = int(owner) - 1
        if graph_id in active_ids:
            counts[graph_id][int(type_)] += 1
    assert counts.keys()==active_ids
    assert all(counts[i].total()>0 for i in active_ids)
    if name=='PROTEINS':
        assert set().union(*(c.keys() for c in counts.values()))=={0,1,2}
    a,b=pair
    def difference(g,code):
        numerator=counts[g][a]-counts[g][b] if code=='identity' else counts[g][b]-counts[g][a]
        return F(numerator,counts[g].total())
    for k, region in sorted(selected.items()):
        ids=region['roles']
        assert region['seed']==3405 and region['status']=='ok'
        assert len(set().union(*map(set,ids.values())))==sum(map(len,ids.values()))
        D=ids['D']
        C=sorted(ids['C'],key=rank)
        middle=len(C)//2
        U,Q=C[:middle],C[middle:]
        assert set(U).isdisjoint(Q) and set(D).isdisjoint(U+Q)
        assert sorted(U+Q)==sorted(ids['C'])
        roles_kept[k]=dict(D=D,C=ids['C'],U_star=U,Q_star=Q)
        source=average([difference(g,'identity') for g in D])
        total_single=F(0)
        total_pool=F(0)
        ties=0
        checkpoints={}
        for code in ('identity','swap'):
            obs=average([difference(g,code) for g in U])
            decision=predict(sign(source),obs)
            votes=[predict(sign(source),difference(g,code)) for g in Q]
            single=sum((score(v,code) for v in votes),F(0))
            p_score=score(decision,code)
            checkpoints[code]=(single,p_score)
            for g,v in zip(Q,votes,strict=True):
                per_query.append(dict(region=k,graph_id_zero_based=g,code=code,
                    single_vote=v,pool_vote=decision,single_score=score(v,code),pool_score=p_score))
            ties += votes.count('tie')
            total_pool+=p_score*len(Q)
            total_single+=single
        assert checkpoints['identity']==checkpoints['swap']
        pool=total_pool/(len(Q)*2)
        single=total_single/(len(Q)*2)
        all_rows.append(dict(setting=setting,source=region['source'],direction=region['direction'],
            D=len(D),C=len(C),U_star=len(U),Q_star=len(Q),source_sign=sign(source),
            source_mean=str(source),pool_identity_mean=str(average([difference(g,'identity') for g in U])),
            single_correct_identifications_per_code=str(checkpoints['identity'][0]),single_ties_per_code=ties//2,
            pool_accuracy=str(pool),single_accuracy=str(single),pool_minus_single=str(pool-single)))

summaries=[]
for setting in SETTINGS:
    for source in [0,1,2,3,None]:
        rows = [r for r in all_rows if r['setting']==setting and (source is None or r['source']==source)]
        pool=average([F(r['pool_accuracy']) for r in rows])
        single=average([F(r['single_accuracy']) for r in rows])
        n=sum(r['Q_star'] for r in rows)
        micro_pool=sum(F(r['pool_accuracy'])*r['Q_star'] for r in rows)/n
        micro_single=sum(F(r['single_accuracy'])*r['Q_star'] for r in rows)/n
        summaries.append(dict(setting=setting,source='all' if source is None else source,directions=len(rows),
            Q_star_total=n,macro_pool=pool,macro_single=single,macro_gain=pool-single,
            micro_pool=micro_pool,micro_single=micro_single,micro_gain=micro_pool-micro_single,
            single_ties_per_code_total=sum(r['single_ties_per_code'] for r in rows)))
save('roles.json',roles_kept)
save('input-sha256.json',inputs)
export_table('directions.csv',all_rows)
export_table('query-by-codebook.csv',per_query)
export_table('summary.csv',summaries)
for r in summaries:
    print(r['setting'],r['source'],r['directions'],r['Q_star_total'],*[round(100*float(r[key]),3) for key in ('macro_pool','macro_single','macro_gain')],r['single_ties_per_code_total'])
