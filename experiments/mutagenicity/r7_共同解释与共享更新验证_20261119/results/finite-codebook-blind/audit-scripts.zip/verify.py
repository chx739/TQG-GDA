"""Independent vectorized recount with explicit raw-code permutations and held-out queries."""
import csv
import hashlib
import json
from fractions import Fraction
from pathlib import Path
import numpy as np

out=Path(__file__).resolve().parent
repo=Path('/home/hxchen/research/GDA/TSBA/repository')
base=Path('/home/hxchen/research/GDA/TQG/data')
r9=next((repo/'experiments/mutagenicity').glob('r9*/results/attempt-002*/roles.json'))
scope=json.loads(r9.read_text())
checksums=json.loads((out/'input-sha256.json').read_text())
assert hashlib.sha256(r9.read_bytes()).hexdigest()==checksums[str(r9)]==json.loads((r9.parent/'OBS.json').read_text())['files']['roles.json']
with (out/'query-by-codebook.csv').open() as f:
    votes={(row['region'],row['code'],int(row['graph_id_zero_based'])):(row['single_vote'],row['pool_vote']) for row in csv.DictReader(f)}
with (out/'directions.csv').open() as f:
    dirs={(row['setting'],int(row['source']),row['direction']):row for row in csv.DictReader(f)}
derived=json.loads((out/'roles.json').read_text())
verified=0
all_decisions=0
output=[]
for setting,name,pair in [('mutagenicity_edge','Mutagenicity',(1,4)),('proteins_edge','PROTEINS',(0,1))]:
    plan=json.loads(next((repo/'experiments/mutagenicity').glob('r5*/configs/'+name.lower()+'-plan.json')).read_text())
    root=next(base.glob(name+'_official*/'+name+'/raw'))
    paths=[root/(name+s) for s in ('_graph_indicator.txt','_node_labels.txt')]
    for path in paths:
        assert hashlib.sha256(path.read_bytes()).hexdigest()==plan['input']['files'][path.name]['sha256']==checksums[str(path)]
    owner=np.loadtxt(paths[0],dtype=int)-1
    t0=np.loadtxt(paths[1],dtype=int)
    ix,iy=pair
    t1=np.where(t0==ix,iy,np.where(t0==iy,ix,t0))
    assert np.all(np.where(t1==ix,iy,np.where(t1==iy,ix,t1))==t0)
    node_counts=np.bincount(owner)
    def contrast(types):
        return (np.bincount(owner[types==ix],minlength=len(node_counts))-np.bincount(owner[types==iy],minlength=len(node_counts)))/node_counts
    x0=contrast(t0)
    x1=contrast(t1)
    assert np.allclose(x0,-x1)
    for k,r in scope.items():
        if r['setting']!=setting:
            continue
        c=sorted(r['roles']['C'],key=lambda i:hashlib.sha256(str(i).encode()).hexdigest())
        U, Q=np.array_split(c,[len(c)//2])
        assert set(derived[k]['Q_star'])==set(Q) and set(derived[k]['U_star'])==set(U)
        src=np.mean(x0[r['roles']['D']])
        assert abs(src)>1e-12
        total=[0.,0.]
        pool_agrees=[]
        for code,observed in [('identity',x0),('swap',x1)]:
            ref=observed[U].mean()
            assert abs(ref)>1e-12
            p='identity' if np.signbit(src)==np.signbit(ref) else 'swap'
            pool_agrees.append(int(p==code))
            for g in Q:
                s='tie' if observed[g]==0 else ('identity' if np.signbit(src)==np.signbit(observed[g]) else 'swap')
                assert (s,p)==votes[k,code,int(g)]
                total[0]+=0.5 if s=='tie' else int(s==code)
                total[1]+=int(p==code)
                all_decisions+=1
        assert pool_agrees[0]==pool_agrees[1]
        record=dirs[setting,r['source'],r['direction']]
        for i,attr in enumerate(['single_accuracy','pool_accuracy']):
            assert abs(total[i]/(2*len(Q))-float(Fraction(record[attr])))<1e-12
        verified+=1
        output.append(f"{k} D={len(r['roles']['D'])} U*={len(U)} Q*={len(Q)} pool={pool_agrees[0]} solo={total[0]/(2*len(Q)):.6f}")
print('\n'.join(output))
print(f'Confirmed {verified} directions and {all_decisions} individual query/codebook pairs. R9 role and R5 raw-input hashes matched.')
